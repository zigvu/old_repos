/* DUPLICATE CODE: TODO : Remove from lib/main.js */

// some upload status constants
var uploadStatusQueue = "Upload Queue";
var uploadStatusBegin = "Uploading";
var uploadStatusSuccess = "Upload Success";
var uploadStatusFailure = "Upload Failure";

/* Debug levels: 
	0 = no logs, 
	1 = critical logs, 
	2 = essential logs, 
	3 = debug logs */
var debugLevel = 3;

function log(logLevel, logText) {
	if (logLevel <= debugLevel) {
		console.log(logText);
	}
}