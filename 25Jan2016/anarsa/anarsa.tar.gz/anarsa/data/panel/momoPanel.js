
var momoPanelSubmitButton = document.getElementById("momo-panel-submit-button");
momoPanelSubmitButton.onclick = function() {
	var textArea = document.getElementById('momo-url-box');
	// Remove any newline.
	var url = textArea.value.replace(/(\r\n|\n|\r)/gm,"");

	// TODO: check for validity of URL -- not working right now
	//if(URL.isValidURI(url)){
		log(3, "PORT:EMIT: momoPanelSubmit");
		self.port.emit("momoPanelSubmit", url);
	//} else {
	// 	log(2, "Invalid URL submitted");
	// 	alert("Supplied URL is not valid URI - please ensure it has http(s) and correct address");
	// }
}

var momoPanelResetButton = document.getElementById("momo-panel-reset-button");
momoPanelResetButton.onclick = function() {
	// reset all values in panel and send emit
	$('#momo-panel-success').html("");
	$('#momo-panel-errors').html("");
	document.getElementById('momo-url-box').value = "";

	log(3, "PORT:EMIT: momoPanelReset");
	self.port.emit("momoPanelReset");
}

self.port.on('panelErrorConnectingToMomo', function(momo){
	log(3, "PORT:ON: panelErrorConnectingToMomo");
	// Add errors to panel:
	$('#momo-panel-errors').html(function(){
		var txt = '<ul>';
		momo.errors.forEach(function(error){
			txt = txt + '<li>' + error + '</li>';
		});
		txt = txt + '</ul>';
		return txt;
	});
	// Remove success info:
	$('#momo-panel-success').html("");
});

self.port.on('panelSuccessConnectingToMomo', function(momo){
	log(3, "PORT:ON: panelSuccessConnectingToMomo");
	// Add success to panel:
	$('#momo-panel-success').html(function(){
		var txt = '<ul>';
		txt = txt + '<li>User: ' + momo.userId + '</li>';
		txt = txt + '<li>Model: ' + momo.modelId + '</li>';
		txt = txt + '</ul>';
		return txt;
	});
	// Remove errors info:
	$('#momo-panel-errors').html("");
});
