var minWidthPx = 600;
var minHeightPx = 600;
var imgAddStyle = {'border': "2px solid red"};
var imgRemoveStyle = {'border': "0px solid white"};

self.port.on('selectorRescanImages', function () {	
	log(3, "PORT:ON: selectorRescanImages");
	markImages();
});

self.port.on('selectorResetImages', function () {	
	log(3, "PORT:ON: selectorResetImages");
	resetImages();
});

function createSaveBox(offset, link){
	var saveBox = $('<div class="zigvuImgSave">Save</div>');
	$('body').append(saveBox);
	// float box in appropriate place
	$(saveBox).css({'top': offset.top, 
		'left': offset.left, 
		'position': 'absolute', 
		'z-index': 9999});

	// if save button is clicked, emit to let selector know
	$(saveBox).click(function(){
		log(3, "PORT:EMIT: selectorImageSelected");
		self.port.emit('selectorImageSelected', link);
	});
}

// Mark all images that fit a particular criteria
function markImages(){
	// first, reset all images in page
	resetImages();

	// For each image in the file that satisfies width/height criteria
	$('img').each(function(index, element) {
		// independently load the image and check dimensions:
		var newImage = new Image();
		newImage.onload = function() {
			if ((this.width >= minWidthPx) || (this.height >= minHeightPx)) {
				// border the images that can be saved
				$(element).css(imgAddStyle);
				// overlay a save button
				createSaveBox($(element).offset(), element.src);
			}
		};
		newImage.src = this.src;
	});	
}

// Reset all images
function resetImages(){
	// For all populated save boxes, delete them
	$('.zigvuImgSave').remove();
	// Remove image decoration as well
	$('img').each(function(index, element) {
		$(element).css(imgRemoveStyle);
	});
}