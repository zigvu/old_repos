
URLUploader = {
	momoConnected: false,
	momoUploadUrl: '',
	uploadArray: [],

	maxNumberOfUploadItemsToShow: 50,
	tableRootIdStr: '#sideBarLoadedImagesTable',

	// update status of url upload and refresh html
	updateStatus: function(url, status) {
		var that = this;
		this.uploadArray.forEach(function(uploadItem){
			if (url === uploadItem['url']) {
				log(2, "Status: URL: " + uploadItem['url'] + ", Status: " + uploadItem['status']);
				uploadItem['status'] = status;
				that.updateHTMLURLStatus();
				return true;
			}
		});
		return false;
	},
	// add url if it doesn't exist
	addURL: function (url) {
		this.uploadArray.forEach(function(uploadItem){
			if (url === uploadItem['url']) {
				return false;
			}
		});
		this.cleanUpUploadArray();
		this.uploadArray.unshift({
			url: url, 
			status: uploadStatusQueue
		});
		this.updateHTMLURLStatus();
		return true;
	},
	// remove url if it exists
	removeURL: function(url){
		var that = this;
		this.uploadArray.forEach(function(uploadItem){
			if (url === uploadItem['url']) {
				that.uploadArray.splice(that.uploadArray.indexOf(uploadItem), 1);
				that.updateHTMLURLStatus();
				return true;
			}
		});
		return false;
	},
	// if array length exceeds max, clean up in order of success/date
	cleanUpUploadArray: function(){
		var that = this;
		// remove success
		if (this.uploadArray.length >= this.maxNumberOfUploadItemsToShow) {
			this.uploadArray.reverse().forEach(function(uploadItem){
				if (uploadStatusSuccess === uploadItem['status']) {
					that.uploadArray.splice(that.uploadArray.indexOf(uploadItem), 1);
				}
			});
		}
	},
	// refresh image and status table rows
	updateHTMLURLStatus: function() {
		var that = this;
		// remove and re-add the table body and rows
		$(this.tableRootIdStr).children('tbody').remove();
		$('<tbody>').appendTo(this.tableRootIdStr);

		$.each(this.uploadArray, function(index, uploadItem){
			var trClass = function(){
				// bootstrap defined classes
				if (uploadItem['status'] == uploadStatusSuccess) {
					return "success";
				} else if (uploadItem['status'] == uploadStatusFailure) {
					return "danger";
				} else {
					return "warning";
				}
			};
			var tr = $(that.tableRootIdStr)
				.find('tbody')
				.append($('<tr>')
					.attr('class', trClass)
					.append($('<td>')
						.append($('<img>')
							.attr('src', uploadItem['url'])
							.attr('class', "thumbnails")
							.attr('title', uploadItem['url'])))
					.append($('<td>').text(uploadItem['status']))
				);
		});
	}
};



log(3, "PORT:EMIT: sidebarWorkerReady");
addon.port.emit("sidebarWorkerReady");

addon.port.on("sidebarWorkerInit", function(momoConnectionStruct){
	log(3, "PORT:ON: sidebarWorkerInit");
	URLUploader.momoConnected = momoConnectionStruct['momoConnected'];
	URLUploader.momoUploadUrl = momoConnectionStruct['momoUploadUrl'];
	log(3, "Sidebar: Status: " + URLUploader.momoConnected + ", URL: " + URLUploader.momoUploadUrl);
});

addon.port.on("sidebarImageToUpload", function(urlToUpload){
	log(3, "PORT:ON: sidebarImageToUpload");
	URLUploader.addURL(urlToUpload);
});

addon.port.on("sidebarUpdateURLStatus", function(urlUploadStatus){
	log(3, "PORT:ON: sidebarUpdateURLStatus");
	URLUploader.updateStatus(urlUploadStatus['urlToUpload'], urlUploadStatus['uploadStatus']);
});

$('#rescanImagesButton').click(function(){
	addon.port.emit("sidebarWorkerRescanButton");
});

// URLUploader.addURL("http://cdn.nepal.fm/media/Yo-Timlay-Garda-Ho-James-Shrestha-Nepal-FM.jpg");
// URLUploader.addURL("http://i1.ytimg.com/vi/1fQxteKBgSY/hqdefault.jpg");
// console.log(URLUploader.uploadArray);


