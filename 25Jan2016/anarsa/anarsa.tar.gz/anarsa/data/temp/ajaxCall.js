// start ajax calls
	startAjaxCalls: function() {
		var that = this;
		$.each(this.uploadArray, function(index, uploadItem){
			if (that.uploadStatusQueue === uploadItem['status']) {
				$.ajax({
					url: that.momoUploadUrl,
					data: {
						addonAction: 'link',
						addonLink: uploadItem['url']
					},
					beforeSend: function(){
						log(2, "Attempt to save link: " + uploadItem['url']);
						that.updateStatus(uploadItem['url'], that.uploadStatusBegin);
					},
					success: function(data) {
						var stts;
						if (data['Status'] === 'success') {
							log(2, "Saved link: " + uploadItem['url']);
							stts = that.uploadStatusSuccess;
						} else {
							log(2, "Failed to save link: Server Response Error: " + data['Status']);
							stts = that.uploadStatusFailure;
						}
						that.updateStatus(uploadItem['url'], stts);
					},
					error: function() {
						log(2, "Failed to save link: AJAX Error: " + uploadItem['url']);
						that.updateStatus(uploadItem['url'], that.uploadStatusFailure);
					}
				});
			}
		});
	},