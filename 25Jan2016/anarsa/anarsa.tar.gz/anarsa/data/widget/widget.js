
var connectMomoButton = document.getElementById("connect-momo-button");
connectMomoButton.onclick = function() {
	log(3, "PORT:EMIT: widgetConnectMomo");
  self.port.emit("widgetConnectMomo");
}

// Change connection icons
self.port.on('widgetConnectMomoEnabled', function(){
	log(3, "PORT:ON: widgetConnectMomoEnabled");
	connectMomoButton.src = "connection-icon-enabled.png";
});
self.port.on('widgetConnectMomoDisabled', function(){
	log(3, "PORT:ON: widgetConnectMomoDisabled");
	connectMomoButton.src = "connection-icon-disabled.png";
});