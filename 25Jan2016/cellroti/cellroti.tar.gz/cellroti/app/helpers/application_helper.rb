module ApplicationHelper
	include FoundationRailsHelper::FlashHelper
end
