module Jsonifiers
	class JAnalytics
		def initialize
		end
	end
end