require 'test_helper'

class ClientDecoratorTest < Draper::TestCase
end
