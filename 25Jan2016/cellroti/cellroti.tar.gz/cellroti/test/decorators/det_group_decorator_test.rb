require 'test_helper'

class DetGroupDecoratorTest < Draper::TestCase
end
