require 'test_helper'

class EventDecoratorTest < Draper::TestCase
end
