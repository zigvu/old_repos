require 'test_helper'

class GameDecoratorTest < Draper::TestCase
end
