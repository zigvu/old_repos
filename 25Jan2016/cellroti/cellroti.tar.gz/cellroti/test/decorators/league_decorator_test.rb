require 'test_helper'

class LeagueDecoratorTest < Draper::TestCase
end
