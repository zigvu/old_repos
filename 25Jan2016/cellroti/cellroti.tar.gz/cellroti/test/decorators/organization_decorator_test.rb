require 'test_helper'

class OrganizationDecoratorTest < Draper::TestCase
end
