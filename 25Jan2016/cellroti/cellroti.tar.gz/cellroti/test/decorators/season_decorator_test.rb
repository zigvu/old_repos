require 'test_helper'

class SeasonDecoratorTest < Draper::TestCase
end
