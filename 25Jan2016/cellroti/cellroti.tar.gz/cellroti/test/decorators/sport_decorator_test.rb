require 'test_helper'

class SportDecoratorTest < Draper::TestCase
end
