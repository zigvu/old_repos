require 'test_helper'

class DetGroupsHelperTest < ActionView::TestCase
end
