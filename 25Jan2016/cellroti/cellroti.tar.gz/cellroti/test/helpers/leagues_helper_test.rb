require 'test_helper'

class LeaguesHelperTest < ActionView::TestCase
end
