require 'test_helper'

class OrganizationsHelperTest < ActionView::TestCase
end
