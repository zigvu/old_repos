require 'test_helper'

class ClientDetectableTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
