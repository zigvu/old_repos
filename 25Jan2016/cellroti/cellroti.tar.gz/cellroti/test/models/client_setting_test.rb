require 'test_helper'

class ClientSettingTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
