require 'test_helper'

class DetGroupClientTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
