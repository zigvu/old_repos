require 'test_helper'

class DetGroupTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
