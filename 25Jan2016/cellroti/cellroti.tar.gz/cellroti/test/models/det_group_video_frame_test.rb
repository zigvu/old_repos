require 'test_helper'

class DetGroupVideoFrameTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
