require 'test_helper'

class DetectableMetricTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
