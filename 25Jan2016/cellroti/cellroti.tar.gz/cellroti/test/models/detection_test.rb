require 'test_helper'

class DetectionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
