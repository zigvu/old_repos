require 'test_helper'

class GameTeamTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
