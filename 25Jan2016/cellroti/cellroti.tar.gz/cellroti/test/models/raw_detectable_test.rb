require 'test_helper'

class RawDetectableTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
