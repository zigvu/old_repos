require 'test_helper'

class SummaryDetGroup1SecondTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
