require 'test_helper'

class SummaryDetGroup60SecondTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
