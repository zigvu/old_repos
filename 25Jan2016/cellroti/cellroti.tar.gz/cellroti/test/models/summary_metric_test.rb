require 'test_helper'

class SummaryMetricTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
