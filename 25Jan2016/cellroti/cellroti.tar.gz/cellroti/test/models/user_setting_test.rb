require 'test_helper'

class UserSettingTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
