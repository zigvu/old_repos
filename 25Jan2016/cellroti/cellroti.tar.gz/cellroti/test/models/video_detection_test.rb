require 'test_helper'

class VideoDetectionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
