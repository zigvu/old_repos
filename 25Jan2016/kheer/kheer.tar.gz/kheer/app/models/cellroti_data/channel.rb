class CellrotiData::Channel < CellrotiData::StreamActions
  @streamObjAttr = [:name, :description, :url]
  # get nothing else from controller
end
