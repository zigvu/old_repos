class CellrotiData::League < CellrotiData::StreamActions
  @streamObjAttr = [:name, :description]
  # get sport_id from controller
end
