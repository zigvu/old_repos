class CellrotiData::Season < CellrotiData::StreamActions
  @streamObjAttr = [:name, :description]
  # get league_id from controller
end
