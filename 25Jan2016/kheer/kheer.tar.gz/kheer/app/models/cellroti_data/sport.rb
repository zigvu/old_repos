class CellrotiData::Sport < CellrotiData::StreamActions
  @streamObjAttr = [:name, :description]
  # get nothing else from controller
end
