class CellrotiData::SubSeason < CellrotiData::StreamActions
  @streamObjAttr = [:name, :description]
  # get season_id from controller
end
