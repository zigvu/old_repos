class CellrotiData::Team < CellrotiData::StreamActions
  @streamObjAttr = [:name, :description, :icon_path]
  # get league_id from controller
end
