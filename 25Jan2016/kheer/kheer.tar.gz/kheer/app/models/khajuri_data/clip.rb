class Clip < ActiveRecord::Base
  belongs_to :video
end
