HighVoltage.configure do |config|
  config.home_page = 'index'
end