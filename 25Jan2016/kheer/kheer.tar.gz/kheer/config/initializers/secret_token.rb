# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Kheer::Application.config.secret_key_base = '6c3cefef29294f152d6c2719f537e1068fb67a4bda8f7aa753e7cb5722149dd3316f92e18e2e7afa9616955dc8f3fe80d28b95a004303ca43b37797a4d3024fb'
