require 'test_helper'

class ChannelDecoratorTest < Draper::TestCase
end
