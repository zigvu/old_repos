require 'test_helper'

class ChiaVersionDecoratorTest < Draper::TestCase
end
