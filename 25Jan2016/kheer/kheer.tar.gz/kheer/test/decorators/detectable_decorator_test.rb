require 'test_helper'

class DetectableDecoratorTest < Draper::TestCase
end
