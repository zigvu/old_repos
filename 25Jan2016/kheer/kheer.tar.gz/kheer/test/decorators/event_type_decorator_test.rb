require 'test_helper'

class EventTypeDecoratorTest < Draper::TestCase
end
