require 'test_helper'

class GameTeamDecoratorTest < Draper::TestCase
end
