require 'test_helper'

class MiningDecoratorTest < Draper::TestCase
end
