require 'test_helper'

class SetupMiningDecoratorTest < Draper::TestCase
end
