require 'test_helper'

class SubSeasonDecoratorTest < Draper::TestCase
end
