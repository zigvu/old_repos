require 'test_helper'

class TeamDecoratorTest < Draper::TestCase
end
