require 'test_helper'

class VideoCollectionDecoratorTest < Draper::TestCase
end
