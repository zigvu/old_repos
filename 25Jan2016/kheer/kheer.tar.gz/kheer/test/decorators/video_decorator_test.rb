require 'test_helper'

class VideoDecoratorTest < Draper::TestCase
end
