require 'test_helper'

class ChannelsHelperTest < ActionView::TestCase
end
