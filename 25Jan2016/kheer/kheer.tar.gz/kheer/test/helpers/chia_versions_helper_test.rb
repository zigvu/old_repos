require 'test_helper'

class ChiaVersionsHelperTest < ActionView::TestCase
end
