require 'test_helper'

class DetectablesHelperTest < ActionView::TestCase
end
