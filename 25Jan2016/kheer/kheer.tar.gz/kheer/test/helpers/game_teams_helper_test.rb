require 'test_helper'

class GameTeamsHelperTest < ActionView::TestCase
end
