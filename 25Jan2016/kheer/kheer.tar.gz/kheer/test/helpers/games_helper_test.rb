require 'test_helper'

class GamesHelperTest < ActionView::TestCase
end
