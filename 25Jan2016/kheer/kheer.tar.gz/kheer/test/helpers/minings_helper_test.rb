require 'test_helper'

class MiningsHelperTest < ActionView::TestCase
end
