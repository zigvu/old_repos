require 'test_helper'

class SeasonsHelperTest < ActionView::TestCase
end
