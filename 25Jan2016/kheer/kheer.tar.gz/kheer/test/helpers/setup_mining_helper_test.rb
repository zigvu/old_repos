require 'test_helper'

class SetupMiningHelperTest < ActionView::TestCase
end
