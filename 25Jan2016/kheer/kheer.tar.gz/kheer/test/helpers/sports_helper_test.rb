require 'test_helper'

class SportsHelperTest < ActionView::TestCase
end
