require 'test_helper'

class SubSeasonsHelperTest < ActionView::TestCase
end
