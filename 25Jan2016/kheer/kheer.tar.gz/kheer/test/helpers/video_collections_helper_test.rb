require 'test_helper'

class VideoCollectionsHelperTest < ActionView::TestCase
end
