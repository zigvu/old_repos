require 'test_helper'

class VideosHelperTest < ActionView::TestCase
end
