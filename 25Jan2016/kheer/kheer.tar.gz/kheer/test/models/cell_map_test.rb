require 'test_helper'

class CellMapTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
