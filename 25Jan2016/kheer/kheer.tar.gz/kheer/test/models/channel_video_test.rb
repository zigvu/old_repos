require 'test_helper'

class ChannelVideoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
