require 'test_helper'

class ChiaVersionDetectableTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
