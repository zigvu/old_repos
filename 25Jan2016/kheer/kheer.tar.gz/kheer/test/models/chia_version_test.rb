require 'test_helper'

class ChiaVersionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
