require 'test_helper'

class FrameScoreTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
