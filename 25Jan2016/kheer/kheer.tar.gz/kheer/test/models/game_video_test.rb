require 'test_helper'

class GameVideoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
