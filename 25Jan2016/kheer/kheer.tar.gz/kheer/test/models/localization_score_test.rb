require 'test_helper'

class LocalizationScoreTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
