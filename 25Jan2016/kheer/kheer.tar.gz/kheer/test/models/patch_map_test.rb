require 'test_helper'

class PatchMapTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
