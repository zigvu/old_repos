require 'test_helper'

class PatchScoreTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
