require 'test_helper'

class SubSeasonTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
