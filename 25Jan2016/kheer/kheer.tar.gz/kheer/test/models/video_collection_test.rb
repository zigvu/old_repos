require 'test_helper'

class VideoCollectionTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
