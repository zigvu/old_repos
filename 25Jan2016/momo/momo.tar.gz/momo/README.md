Momo
============

Repo for rails server

To run the server run:
 
`cd momo`

`rails server`

