# Class to convert parts of database to JSON 
class GetJSONFromDatabase

	def getJSONForVideoDetections(videoId)
		video = Video.find(videoId)
		if video.video_detections.count <= 0
			raise Exception.new("No video detections found")
		end
		modelIds = video.video_detections.pluck(:model_id)
		videoDetectionsHash = {}
		modelIds.each do |modelId|
			videoDetections = video.video_detections.where(model_id: modelId)
			if videoDetections.count > 1
				raise Exception.new("Multiple video detections found; ModelId: " + modelId.to_s)
			end
			videoDetectionsHash.merge!({modelId => videoDetections.first})
		end

		videoFrames = []
		video.video_frames.find_each do |video_frame|
			detectionScores = []
			modelIds.each do |modelId|
				frameDetections = video_frame
													.frame_detections
													.where(video_detection_id: videoDetectionsHash[modelId].id)
				if frameDetections.count <= 0
					detectionScores << {
						ModelId: modelId,
						DetectionScore: nil
					}
				else
					detectionScores << {
						ModelId: modelId,
						DetectionScore: frameDetections.first.frame_score
					}
				end
			end

			videoFrames << {
				VideoFrameNumber: video_frame.frame_position,
				S3_URL: video_frame.S3_URL,
				DetectionScores: detectionScores
			}
		end

		resultJSON = {
			VideoEvaluationResult: {
				VideoId: video.id,
				ModelIds: modelIds,
				Plugins: ["DetectionScore"],
				VideoFrames: videoFrames
			}
		}
		return JSON.pretty_generate(resultJSON)
	end

	def getJSONForModelAlbumResult(resultModelId, resultAlbumType)
		model = Model.find(resultModelId)
		imageScoresArray = []
		imgScore = -0.3
		model.image_tags.where(usage: resultAlbumType).find_each do |image_tag|
			imageScoresArray << {
				ImageId: image_tag.image_id,
				DetectionScore: image_tag.detection_score
			}
		end
		resultJSON = {
			ModelAlbumResult: {
				ModelId: model.id,
				ModelVersion: model.model_version,
				ModelName: model.name,
				Album: resultAlbumType,
				Plugins: ["DetectionScore"],
				ImageScores: imageScoresArray
			}
		}
		return JSON.pretty_generate(resultJSON)
	end
end