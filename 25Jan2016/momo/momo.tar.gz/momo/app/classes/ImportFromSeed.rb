# Class to seed database with images.
# 
# This class loads images to S3 and populates database
# values for development environment. Typically, images should be
# saved in '/var/seedImages' and the functions of this class should
# be called from db/seeds.rb
class ImportFromSeed

	# Upper limit on number of image per album
	@limitRecords = 500

	# Set default limit on number items for recording
	#
	# Defaults to 500
	# @param limit [Integer] number of items for limiting records
	def setLimitRecordCount(limit)
		@limitRecords = limit
	end

	# Add multiple images from folder to image bank
	#
	# @param userId [Integer] id of user performing this operation
	# @param modelId [Integer] id of model for which images are added
	# @param usage [String] image tag constants from {ImageTag}
	# @param modelTextTag [String] one of the text tag associated with model
	# @param albumPath [String] folder path of where the images are located
	def addImagesToAlbum(userId, modelId, usage, modelTextTag, albumPath)
		limitRecordCount = 0
		imageFirstLevels = Dir[albumPath + '/*']
		imageFirstLevels.map do |imageFirstLevel|
			if File.file?(imageFirstLevel)
				addImageToDatabase(userId,
					modelId,
					usage,
					modelTextTag,
					imageFirstLevel,
					"Local")

				limitRecordCount = limitRecordCount + 1
				if (limitRecordCount >= @limitRecords)
					return
				end
			end
		end
	end

	# Add multiple images from the SUN library to image bank
	#
	# This method recursively traverses the SUN image library.
	# The folder names in the library are treated as image tags.
	# @param imageBankModelId [Integer] id of the imagebank model
	# @param sunFolderPath [String] folder path of where the SUN images are located
	def importSUNImagesToImageBank(imageBankModelId, sunFolderPath)
		limitRecordCount = 0

		# expect images in the SUN library format
		imageFirstLevels = Dir[sunFolderPath + '/*/*']
		imageFirstLevels.map do |imageFirstLevel|
			if File.directory?(imageFirstLevel)
				imageFirstLevelFolderName = File.basename(imageFirstLevel)

				imageSecondLevels = Dir[imageFirstLevel + '/*']
				imageSecondLevels.map do |imageSecondLevel|
					# some times there are folder within folders:
					if File.directory?(imageSecondLevel)
						imageSecondLevelFolderName = File.basename(imageSecondLevel)

						imageThirdLevels = Dir[imageSecondLevel + '/*']
						imageThirdLevels.map do |imageThirdLevel|
							if File.file?(imageThirdLevel)
								modelTextTag = imageFirstLevelFolderName + "." + imageSecondLevelFolderName
								addSunImageToImageBank(imageBankModelId, modelTextTag, imageThirdLevel)

								limitRecordCount = limitRecordCount + 1
								if (limitRecordCount >= @limitRecords)
									return
								end
							end
						end
					elsif File.file?(imageSecondLevel)
						modelTextTag = imageFirstLevelFolderName
						addSunImageToImageBank(imageBankModelId, modelTextTag, imageSecondLevel)

						limitRecordCount = limitRecordCount + 1
						if (limitRecordCount >= @limitRecords)
							return
						end
					end
				end
			end
		end
	end

	# Create dummy model
	#
	# Create a new {TreeNode} under the prescribed parent and create V0
	# model under that new {TreeNode}.
	# @param modelName [String] name of the model to be built
	# @param user [User] the current user
	# @param treeNodeParent [TreeNode] parent node of the new model
	# @param modelComment [String] comment for this model
	# @return [Model] newly created model
	def createDummyModel(modelName, user, treeNodeParent, modelComment)
		treeNode =  TreeNode.new(name: modelName, description: "Dummy node", comment: "", user_id: user.id)
		treeNodeParent.add_child treeNode
		model = Model.create(name: modelName, model_version: 0, model_type: "Object", buildstatus: "pre-build", algorithm: "StructSVM-Generic", modelpath: Model.fileNotFoundString, accuracy: 0.0, threshold: 0.0, comment: modelComment, tree_node_id: treeNode.id, user_id: user.id)
		model.model_text_tags.create(user_id: user.id, tag: ModelTextTag::UNASSIGNED)
		
		# return newly created model
		model
	end

	# Add video frames to database of a prior detection event
	#
	# @param jsonVideoDetectionFilePath [String] file path to read JSON file
	# @param dataBaseFolder [String] folder path from which to reconstruct image
	#   paths based on JSON field data
	# @param videoId [Integer] id of video for which this detection is occuring
	# @param videoDetectionId [Integer] id of video detection event for this detection
	def addVideoFrames(jsonVideoDetectionFilePath, dataBaseFolder, videoId, videoDetectionId)
		limitRecordCount = 0

		jsonFile = ActiveSupport::JSON.decode(File.read(jsonVideoDetectionFilePath))
		video = Video.find(videoId)
		videoDetection = VideoDetection.find(videoDetectionId)

		s3 = AWS::S3.new(
			:access_key_id => YAML.load_file("#{Rails.root}/config/passwords.yml")[Rails.env]["aws_access_key_id"],
			:secret_access_key => YAML.load_file("#{Rails.root}/config/passwords.yml")[Rails.env]["aws_secret_access_key"])
		bucketDevelopment = s3.buckets['zigvuvideosdevelopment']
		bucketProduction = s3.buckets['zigvuvideosproduction']

		jsonFile.each do |j|
			time = j["Time"]
			fileName = dataBaseFolder + '/' + j["Filename"]

			# store depending on environment:
			if Rails.env.local?
				dirName = "#{Rails.root}/public/system/images/videoFrames/" + videoId.to_s + '/'+ time.to_s
				FileUtils.mkdir_p(dirName)
				FileUtils.cp(fileName, dirName + '/original.png')
				fileName = '/system/images/videoFrames/' + videoId.to_s + '/'+ time.to_s + '/original.png'
			elsif Rails.env.development?					
				bucketDevelopment.objects['uploads/' + videoId.to_s + '/'+ time.to_s + '/original.png'].write(file: fileName)
				# rewrite filename:
				fileName = 's3-us-west-2.amazonaws.com/zigvuvideosdevelopment/uploads/' + videoId.to_s + '/'+ time.to_s + '/original.png'
			elsif Rails.env.production?					
				bucketProduction.objects['uploads/' + videoId.to_s + '/'+ time.to_s + '/original.png'].write(file: fileName)
				# rewrite filename:
				fileName = 's3-us-west-2.amazonaws.com/zigvuvideosproduction/uploads/' + videoId.to_s + '/'+ time.to_s + '/original.png'
			end

			vf = video.video_frames.create_with(S3_URL: fileName).find_or_create_by(frame_position: time)
			#vf = video.video_frames.create(S3_URL: fileName, frame_position: time)
			clsf = j["Score"] > 0 ? VideoDetection::CLASSIFICATION[:positive] : VideoDetection::CLASSIFICATION[:negative]
			vf.frame_detections.create(frame_score: j["Score"], cumulative_score: j["Score"] + 0.1, classification: clsf, video_detection_id: videoDetectionId)

			puts "VideoFrame--> " + fileName

			limitRecordCount = limitRecordCount + 1
			if (limitRecordCount >= @limitRecords)
				return
			end
		end
	end

	private

	# Add single image from the SUN library to image bank
	#
	# This method adds a single image from the SUN image library by
	# updating the database and uploading the image to S3 via paperclip
	# For each image, it also saves a image tag
	# @param imageBankModelId [Integer] id of the imagebank model
	# @param modelTextTag [String] the text tag for this image - taken from folder name
	# @param fullFilePath [String] file path of where the SUN image is located
	def addSunImageToImageBank(imageBankModelId, modelTextTag, fullFilePath)
		userId = User.getBuilderId
		addImageToDatabase(userId,
				imageBankModelId,
				ImageTag::TRAIN_POS,
				modelTextTag,
				fullFilePath,
				"SUN")
	end

	# Add images for a particular model, usage and text tag from source
	#
	# @param userId [Integer] id of user performing this operation
	# @param modelId [Integer] id of model for which images are added
	# @param usage [String] image tag constants from {ImageTag}
	# @param modelTextTag [String] one of the text tag associated with model
	# @param fullFilePath [String] file path of where the image is located
	# @param dataSource [String] name of the data source
	def addImageToDatabase(userId, modelId, usage, modelTextTag, fullFilePath, dataSource)
		puts usage + "--> " + fullFilePath
		model = Model.find(modelId)

		# if modelTextTag is nil, then probably it is negative image
		if modelTextTag != nil
			mtt = model.model_text_tags.where(tag: modelTextTag).first
			# if text tag doesn't exist, create it:
			if mtt == nil
				mtt = model.model_text_tags.create(tag: modelTextTag, user_id: userId)
			end
			mttId = mtt.id
		else
			mttId = nil
		end

		image = Image.new
        image.upload = File.new(fullFilePath)
        image.user_id = userId
        image.file_source = dataSource
        image.save

        model.image_tags
			.create(usage: usage, 
				image_id: image.id, 
				user_id: userId, 
				model_text_tag_id: mttId)
	end
end