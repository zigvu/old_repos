# Class to populate database from given JSON
class PopulateDatabaseFromJSON

	def populateVideoAnalysisResult(resultVideoId, resultJSON)
		videoId = resultJSON['VideoEvaluationResult']['VideoId']
		modelIds = resultJSON['VideoEvaluationResult']['ModelIds']
		videoFrames = resultJSON['VideoEvaluationResult']['VideoFrames']
		# check basic errors:
		if (resultVideoId != videoId) || 
			(videoFrames.count <= 0)
			raise Exception.new("JSON doesn't match function signature")
		end
		# store video detections in hash
		video = Video.find(videoId)
		videoDetectionsHash = {}
		modelIds.each do |modelId|
			videoDetections = video.video_detections.where(model_id: modelId)
			if videoDetections.count <= 0
				raise Exception.new("Video detections not found; ModelId: " + modelId.to_s)
			end
			videoDetectionsHash.merge!({modelId => videoDetections.first})
		end

		videoFrames.each do |vf|
			video_frame = video.video_frames
											.create_with(S3_URL: vf['S3_URL'].to_s)
											.find_or_create_by(frame_position: vf['VideoFrameNumber'])
			vf['DetectionScores'].each do |detectionScore|
				modelId = detectionScore['ModelId']
				if !modelIds.include?(modelId)
					raise Exception.new("Model not found; ModelId: " + modelId.to_s)
				end
				if detectionScore['DetectionScore'] == nil
					next
				end
				# create new detection for this {frame, model} pair
				if videoDetectionsHash[modelId].frame_detections.create(
					video_frame_id: video_frame.id,
					frame_score: detectionScore['DetectionScore'].to_f)
				else
					raise Exception.new("Frame detection create failed; ModelId: " + 
						modelId.to_s + "; videoFrameId: " + video_frame.id)
				end
			end
		end
		return true
	end

	def populateModelAlbumResult(resultModelId, resultAlbumType, resultJSON)
		modelId = resultJSON['ModelAlbumResult']['ModelId']
		albumType = resultJSON['ModelAlbumResult']['Album']
		imageScores = resultJSON['ModelAlbumResult']['ImageScores']
		# check basic errors:
		if (resultModelId != modelId) || 
			(resultAlbumType != albumType) || 
			(imageScores.count <= 0)
			raise Exception.new("JSON doesn't match function signature")
		end
		# update all scores from JSON:
		model = Model.find(modelId)
		imageScores.each do |is|
			image_tags = model.image_tags.where(image_id: is['ImageId']).where(usage: albumType)
			# if supplied image is not present in album, raise exception:
			if image_tags.count <= 0
				raise Exception.new("Image not found in album; ImageId: " + is['ImageId'].to_s)
			end
			# update image:
			image_tags.find_each do |image_tag|
				if image_tag.update(detection_score: is['DetectionScore'].to_f)
				else
					raise Exception.new("Database update failed; ImageID: " + is['ImageId'].to_s)
				end
				puts "Updating image_tag: " + image_tag.id.to_s
			end
		end
		# ensure that all image in album have been updated
		model.image_tags.where(usage: albumType).find_each do |image_tag|
			if image_tag.detection_score == nil
				raise Exception.new("Some image in album were not scored; ImageID: " + 
					image_tag.image_id.to_s)
			end
		end
		return true
	end

end
