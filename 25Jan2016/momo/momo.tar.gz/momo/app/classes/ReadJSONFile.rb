# Class to read JSON files.
class ReadJSONFile

	def getJSONFromModelBucket(modelId, fileName)
		if Rails.env.local?
			@bucketName = nil
			@keyName = 'tmp/' + fileName
		else
			@bucketName = S3HOSTBUCKETMODEL
			@keyName = "uploads/" + modelId.to_s + "/" + fileName
		end
		return getJSON()
	end

	def getJSONFromVideoBucket(videoId, fileName)
		if Rails.env.local?
			@bucketName = nil
			@keyName = 'tmp/' + fileName
		else
			@bucketName = S3HOSTBUCKETVIDEO
			@keyName = "uploads/" + videoId.to_s + "/" + fileName
		end
		return getJSON()
	end

	def getJSON
		# if no bucketname provided, try to read from local file system
		if @bucketName == nil
			return ActiveSupport::JSON.decode(File.read(@keyName))
		else
			s3 = AWS::S3.new(
				:access_key_id => YAML.load_file("#{Rails.root}/config/passwords.yml")[Rails.env]["aws_access_key_id"],
				:secret_access_key => YAML.load_file("#{Rails.root}/config/passwords.yml")[Rails.env]["aws_secret_access_key"])
			bucket = s3.buckets[@bucketName]
			return ActiveSupport::JSON.decode(bucket.objects[@keyName].read)
		end
	end
end
