# Class to read write JSON file from database content.
class WriteJSONFile
	def initialize(fullPathFilename, json)
		File.open(fullPathFilename,"w") do |f|
	    f.write(json)
	  end
	end
end