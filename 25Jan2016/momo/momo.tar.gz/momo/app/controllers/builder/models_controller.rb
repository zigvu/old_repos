require 'ReadJSONFile'
require 'PopulateDatabaseFromJSON'

module Builder
	class ModelsController < ApplicationController
		include ApplicationHelper
		
		before_filter :authenticate_user!
		skip_before_filter :verify_authenticity_token
		before_action :set_model, only: [:updateModelParam, :updateScoreFromFile, :updateScore, :getImages, :show, :update]
    
		respond_to :json

		def updateModelParam
			if params[:accuracy]
				if @model.update(accuracy: params[:accuracy].to_f)
					render json: {update_status: "success"}.to_json
				else
					render json: {update_status: "failure: database update failed"}.to_json
				end
			end

			if params[:threshold]
				if @model.update(threshold: params[:threshold].to_f)
					render json: {update_status: "success"}.to_json
				else
					render json: {update_status: "failure: database update failed"}.to_json
				end
			end
		end

		def updateScoreFromFile
			filename = params['filename']
			resultAlbumType = params['album']
			jsonReader = ReadJSONFile.new
			databasePopulator = PopulateDatabaseFromJSON.new
			# handle exceptions:
			begin
				resultJSON = jsonReader.getJSONFromModelBucket(@model.id, filename)
				databasePopulator.populateModelAlbumResult(@model.id, resultAlbumType, resultJSON)
				render json: {update_status: "success"}.to_json
			rescue Exception => e
				render json: {update_status: "failure: update failed: " + e.message}.to_json
			end
		end

		def updateScore
			# update only test images and imagebank for now:
			image_tags = @model.image_tags.where(image_id: params['image_id'])
				.where(usage: [ImageTag::TEST_POS, ImageTag::TEST_NEG, ImageTag::IMAGEBANK])
			detection_score = params['score'].to_f
			failure = false

			image_tags.map do |image_tag|
				if image_tag.update(detection_score: detection_score)
				else
					failure = true
					break
				end
			end

			if failure
				render json: {update_status: "failure: database update failed"}.to_json
			else
				render json: {update_status: "success"}.to_json
			end
		end

		def getImages
			@album = params['album']
			@images = @model.getImagesUserUsageTag(nil, @album, nil)
		end

		def index
			@models = Model.where(buildstatus: 'build-queue')
			render json: @models.as_json(only: [:id, :name, :algorithm])
		end

		def show
			@status = modelGetStatus(@model.buildstatus)
			@progress = modelGetProgress(@model.buildstatus)
			@TRAIN_POS_COUNT = @model.getImagesUserUsageTag(nil, ImageTag::TRAIN_POS, nil).count
			@TRAIN_NEG_COUNT = @model.getImagesUserUsageTag(nil, ImageTag::TRAIN_NEG, nil).count
			@TEST_POS_COUNT = @model.getImagesUserUsageTag(nil, ImageTag::TEST_POS, nil).count
			@TEST_NEG_COUNT = @model.getImagesUserUsageTag(nil, ImageTag::TEST_NEG, nil).count
			@IMAGEBANK_COUNT = @model.getImagesUserUsageTag(nil, ImageTag::IMAGEBANK, nil).count
		end

		def update
			oldStatusProgress = @model.buildstatus

			if params[:status]
				if params[:status] == "build-failure"
					oldProgress = modelGetProgress(oldStatusProgress)
					error = "#{params[:error]} (progress: #{oldProgress} %)"
					if @model.update(buildstatus: params[:status], error: error)
						render json: {update_status: "success"}.to_json
					else
						render json: {update_status: "failure: database update failed"}.to_json
					end
				elsif params[:status] == "build-complete"
					if @model.update(buildstatus: params[:status])
						render json: {update_status: "success"}.to_json
					else
						render json: {update_status: "failure: database update failed"}.to_json
					end
				else
					buildstatus = modelSetStatus(oldStatusProgress, params[:status])
					if @model.update(buildstatus: buildstatus)
						render json: {update_status: "success"}.to_json
					else
						render json: {update_status: "failure: database update failed"}.to_json
					end
				end
			end

			if params[:progress]
				buildstatus = modelSetProgress(oldStatusProgress, params[:progress])
				if @model.buildstatus == "build-complete"
					# do nothing - since the model is built
				elsif @model.update(buildstatus: buildstatus)
					render json: {update_status: "success"}.to_json
				else
					render json: {update_status: "failure: database update failed"}.to_json
				end
			end
		end

		private

		def set_model
			# hack because routes can either send :id or :model_id
			paramId = params[:id] != nil ? params[:id] : params[:model_id]
			@model = Model.find(paramId)
			if !@model.isModelCheckedout?(User.getBuilderId)
				render json: {update_status: "failure: model is not checked out to builder"}.to_json
				return
			end
		end
	end
end