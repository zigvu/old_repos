module Builder
	class ReleasesController < ApplicationController
		include ApplicationHelper
		
		before_filter :authenticate_user!
		skip_before_filter :verify_authenticity_token
		before_action :set_release, only: [:show, :update]
    
		respond_to :json

		def getDefaultRelease
			@user = current_user
			# TODO: replace later with @user
			admin = User.where(username: "admin").first
			releaseId = admin.user_setting.release_id
			if releaseId == nil
				release = Release.first
			else
				release = Release.find(releaseId)
			end
			rh = Services::ReleasesHandler.new(release)
			render json: rh.getReleaseTree.to_json
		end

		def index
			@releases = Release.where(buildstatus: Release::BUILDSTATE[:build_queue])
			render json: @releases.as_json(only: [:id, :name, :S3_URL])
		end

		def show
			releaseHanlder = Services::ReleasesHandler.new(@release)
			render json: releaseHanlder.release_mapping_hash.to_json
		end

		def update
			if params[:status]
				if @release.update(buildstatus: params[:status])
					render json: {update_status: "success"}.to_json
				else
					render json: {update_status: "failure: database update failed"}.to_json
				end
			end
		end

		private
			def set_release
				#hack because routes can either send :id or :model_id
				paramId = params[:id] != nil ? params[:id] : params[:release_id]
				@release = Release.find(paramId)
			end
	end
end