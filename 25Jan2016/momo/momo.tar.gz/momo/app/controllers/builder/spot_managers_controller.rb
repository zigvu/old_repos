module Builder
	class SpotManagersController < ApplicationController
		include ApplicationHelper
		
		before_filter :authenticate_user!
		skip_before_filter :verify_authenticity_token
		respond_to :json

		def index
			@modelSpotManager = SpotManager.where(task: SpotManager::TASK[:model]).last
			@videoSpotManager = SpotManager.where(task: SpotManager::TASK[:video]).last

			@spotManagers = [@modelSpotManager, @videoSpotManager]

			# return spot manager current configuration
			render json: @spotManagers.as_json(only: 
				[:id, :instance_type, :price, :task, :num_instance, :idle_time, :failure_behavior])
		end

	end
end