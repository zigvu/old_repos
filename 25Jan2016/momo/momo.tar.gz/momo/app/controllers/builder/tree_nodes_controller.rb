module Builder
	class TreeNodesController < ApplicationController
    include ApplicationHelper

    before_filter :authenticate_user!
    skip_before_filter :verify_authenticity_token
		respond_to :json

		def getLatestModel
			@treenode = TreeNode.find(params[:tree_node_id])
			@model = @treenode.models.where(buildstatus: "build-complete").order(id: :asc).last
			render json: @model.as_json(only: 
				[:id, :name, :model_version, :algorithm, 
					:accuracy, :threshold, :model_type])
		end

		def index
			@treenodes = TreeNode.first.getAllChildrenNodeJSON
			render json: @treenodes.as_json
		end

		def show
			@treenode = TreeNode.find(params[:id])
			render json: @treenode.as_json(only: [:id, :name, :description, :comment])
		end
	end
end