require 'ReadJSONFile'
require 'PopulateDatabaseFromJSON'

module Builder
	class VideosController < ApplicationController
		include ApplicationHelper
		
		before_filter :authenticate_user!
		skip_before_filter :verify_authenticity_token
		respond_to :json

		def evaluateQueueLength
			videoLengthArray = Video
				.where(videotask: [Video::VIDEOTASK[:evaluateQueue], 
					Video::VIDEOTASK[:evaluateCurrent]])
				.pluck(:length)
			videoLength = 0
			nilVideoLengthError = false
			videoLengthArray.each do |vl|
				if vl != nil
					videoLength = videoLength + vl
				else
					nilVideoLengthError = true
				end
			end
			if nilVideoLengthError
				render json: {status: "failure: length of at least one video is nil"}.to_json
			else
				render json: {evaluate_queue_length: videoLength}.to_json
			end
		end

		def videoFrame
			@video = Video.find(params[:video_id])
			@video_frame = @video.video_frames.where(frame_position: params[:frame_position].to_i).first
			if @video_frame != nil
				@model = Model.find(params[:model_id])
				model_json = @model.as_json(only: [:id, :name, :algorithm])
				@video_json = @video.as_json(only: [:id, :videotask]).merge(:model => model_json)
				@video_frame_json = @video_json.merge(:videoframe => @video_frame.as_json(only: [:id, :S3_URL]))
				render json: @video_frame_json
			else
				render json: {update_status: "failure: frame does not exist"}.to_json
			end
		end

		def evaluateUpdateFromFile
			filename = params['filename']
			@video = Video.find(params[:video_id])
			jsonReader = ReadJSONFile.new
			databasePopulator = PopulateDatabaseFromJSON.new
			# handle exceptions:
			begin
				resultJSON = jsonReader.getJSONFromVideoBucket(@video.id, filename)
				databasePopulator.populateVideoAnalysisResult(@video.id, resultJSON)
				render json: {update_status: "success"}.to_json
			rescue Exception => e
				render json: {update_status: "failure: update failed: " + e.message}.to_json
			end
		end

		def videoFrameUpdate
			status = "failure"
			@video = Video.find(params[:video_id])
			@video_detection = @video.video_detections.where(model_id: params[:model_id]).first
			if @video_detection != nil
				if @video_detection.classification == VideoDetection::CLASSIFICATION[:evaluateCurrent]
					@video_frame = @video.video_frames.
						create_with(S3_URL: params[:S3_URL].to_s).
						find_or_create_by(frame_position: params[:frame_position].to_i)

					# now store the scores
					# prevent duplicate scores for same frame/model:
					if FrameDetection.where(video_detection_id: @video_detection.id).
						where(video_frame_id: @video_frame.id).count <= 0
						if @video_detection.frame_detections.create(
							video_frame_id: @video_frame.id,
							frame_score: params[:frame_score].to_f,
							cumulative_score: params[:cumulative_score].to_f,
							classification: params[:classification])
							# update status
							status = "success"
						else
							status = "failure: database update failed"
						end
					else
						status = "failure: frame detection for model already exists"
					end
				else
					status = "failure: video detection task state is not in-progress"
				end
			else
				status = "failure: video detection task not found"
			end

			# at the end, render json:
			render json: {update_status: status}.to_json
		end

		def inspect
			@video = Video.find(params[:video_id])
			if @video.videotask == Video::VIDEOTASK[:inspectQueue]
				render json: @video.as_json(only: [:id, :videotask]).merge(:S3_URL => @video.upload.url)
			else
				render json: {update_status: "failure: video task is not inspect"}.to_json
			end
		end

		def inspectUpdate
			status = "failure"
			@video = Video.find(params[:video_id])
			if params[:status] == Video::VIDEOTASK[:inspectCurrent]
				if @video.update(videotask: Video::VIDEOTASK[:inspectCurrent])
					status = "success"
				else
					status = "failure: database update failed"
				end
			elsif params[:status] == Video::VIDEOTASK[:inspectSuccess]
				if @video.update(videotask: Video::VIDEOTASK[:inspectSuccess],
					videostatus: Video::VIDEOSTATUS[:s3ready],
					quality: params[:quality],
					format: params[:videoformat],
					length: params[:length].to_i,
					size: params[:size].to_i,
					title: params[:title],
					description: params[:description],
					upload_file_size: params[:size].to_i)

					if @video.title == ""
						@video.update(title: "Please type in new title...")
					end

					# set status
					status = "success"
				else
					status = "failure: database update failed"
				end
			elsif params[:status] == Video::VIDEOTASK[:inspectFail]
				# inform end-user that inspect has failed
				if @video.update(videotask: Video::VIDEOTASK[:inspectFail],
					error: params[:error])
					# inform backend that failure is registered
					status = "success"
				else
					status = "failure: database update failed"
				end
			else
				status = "failure: unrecognized video task"
			end

			# at the end, render json:
			render json: {update_status: status}.to_json
		end

		def upload
			@video = Video.find(params[:video_id])
			if @video.videotask == Video::VIDEOTASK[:uploadQueue]
				render json: @video.as_json(only: [:id, :videotask, :source_type, :file_source])
			else
				render json: {update_status: "failure: video task is not upload"}.to_json
			end
		end

		def uploadUpdate
			status = "failure"
			@video = Video.find(params[:video_id])
			if params[:status] == Video::VIDEOTASK[:uploadCurrent]
				if @video.update(videotask: Video::VIDEOTASK[:uploadCurrent])
					status = "success"
				else
					status = "failure: database update failed"
				end
			elsif params[:status] == Video::VIDEOTASK[:uploadSuccess]
				if @video.update(videotask: Video::VIDEOTASK[:inspectQueue])
					if !Rails.env.local?
						# update paperclip:
						@video.upload_from_S3_url(params[:S3_URL].to_s)
						@video.save
					end

					status = "success"
				else
					# send database error back
					status = "failure: database update failed"
				end
			elsif params[:status] == Video::VIDEOTASK[:uploadFail]
				if @video.update(videotask: Video::VIDEOTASK[:uploadFail],
					error: params[:error])
					status = "success"
				else
					status = "failure: database update failed"
				end
			else
				status = "failure: unrecognized video task"
			end

			# at the end, render json:
			render json: {update_status: status}.to_json
		end

		def evaluate
			@video = Video.find(params[:video_id])
			if @video.videotask == Video::VIDEOTASK[:evaluateQueue]
				models_json = @video.getModelsInVideoDetectionState(VideoDetection::CLASSIFICATION[:evaluateQueue]).as_json(only: [:id])
				render json: @video.as_json(only: [:id, :videotask]).merge(:models => models_json)
			else
				render json: {update_status: "failure: video task is not evaluate"}.to_json
			end
		end

		def evaluateModel
			@video = Video.find(params[:video_id])
			if @video.isModelInVideoDetectionState?(params[:model_id], 
				VideoDetection::CLASSIFICATION[:evaluateQueue])
				# set model
				@model = Model.find(params[:model_id])
				if @video.videotask == Video::VIDEOTASK[:evaluateQueue]
					model_json = @model.as_json(only: [:id, :name, :algorithm])
					render json: @video.as_json(only: [:id, :videotask]).merge(:model => model_json)
				else
					render json: {update_status: "failure: video task is not evaluate"}.to_json
				end
			else
				render json: {update_status: "failure: model is not in evaluation state"}.to_json
			end
		end

		def evaluateModelUpdate
			status = "failure"
			@video = Video.find(params[:video_id])
			if @video.videotask != Video::VIDEOTASK[:evaluateFail] &&
				@video.isModelInVideoDetectionState?(params[:model_id], 
				VideoDetection::CLASSIFICATION[:evaluateQueue])
				# start evaluation on current {video, model} pair
				if params[:status] == Video::VIDEOTASK[:evaluateCurrent]
					# update video detection table:
					@video.setModelVideoDetection(params[:model_id], 
						VideoDetection::CLASSIFICATION[:evaluateCurrent], nil)
					status = "success"

					# if this is the last {video, model} pair, then update the video task
					if @video.getModelsInVideoDetectionState(VideoDetection::CLASSIFICATION[:evaluateQueue]).count <= 0 &&
						!@video.update(videotask: Video::VIDEOTASK[:evaluateCurrent])
						status = "failure: database update failed"
					end
				else
					status = "failure: unrecognized video task"
				end

			elsif @video.isModelInVideoDetectionState?(params[:model_id], 
				VideoDetection::CLASSIFICATION[:evaluateCurrent])
				# if success
				if params[:status] == Video::VIDEOTASK[:evaluateSuccess]
					@video.setModelVideoDetection(params[:model_id],
						params[:classification],
						params[:score].to_f)

					status = "success"
					# if no model is in queue or in progress,
					# transition video state to evaluate-success
					# however, if video is already in error state, don't change the state
					if @video.videotask != Video::VIDEOTASK[:evaluateFail] &&
						@video.getModelsInVideoDetectionState(VideoDetection::CLASSIFICATION[:evaluateQueue]).count <= 0 &&
						@video.getModelsInVideoDetectionState(VideoDetection::CLASSIFICATION[:evaluateCurrent]).count <= 0 &&
						!@video.update(videotask: Video::VIDEOTASK[:evaluateSuccess])
						status = "failure: database update failed"
					end
				elsif params[:status] == Video::VIDEOTASK[:evaluateFail]
					# video task has failed
					if @video.setModelVideoDetection(params[:model_id], 
						VideoDetection::CLASSIFICATION[:evaluateFail], nil) && 
						@video.update(videotask: Video::VIDEOTASK[:evaluateFail],
							error: params[:error])
						# ack receipt
						status = "success"
					else
						status = "failure: database update failed"
					end
				else
					status = "failure: unrecognized model evaluation status"
				end	
			else
				status = "failure: unknown model evaluation state"
			end

			# at the end, render json:
			render json: {update_status: status}.to_json
		end

		def index
			@videos = Video.where(videotask: 
				[Video::VIDEOTASK[:inspectQueue],
				Video::VIDEOTASK[:uploadQueue],
				Video::VIDEOTASK[:evaluateQueue]])

			# return all tasks in queue
			render json: @videos.as_json(only: [:id, :videotask])
		end

		def show
			@video = Video.find(params[:id])
		end

		def update
		end
	end
end