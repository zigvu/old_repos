require 'uri'

class ImagesController < ApplicationController
  skip_before_filter :verify_authenticity_token, only: [:uploadFromKheer]
  before_filter :authenticate_user!, except: [:uploadFromAddon ]
  before_action :set_image, only: [:show, :edit, :update, :destroy]
  before_action :set_model_album, only: [:uploadFromLocal, :dragDropFromWeb, :pasteFromVideo, :create]

  # POST /images/uploadFromAddon
  def uploadFromKheer
    # make sure user is logged in
    if current_user == nil
      retJSON = {Error: "User not signed in"}
    else
      @user = current_user
      retJSON = {}
      @model = Model.where(checkout_user: @user.id).first
      if @model == nil
        retJSON.merge!({Error: "No model checked out"})
      else
        if params['kheerUpload']
          # save from kheer
          uploadedFile = params['kheerUpload']
          tempFileLocation = uploadedFile.path
          createImageFromURL(tempFileLocation, ImageTag::CLIPBOARD, @model, @user)
          retJSON.merge!({Status: "Saved image file"})
        else
          retJSON.merge!({Error: "Unknown parameter in request"})
        end
      end
    end

    respond_to do |format|
      format.json { render json: retJSON.to_json }
    end
  end

  # GET /images/uploadFromAddon
  def uploadFromAddon
    # make sure user is logged in
    if current_user == nil
      retJSON = {Error: "User not signed in"}
    else
      @user = current_user
      retJSON = {User: @user.id}

      # Make sure a model is checked out
      @model = Model.where(checkout_user: @user.id).first
      if @model == nil
        retJSON.merge!({Error: "No model checked out"})
      else
        retJSON.merge!({Model: @model.id})
        if params['addonAction'] == 'test'
          # no additional info to send right now
        elsif params['addonAction'] == 'link'
          # save image file to clipboard
          addonLink = URI.escape(URI.unescape(params['addonLink']))
          createImageFromURL(addonLink, ImageTag::CLIPBOARD, @model, @user)
          retJSON.merge!({Status: "Saved image file"})
        else
          retJSON.merge!({Error: "Unknown parameter in request"})
        end
      end
    end

    respond_to do |format|
      format.json { render json: retJSON.to_json }
    end
  end

  # GET /images/uploadFromLocal
  def uploadFromLocal
    @file_source = 'uploadFromLocal'
  end

  # GET /images/dragDropFromWeb
  def dragDropFromWeb
    respond_to do |format|
      format.html
      format.js {
        createImageFromURL(params['imgUrl'], @album_type, @model, @user)
        @numOfImagesInAlbum = @model.getImagesUserUsageTag(@user_id, @album_type, nil).count
      }
    end
  end

  # GET /images/pasteFromVideo
  def pasteFromVideo
    @file_source = 'pasteFromVideo'

    @videoFrames = VideoFrame.includes(:video_frame_tags).where(video_frame_tags: {user_id: @user.id, usage: ImageTag::CLIPBOARD})
    @clipboardCount = @videoFrames.count
    @viewingClipboard = true
    @viewingVideoClipboardFromImage = true

    buttonType = params[:button_type]
    respond_to do |format|
      format.html {
        if buttonType == "pasteClipboardToAlbum"
          @videoFrames.find_each do |videoFrame|
            # copy each frame to S3 and create appropriate image tags:
            createImageFromURL(videoFrame.getURL, @album_type, @model, @user)
          end
          # remove from video clipboard
          VideoFrameTag.where(user_id: @user.id).where(usage: [ImageTag::TEMP, ImageTag::CLIPBOARD]).destroy_all
          redirect_to addImages_model_path(@model), notice: "Clipboard pasted"
        end
      }
      format.js { }
    end

  end

  # GET /images
  # GET /images.json
  def index
    #@images = Image.all
    @images = []

    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @images.map{|image| image.to_jq_upload } }
    end
  end

  # GET /images/1
  # GET /images/1.json
  def show
    respond_to do |format|
      format.html # show.html.erb
      format.json { render json: @image }
    end
  end

  # GET /images/new
  def new
    @image = Image.new

    respond_to do |format|
      format.html # new.html.erb
      format.json { render json: @image }
    end
  end

  # GET /images/1/edit
  def edit
  end

  # POST /images
  # POST /images.json
  def create
    @image = Image.new(image_params.except(:album_type, :model_id))
    @image.user_id = @user.id

    respond_to do |format|
      if @image.save
        format.html {
          # save image tag:
          @image.image_tags.create(usage: @album_type, model_id: @model.id, user_id: @user.id)

          # also set that this image is uncategorized right now
          if @album_type == ImageTag::TRAIN_POS || @album_type == ImageTag::TEST_POS
            mtt = @model.getIdOfUnassignedModelTextTag
            @image.image_tags.create(usage: ImageTag::TEXT, model_id: @model.id, user_id: @user.id, model_text_tag_id: mtt)
          end

          render :json => [@image.to_jq_upload].to_json,
          :content_type => 'text/html',
          :layout => false
        }
        format.json { 
          # save image tag:
          @image.image_tags.create(usage: @album_type, model_id: @model.id, user_id: @user.id)

          # also set that this image is uncategorized right now
          if @album_type == ImageTag::TRAIN_POS || @album_type == ImageTag::TEST_POS
            mtt = @model.getIdOfUnassignedModelTextTag
            @image.image_tags.create(usage: ImageTag::TEXT, model_id: @model.id, user_id: @user.id, model_text_tag_id: mtt)
          end

          render json: {files: [@image.to_jq_upload]}, status: :created, location: @image 
        }
      else
        format.html { render action: "new" }
        format.json { render json: @image.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /images/1
  # PATCH/PUT /images/1.json
  def update
    respond_to do |format|
      if @image.update(image_params.except(:album_type, :model_id))
        format.html { redirect_to @image, notice: 'Image was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @image.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /images/1
  # DELETE /images/1.json
  def destroy
    @image.destroy
    respond_to do |format|
      format.html { redirect_to images_url }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def createImageFromURL(url, usage, model, user)
      if url != nil
        image = Image.new
        image.upload_from_url(url)
        image.user_id = user.id

        puts image.upload_content_type
        #if image.upload_content_type.include?("image")
          # save image:
          if image.save
            image.image_tags.create(usage: usage, model_id: model.id, user_id: user.id)

            # also set that this image is uncategorized right now
            if usage == ImageTag::TRAIN_POS || usage == ImageTag::TEST_POS
              mtt = model.getIdOfUnassignedModelTextTag
              image.image_tags.create(usage: ImageTag::TEXT, model_id: model.id, user_id: user.id, model_text_tag_id: mtt)
            end
          end
        #end
      end
    end

    def set_image
      @image = Image.find(params[:id])
    end

    def set_model_album
      @user = current_user
      
      if params[:model_id] != nil
        model_id = params[:model_id]
      elsif params[:image][:model_id] != nil
        model_id = params[:image][:model_id]
      end        
      @model = Model.find(model_id)

      if params[:album_type] != nil
        @album_type = params[:album_type]
      elsif params[:image][:album_type] != nil
        @album_type = params[:image][:album_type]
      end

      @addingImagesToModel = true

      @numOfImagesInAlbum = @model.getImagesUserUsageTag(@user_id, @album_type, nil).count
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def image_params
      params.require(:image).permit(:upload, :file_source, :medium_filepath, :user_id, :album_type, :model_id)
    end
end
