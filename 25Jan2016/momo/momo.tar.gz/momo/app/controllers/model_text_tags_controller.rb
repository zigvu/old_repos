class ModelTextTagsController < ApplicationController
  before_action :set_model_text_tag, only: [:show, :edit, :update]

  # GET /model_text_tags
  # GET /model_text_tags.json
  def index
    @model_text_tags = ModelTextTag.all
  end

  # GET /model_text_tags/1
  # GET /model_text_tags/1.json
  def show
  end

  # GET /model_text_tags/new
  def new
    @model_text_tag = ModelTextTag.new
  end

  # GET /model_text_tags/1/edit
  def edit
  end

  # POST /model_text_tags
  # POST /model_text_tags.json
  def create
    @model = Model.find(params[:model_text_tag][:model_id])
    @model_text_tag = ModelTextTag.new(model_text_tag_params)
    @model_text_tag.user_id = current_user.id
    @model_text_tag.model_id = @model.id

    if @model_text_tag.save
      redirect_to model_path(@model), notice: 'Text tag was successfully created.'
    else
      redirect_to model_path(@model), alert: 'Text tag could not be saved - is it empty?'
    end
  end

  # PATCH/PUT /model_text_tags/1
  # PATCH/PUT /model_text_tags/1.json
  def update
    respond_to do |format|
      if @model_text_tag.update(model_text_tag_params)
        format.html { redirect_to @model_text_tag, notice: 'Model text tag was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @model_text_tag.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /model_text_tags/1
  # DELETE /model_text_tags/1.json
  def destroy
    @model = Model.find(params[:model_id])
    @model_text_tag = ModelTextTag.find(params[:id])

    # delete related text tags - although this happens automatically
    # due to dependent destroy, the uncategorized tags are not deleted,
    # hence need this extra step
    @model.deleteModelTextTag(current_user, @model_text_tag)

    @model_text_tag.destroy
    redirect_to model_path(@model), notice: 'Text tag was successfully deleted. No images were deleted'
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_model_text_tag
      @model_text_tag = ModelTextTag.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def model_text_tag_params
      params.require(:model_text_tag).permit(:tag, :model_id)
    end
end
