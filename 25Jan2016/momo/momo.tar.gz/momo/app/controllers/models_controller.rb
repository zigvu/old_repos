class ModelsController < ApplicationController
    include ApplicationHelper

    before_filter :authenticate_user!
    before_action :set_model, only: [:show, :buildAndTestModel, :addImages, :viewImages, :buildNewVersion, :finalizeNewModel, :finalizeNodeTree, :selectNodeChild, :update, :destroy]
    before_action :clear_viewImages_session, except: [:viewImages, :set_model, :model_params]

    # GET /models/:id/rerunModelTasks
    def rerunModelTasks
        @model = Model.find(params[:id])
        failureType = params[:failure]

        status = "Unknown failure"
        if failureType == "build-failure"
            # reset all image tags scores:
            @model.image_tags.find_each do |imt|
                imt.update(detection_score: nil)
            end

            if @model.update(accuracy: 0.0,
                buildstatus: "build-queue",
                threshold: 0.0,
                modelpath: "FileNotFoundString",
                checkout_user: User.getBuilderId,
                error: nil)
                status = "Model build task for model id #{@model.id} updated"
            end
        else
            status = "Unknown failure type or database update failed"
        end
        redirect_to users_admin_path, notice: status
    end
    
    # GET /models
    def index
        @user = current_user
        @models = Model.where("name != ?", ImageTag::IMAGEBANK)

        @models.find_each do |model|
            if model.isModelCheckedout?(@user.id)
                @checkedOutModel = model
                break
            end
        end

        respond_to do |format|
            format.html
            format.json { 
                render json: [TreeNode.getJSONForSelectionTable(@user, 
                    @models, nil, TreeNode::JSONUSAGE[:modelIndex])].to_json 
            }
        end
    end

    # GET /models/1
    def show
        # handle checkout/checkin button:
        if params['userCheckOutAction'] == 'checkin'
            @model.modelCheckin(@user.id)
            redirect_to models_path, notice: "Checked in model #{@model.name}:v#{@model.model_version}"
            return
        elsif params['userCheckOutAction'] == 'checkout'
            @model.modelCheckout(@user.id)
            # force redirect:
            redirect_to model_path(@model), notice: "Checked out model #{@model.name}:v#{@model.model_version}"
            return
        end

        @nodeParents = @model.getNodeParents
        @model_text_tag = ModelTextTag.new

    end

    def buildAndTestModel
        mtt = @model.getIdOfUnassignedModelTextTag
        @numOfUnassignedImages = @model.getImagesUserUsageTag(nil, ImageTag::TEXT, mtt).count

        buttonType = params['button_type']
        if buttonType == 'startBuildingModel'
            # don't start twice by accident:
            if @model.buildstatus == 'pre-build'
                @model.modelCheckin(@user.id)
                # builder is user zero for now
                @model.modelCheckout(User.getBuilderId)
                if @model.isModelCheckedout?(User.getBuilderId)
                    # upon success, change build status
                    @model.setBuildStatus('build-queue')
                else
                    redirect_to model_path(@model), alert: "Could not start build of model #{@model.name}:v#{@model.model_version}"
                end
            end
        end

        @buildStatus = modelGetStatus(@model.buildstatus).split('-').map(&:capitalize).join(' ')
        @buildProgress = modelGetProgress(@model.buildstatus)

        respond_to do |format|
            format.html {}
            format.js {
                @modelBuildingComplete = false
                if buttonType == 'progressBarUpdateRequest'
                    @buildStatus = modelGetStatus(@model.buildstatus).split('-').map(&:capitalize).join(' ')
                    @buildProgress = modelGetProgress(@model.buildstatus)

                    # exit from loop after build is complete
                    if @model.buildstatus == "build-complete"
                        @modelBuildingComplete = true
                        # checkin model so that further writes are not possible
                        @model.modelCheckin(User.getBuilderId)
                        flash[:notice] = "Finished building model #{@model.name}:v#{@model.model_version}"
                    end

                    # exit from loop after error in build process
                    if @model.buildstatus == "build-failure"
                        @modelBuildingComplete = true
                        # checkin model so that further writes are not possible
                        @model.modelCheckin(User.getBuilderId)
                        flash[:alert] = "Error during building model #{@model.name}:v#{@model.model_version}"
                    end
                end
            }
        end
    end

    # GET /models/1/addImages
    def addImages
        @addingImagesToModel = true
    end

    # GET /models/1/viewImages
    def viewImages

        if params['album_type'] != nil
            session[:album_type] = params['album_type']
            # reset temp image counter:
            @model.unsetTempAllImages(@user)
        end
        @album_type = session[:album_type] || ImageTag::TRAIN_POS

        if params['thumbnailImageSize'] != nil
            session[:thumbnailImageSize] = params['thumbnailImageSize']
        end
        @thumbnailImageMedium = (session[:thumbnailImageSize] == 'thumbnailImageMedium')? true : false

        @textTagAlbumId = nil
        if @album_type == ImageTag::TEXT
            if params['text_tag_id'] != nil
                session[:text_tag_id] = params['text_tag_id']
            end
            @textTagAlbumId = session[:text_tag_id]
            @textTagAlbum = ModelTextTag.find(@textTagAlbumId)
        end

        if @album_type == ImageTag::CLIPBOARD
            @imagesWithoutPagination = @model.getImagesUserUsageTag(@user, @album_type, @textTagAlbumId)
        elsif   @album_type == ImageTag::TP || 
                @album_type == ImageTag::FN || 
                @album_type == ImageTag::FP || 
                @album_type == ImageTag::TN ||
                @album_type == ImageTag::IMAGEBANK
            # basic error checking - if model is not built, these pages shouldn't be
            # accessible
            if !@model.isModelBuilt?
                redirect_to viewImages_model_path(album_type: ImageTag::TRAIN_POS), notice: "Model not built. Hence, cannot show #{@album_type.capitalize} album" 
                return
            end
            @imagesWithoutPagination = @model.getImagesPostAnalysis(@album_type)
        else
            @imagesWithoutPagination = @model.getImagesUserUsageTag(nil, @album_type, @textTagAlbumId)
        end

        # Set up pagination
        if params['imagePerPage'] != nil
            session[:per_page] = params['imagePerPage']
        end
        @per_page = session[:per_page] || Image.per_page
        @images = @imagesWithoutPagination.paginate(page: params[:page], per_page: @per_page)

        # Handle button clicks
        buttonType = params['button_type']
        respond_to do |format|
            format.html {
                if buttonType == "deleteSelectedImages"
                    @model.unsetClickedImageTags(@user, @album_type, @textTagAlbumId)

                    redirect_to viewImages_model_path(album_type: @album_type), notice: "Images removed from #{@album_type.capitalize} of this album. (But not from disk)" 
                end

                if buttonType == "pasteClipboardToAlbum"
                    @model.pasteClipboardImageTags(@user, @album_type, @textTagAlbumId)
                    @clipboardChanged = true
                end
            }
            format.js {
                # update individual image click
                if buttonType == "imageSingleClicked"
                    img = Image.find(params['image_id'])
                    if img != nil
                        @model.toggleSingleImageClicked(@user, img)

                        @imageClassTagToUpdate = params[:"data-update-target"]
                        @imageClassTagToUpdateClicked = img.hasTag?(@user.id, @model.id, ImageTag::TEMP, nil)
                    end
                end

                if buttonType == "setTempAllImageIdsInArray"
                    # get images in order of how they were displayed
                    imageSelectionStart = params[:imageSelectionStart].to_i
                    imageSelectionPerPage = params[:imageSelectionPerPage].to_i
                    imageIdArray = @imagesWithoutPagination
                        .pluck(:id)
                        .uniq[
                            imageSelectionStart..
                            (imageSelectionPerPage+imageSelectionStart-1)]
                    @model.setTempAllImageIdsInArray(@user, imageIdArray)
                    @setTempAllImageIdsInArray = true
                end

                if buttonType == "unsetTempAllImages"
                    @model.unsetTempAllImages(@user)
                    @unsetTempAllImages = true
                end

                if buttonType == "addSelectedToClipboard"
                    @model.setClickedImageTags(@user, ImageTag::CLIPBOARD, nil)
                    @unsetTempAllImages = true
                    @clipboardChanged = true
                end

                if buttonType == "removeSelectedFromClipboard"
                    @model.unsetClickedImageTags(@user, ImageTag::CLIPBOARD, nil)
                    @unsetTempAllImages = true
                    @clipboardChanged = true
                end

                if buttonType == "clickTextTag"
                    @textTag = ModelTextTag.find(params['clickTextTagID'])
                    @model.setClickedImageTags(@user, ImageTag::TEXT, @textTag.id)
                    @unsetTempAllImages = true
                    @clickTextTag = true
                end
            }
        end
    end

    # GET /models/1/buildNewVersion
    def buildNewVersion
        # first unset all temporary tags:
        ImageTag.where(usage: ImageTag::CLIPBOARD, user_id: @user.id).destroy_all
        ImageTag.where(usage: ImageTag::TEMP, user_id: @user.id).destroy_all

        # use deep_cloneable gem to duplicate:
        @newModel = @model.dup :include => [ :model_text_tags, { :image_tags => [ :model_text_tag ] } ], :use_dictionary => true
        @newModel.user_id = @user.id
        @newModel.model_version = @newModel.tree_node.models.last.model_version + 1
        @newModel.accuracy = 0
        @newModel.threshold = 0
        @newModel.checkout_user = nil
        @newModel.buildstatus = "pre-build"

        if @newModel.save
            redirect_to new_model_path(id: @newModel.id, new_model_step: '0_done'), notice: 'New model created.' 
        else
            redirect_to new_model_path, alert: 'Could not duplicate model, create new instead'
        end
    end

    # GET /models/new
    def new
        @modelStep0_done = false
        @modelStep1_done = false
        @modelStep2_done = false

        if params['new_model_step'] == '0_done'
            @modelStep0_done = true
        end
        if params['new_model_step'] == '1_done'
            @modelStep0_done = true
            @modelStep1_done = true
        end
        if params['new_model_step'] == '2_done'
            @modelStep0_done = true
            @modelStep1_done = true
            @modelStep2_done = true
        end

        if !@modelStep0_done
            @model = Model.new(name: "Unassigned", model_version: 0)
        else
            @model = Model.find(params[:id])

            @nodeParents = @model.getNodeParents
            @nodeChildren = @model.getNodeChildren
            @nodeChildrenHashForSelect = @model.getNodeChildrenHashForSelect
            @create_new = params['create_new']
            if @nodeChildren.count <= 0
                @create_new = 'yes'
            end
            @tree_node = TreeNode.new
            @model_text_tag = ModelTextTag.new
        end
    end

    # POST /models/finalizeNodeTree
    def finalizeNewModel
        curUserId = @user.id
        curModelId = @model.id

        # if this is not a duplicate model, then it will have only 1 sibling
        # in tree node and we should put in the image bank
        if @model.tree_node.models.count <= 1
            # at this point the new model is ready to be built
            # add in image bank images - for now, use all positive tagged images from bank
            Model.find_by(name: ImageTag::IMAGEBANK)
                .images
                .includes(:image_tags)
                .where(image_tags: {usage: ImageTag::TRAIN_POS})
                .find_each do |image|
                # no need to check for prior existence here because this is a new model:
                image.image_tags.create(user_id: curUserId, model_id: curModelId, usage: ImageTag::IMAGEBANK)
            end
        end

        redirect_to models_path, notice: "New model created! Please checkout the model for adding images."
    end

    # POST /models/finalizeNodeTree
    def finalizeNodeTree
        if @model.tree_node.models.count > 1
            # if tree_node already has model with the same version number, disallow
            redirect_to new_model_path(id: @model.id, new_model_step: '1_done', :create_new => 'no'), 
            alert: "A valid version of #{@model.tree_node.name} already exists. Please either (1) create new node or (2) discard this model and create new version of existing model."
        else
            # if all is well, assign name and be done with new model
            @model.name = @model.tree_node.name
            @model.save
            # also create an unassigned text tag:
            @model.model_text_tags.create(user_id: @user.id, tag: ModelTextTag::UNASSIGNED)

            redirect_to new_model_path(id: @model.id, new_model_step: '2_done'), 
                notice: "Node tree created for model."
        end
    end

    # POST /models/selectNodeChild
    def selectNodeChild
        @nodeChildren = @model.getNodeChildren
        @nodeChildrenHashForSelect = @model.getNodeChildrenHashForSelect
        child_selected = params['child_selected'].to_i
        # want a new node:
        if child_selected >= @nodeChildren.count
            redirect_to new_model_path(id: @model.id, new_model_step: '1_done', :create_new => 'yes')
        else
            @tree_node = @nodeChildren[child_selected]
            @model.addNewChildNode(@tree_node, current_user)
            redirect_to new_model_path(id: @model.id, new_model_step: '1_done', :create_new => 'no')
        end
    end

    # POST /models
    def create
        @model = Model.new(model_params)

        # rewrite model type and algorithm
        @model.model_type = Model.modelTypes[@model.model_type.to_i][0]
        @model.algorithm = Model.algorithms[@model.algorithm.to_i][0]
        @model.user = current_user

        if @model.save
            redirect_to new_model_path(id: @model.id, new_model_step: '1_done', :create_new => 'no'), notice: 'New model created.' 
        else
            render action: 'new'
        end
    end


    # PATCH/PUT /models/1
    def update
        if @model.update(model_params)
                # rewrite model type and algorithm
                @model.model_type = Model.modelTypes[@model.model_type.to_i][0]
                @model.algorithm = Model.algorithms[@model.algorithm.to_i][0]
                @model.user = current_user

                @model.save

                redirect_to new_model_path(id: @model.id, new_model_step: '2_done'), notice: 'Model update created.' 
        else
            render action: 'edit'
        end
    end

    # DELETE /models/1
    def destroy
        # delete orphaned images first:
        @model.images.find_each do |image|
            if image.models.count <= 1
                image.destroy
            end
        end
        @model.destroy
        redirect_to models_url
    end

    private
    # Use callbacks to share common setup or constraints between actions.
    def set_model
        @model = Model.find(params[:id])
        @user = current_user
    end

    # clear session information of viewImages
    def clear_viewImages_session
        session[:album_type] = nil
        session[:thumbnailImageSize] = nil
        session[:text_tag_id] = nil
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def model_params
        # same sequence as newModel_form file:
        params.require(:model).permit(:name, :model_version, :modelpath, :accuracy, :threshold, :buildstatus, :model_type, :algorithm, :comment)
    end
end
