class ReleasesController < ApplicationController
	before_filter :authenticate_user!

  before_action :set_release, only: [:show, :destroy]

  # GET /releases
  def index
  	@user = current_user
  	@releases = Release.all
  end

	# GET /releases/1
	def show
		@user = current_user
		releaseHanlder = Services::ReleasesHandler.new(@release)
		@models = Model
      .where(buildstatus: "build-complete")
      .where("name != ?", ImageTag::IMAGEBANK)
		@releasedModelIds = releaseHanlder.getModelIds
		@releasedNodeIds = releaseHanlder.getNodeIds

		respond_to do |format|
      format.html
      format.json { 
          render json: [TreeNode.getJSONForSelectionTable(@user, @models, nil, TreeNode::JSONUSAGE[:releaseShow], @releasedModelIds, @releasedNodeIds)].to_json 
      }
    end
	end

	# GET /releases/new
	def new
		@release = Release.new
		@user = current_user
    @models = Model
      .where(buildstatus: "build-complete")
      .where("name != ?", ImageTag::IMAGEBANK)
    respond_to do |format|
      format.html
      format.json { 
          render json: [TreeNode.getJSONForSelectionTable(@user, @models, nil, TreeNode::JSONUSAGE[:releaseShow])].to_json 
      }
    end
	end

	# GET /releases/handleReleases
	def handleReleases
		success = false
		reason = "None"

		id = params[:id]
		models = parseIntegerArrayFromStringArray(params[:models])
		nodes = parseIntegerArrayFromStringArray(params[:nodes])
		name = params[:name]

		# populate release
		if id == nil
			@release = Release.new(name: name, user_id: current_user.id, buildstatus: Release::BUILDSTATE[:pre_build])
		else
			@release = Release.find(id)
		end

		# check for errors
		if models.count == 0 || nodes.count == 0 || name == nil
			reason = "Incorrect release configuration"
		else
			releaseHanlder = Services::ReleasesHandler.new(@release)
			success, reason = releaseHanlder.update_release(models, nodes)
		end

		# redirection
		if success
			redirect_to releases_path, notice: reason
		else
			if id == nil
				redirect_to new_release_path, alert: reason
			else
				redirect_to release_path(@release), alert: reason
			end
		end
	end

	# GET /releases/handleDefault
	def handleDefault
		@user = current_user
		id = params[:id]
		if id == nil
			redirect_to releases_path, alert: "Couldn't save new default release"
		else
			@user.user_setting.update(release_id: id)
			redirect_to releases_path, notice: "Saved new default release"
		end
	end

	# GET /releases/handleBuild
	def handleBuild
		@user = current_user
		id = params[:id]
		if id == nil
			redirect_to releases_path, alert: "Couldn't start build process"
		else
			@release = Release.find(id)
			releaseHanlder = Services::ReleasesHandler.new(@release)
			if releaseHanlder.start_build_process
				redirect_to releases_path, notice: "Saved new default release"
			else
				redirect_to releases_path, alert: "Couldn't start build process"
			end
		end
	end

  # DELETE /releases/1
  def destroy
    @release.destroy
  end

	private
    # returns parsed array of integers from string array
    def parseIntegerArrayFromStringArray(stringArray)
      retArr = stringArray[1..stringArray.length-2].split(",").map {|s| s.to_i}
      return retArr.uniq
    end

    # Use callbacks to share common setup or constraints between actions.
    def set_release
      @release = Release.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def release_params
      params.require(:release).permit(:name)
    end
end
