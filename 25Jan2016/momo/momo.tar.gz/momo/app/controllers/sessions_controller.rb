class SessionsController < Devise::SessionsController
  before_filter :authenticate_user!, :except => [:create]
  protect_from_forgery with: :null_session, :if => Proc.new { |c| c.request.format == 'application/json' }

  def create
    respond_to do |format|

      format.json do
        resource = User.find_for_database_authentication(:username => params[:username])
        return invalid_login_attempt unless resource

        if resource.valid_password?(params[:password])
          sign_in(:user, resource)
          resource.ensure_authentication_token!
          render :json=> {:success=>true, :auth_token=>resource.authentication_token, :username=>resource.username}
          return
        end
        invalid_login_attempt
      end

      format.html { super }
    end
  end

  def destroy
    respond_to do |format|
      format.json do
        resource = User.find_for_database_authentication(:username => params[:username])
        resource.authentication_token = nil
        resource.save
        render :json=> {:success=>true}
      end

      format.html { super }
    end
  end

  protected

  def invalid_login_attempt
    render :json=> {:success=>false, :message=>"Error with your login or password"}, :status=>401
  end
end
