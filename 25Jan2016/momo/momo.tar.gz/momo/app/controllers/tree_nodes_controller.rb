class TreeNodesController < ApplicationController
    before_filter :authenticate_user!
    before_action :set_tree_node, only: [:show, :edit, :update, :destroy]

    # GET /tree_nodes
    # GET /tree_nodes.json
    def index
        @tree_nodes = TreeNode.all
    end

    # GET /tree_nodes/1
    # GET /tree_nodes/1.json
    def show
    end

    # GET /tree_nodes/new
    def new
        @tree_node = TreeNode.new
    end

    # GET /tree_nodes/1/edit
    def edit
    end

    # POST /tree_nodes
    # POST /tree_nodes.json
    def create
        puts params.to_s
        @model = Model.find(params[:tree_node][:model_id])
        @tree_node = TreeNode.new(tree_node_params.except(:model_id))
        
        if @tree_node.name.empty?
            redirect_to new_model_path(id: @model.id, new_model_step: '1_done', :create_new => 'yes'), alert: 'Node not created: fields empty.'
        else
            # TODO: change
            # skip checking if saved to database for now:
            @model.addNewChildNode(@tree_node, current_user)
            redirect_to new_model_path(id: @model.id, new_model_step: '1_done', :create_new => 'yes'), notice: 'Node was successfully created.'
        end
        
        #respond_to do |format|
        #    if @tree_node.save
        #        format.html { redirect_to @tree_node, notice: 'Tree node was successfully created.' }
        #        format.json { render action: 'show', status: :created, location: @tree_node }
        #    else
        #        format.html { render action: 'new' }
        #        format.json { render json: @tree_node.errors, status: :unprocessable_entity }
        #    end
        #end
    end

    # PATCH/PUT /tree_nodes/1
    # PATCH/PUT /tree_nodes/1.json
    def update
        respond_to do |format|
            if @tree_node.update(tree_node_params)
                format.html { redirect_to @tree_node, notice: 'Tree node was successfully updated.' }
                format.json { head :no_content }
            else
                format.html { render action: 'edit' }
                format.json { render json: @tree_node.errors, status: :unprocessable_entity }
            end
        end
    end

    # DELETE /tree_nodes/1
    # DELETE /tree_nodes/1.json
    def destroy
        @tree_node.destroy
        respond_to do |format|
          format.html { redirect_to tree_nodes_url }
          format.json { head :no_content }
      end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_tree_node
      @tree_node = TreeNode.find(params[:id])
  end

    # Never trust parameters from the scary internet, only allow the white list through.
    def tree_node_params
      params.require(:tree_node).permit(:name, :description, :comment, :model_id)
  end
end
