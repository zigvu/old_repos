class UsersController < ApplicationController
    include ApplicationHelper

    before_filter :authenticate_user!

    def spot
        @user = current_user

        @modelSpotManager = SpotManager.where(task: SpotManager::TASK[:model]).last
        @videoSpotManager = SpotManager.where(task: SpotManager::TASK[:video]).last
    end

    # POST /users/admin/handleSpot
    def handleSpot
        @user = current_user

        # create model spot manager
        @user.spot_managers.create(
            instance_type: getSelectItem(SpotManager::INSTANCETYPE, params["model_instance_type"].to_i),
            price: params["model_price"],
            task: SpotManager::TASK[:model],
            num_instance: params["model_num_instance"],
            idle_time: params["model_idle_time"],
            failure_behavior: getSelectItem(SpotManager::FAILUREBEHAVIOR, params["model_failure_behavior"].to_i))

        # create video spot manager
        @user.spot_managers.create(
            instance_type: getSelectItem(SpotManager::INSTANCETYPE, params["video_instance_type"].to_i),
            price: params["video_price"],
            task: SpotManager::TASK[:video],
            num_instance: params["video_num_instance"],
            idle_time: params["video_idle_time"],
            failure_behavior: getSelectItem(SpotManager::FAILUREBEHAVIOR, params["video_failure_behavior"].to_i))

        redirect_to users_admin_spot_path, notice: "Spot configuration updated"
    end

    def handleOrphanedImages
        # clean orphaned images
        Image.cleanOrphanedImages()
        redirect_to users_admin_path, notice: "Orphaned Images deleted"
    end

    def admin
        @user = current_user
        @videos = Video.where(videotask: [
            Video::VIDEOTASK[:uploadFail], 
            Video::VIDEOTASK[:inspectFail]])
        videoWithEvaluateFailSet = [].to_set
        videoDetections = VideoDetection.where(classification: 
            VideoDetection::CLASSIFICATION[:evaluateFail])        
        videoDetections.each do |vd|
            videoWithEvaluateFailSet << vd.video.id
        end
        @videoWithEvaluateFail = Video.where(id: videoWithEvaluateFailSet.to_a)
        @models = Model.where(buildstatus: "build-failure")
    end

    private
        # returns parsed array of integers from string array
        def parseIntegerArrayFromStringArray(stringArray)
            retArr = stringArray[1..stringArray.length-2].split(",").map {|s| s.to_i}
            return retArr.uniq
        end

end
