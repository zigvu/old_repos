class VideoFramesController < ApplicationController
  before_action :set_video_frame, only: [:show, :edit, :update, :destroy]

  # GET /video_frames
  # GET /video_frames.json
  def index
    @video_frames = VideoFrame.all
  end

  # GET /video_frames/1
  # GET /video_frames/1.json
  def show
  end

  # GET /video_frames/new
  def new
    @video_frame = VideoFrame.new
  end

  # GET /video_frames/1/edit
  def edit
  end

  # POST /video_frames
  # POST /video_frames.json
  def create
    @video_frame = VideoFrame.new(video_frame_params)

    respond_to do |format|
      if @video_frame.save
        format.html { redirect_to @video_frame, notice: 'Video frame was successfully created.' }
        format.json { render action: 'show', status: :created, location: @video_frame }
      else
        format.html { render action: 'new' }
        format.json { render json: @video_frame.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /video_frames/1
  # PATCH/PUT /video_frames/1.json
  def update
    respond_to do |format|
      if @video_frame.update(video_frame_params)
        format.html { redirect_to @video_frame, notice: 'Video frame was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @video_frame.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /video_frames/1
  # DELETE /video_frames/1.json
  def destroy
    @video_frame.destroy
    respond_to do |format|
      format.html { redirect_to video_frames_url }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_video_frame
      @video_frame = VideoFrame.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def video_frame_params
      params.require(:video_frame).permit(:frame_position, :S3_URL, :video_id)
    end
end
