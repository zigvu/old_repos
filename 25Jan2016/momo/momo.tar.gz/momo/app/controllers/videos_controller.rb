require "open-uri"

class VideosController < ApplicationController
  include ApplicationHelper

  before_filter :authenticate_user!
  before_action :set_video, only: [:show, :edit, :update, :destroy]

  # GET /videos/:id/rerunVideoTasks
  def rerunVideoTasks
    @video = Video.find(params[:id])
    failureType = params[:failure]
    
    status = "Unknown failure"
    if failureType == Video::VIDEOTASK[:uploadFail]
      if @video.update(videotask: Video::VIDEOTASK[:uploadQueue])
        status = "Video upload task for video id #{@video.id} updated"
      end
    elsif failureType == Video::VIDEOTASK[:inspectFail]
      if @video.update(videotask: Video::VIDEOTASK[:inspectQueue])
        status = "Video inspect task for video id #{@video.id} updated"
      end
    elsif failureType == Video::VIDEOTASK[:evaluateFail]
        # find all failed & pending video detections for this video
        failedVideoDetections = @video.video_detections
          .where(classification: 
            [VideoDetection::CLASSIFICATION[:evaluateFail],
            VideoDetection::CLASSIFICATION[:evaluateQueue],
            VideoDetection::CLASSIFICATION[:evaluateCurrent]])
        # delete orphaned frames:
        failedVideoDetections.each do |videoDetection|
          videoDetection.frame_detections.find_each do |fd|
            if fd.video_frame.frame_detections.count == 1
              fd.video_frame.destroy
            end
          end
        end
        # destroy failed/pending video detections and corresponding frame detections
        # also, update video task to inspectSuccess state
        if failedVideoDetections.destroy_all && 
            @video.update(videotask: Video::VIDEOTASK[:inspectSuccess])
          status = "VideoDetections in failure and queue states reset for video #{@video.id}"
        end
    else
      status = "Unknown failure type or database update failed"
    end

    redirect_to users_admin_path, notice: status
  end

  # GET /videos/modelNetworkGraph
  def modelNetworkGraph
    # TODO: move to a global scope
    limitNumberOfFrames = 100

    @user = current_user

    @viewEvaluatedImagesCount = 0
    @clipboardCount = VideoFrameTag.where(user_id: @user.id).where(usage: ImageTag::CLIPBOARD).count
    @selectionCount = VideoFrameTag.where(user_id: @user.id).where(usage: ImageTag::TEMP).count

    buttonType = params[:button_type]

    respond_to do |format|
      format.html
      format.js {
        # hack for modelEvaluation page
        @video = Video.first
        @modelsArray = params['models']
        @videosArray = params['videos']
        @viewingNetworkGraph = true

        if params[:selectedVideoFrames] != nil
            @selectedVideoFrames = parseIntegerArrayFromStringArray(params[:selectedVideoFrames])
            @selectedModels = parseIntegerArrayFromStringArray(params[:selectedModels])
            @viewEvaluatedImagesCount = @selectedVideoFrames.count          
        end
        

        if buttonType == 'showParallelChart'
          @showParallelChart = true
        end

        if buttonType == 'viewEvaluatedImagesCountBut'
        end

        if buttonType == "viewEvaluatedImagesShowBut"  
          @videoFrames = VideoFrame.where(id: @selectedVideoFrames).limit(limitNumberOfFrames)
          @viewEvaluatedImagesCount = @videoFrames.count
          @viewEvaluatedImagesShowBut = true
        end

        # update individual VF click
        if buttonType == "videoFrameSingleClicked"
          vf = VideoFrame.find(params['videoFrame_id'])
          if vf != nil
            vf.toggleClicked(@user.id)
            @videoFrameClassTagToUpdate = params[:"data-update-target"]
            @videoFrameClassTagToUpdateClicked = vf.hasTag?(@user.id, ImageTag::TEMP)
          end
          @selectionCount = VideoFrameTag.where(user_id: @user.id).where(usage: ImageTag::TEMP).count
        end

        if buttonType == "unsetTempAllVideoFrames"
          VideoFrameTag.where(user_id: @user.id).where(usage: ImageTag::TEMP).destroy_all
          @selectionCount = VideoFrameTag.where(user_id: @user.id).where(usage: ImageTag::TEMP).count
          @unsetTempAllVideoFrames = true
        end

        if buttonType == "addSelectedToClipboard"
          VideoFrameTag.addSelectedToClipboard(@user)
          @clipboardCount = VideoFrameTag.where(user_id: @user.id).where(usage: ImageTag::CLIPBOARD).count
          @selectionCount = VideoFrameTag.where(user_id: @user.id).where(usage: ImageTag::TEMP).count
          @unsetTempAllVideoFrames = true
        end

        if buttonType == "removeSelectedFromClipboard"
          VideoFrameTag.removeSelectedFromClipboard(@user)
          @clipboardCount = VideoFrameTag.where(user_id: @user.id).where(usage: ImageTag::CLIPBOARD).count
          @selectionCount = VideoFrameTag.where(user_id: @user.id).where(usage: ImageTag::TEMP).count
          @unsetTempAllVideoFrames = true
        end

      }
      format.json {
        if buttonType == 'jsonForParallelChart'
          @modelsArray = params['models']
          @videosArray = params['videos']
          modelIds = parseIntegerArrayFromStringArray(@modelsArray)
          videoIds = parseIntegerArrayFromStringArray(@videosArray)
          
          render json: VideoDetection.getJSONForParallelChart(modelIds,videoIds)
          #render json: ActiveSupport::JSON.decode(File.read('tmp/cars.json'))
        elsif buttonType == 'jsonForModelsTable'
          # only show models that are already evaluated:
          @models = Model.includes(:video_detections)
            .where(video_detections: {classification: 
              [VideoDetection::CLASSIFICATION[:positive], 
              VideoDetection::CLASSIFICATION[:negative]]})
          render json: [TreeNode.getJSONForSelectionTable(@user, @models, nil, TreeNode::JSONUSAGE[:videoParallelChartModels])].to_json
        elsif buttonType == 'jsonForVideosTable'
          # only show models that are already evaluated:
          @models = Model.includes(:video_detections)
            .where(video_detections: {classification: 
              [VideoDetection::CLASSIFICATION[:positive], 
              VideoDetection::CLASSIFICATION[:negative]]})
          selectedTreeNode = params['selectedTreeNode']
          if selectedTreeNode == nil
            render json: [TreeNode.getJSONForSelectionTable(@user, @models, nil, TreeNode::JSONUSAGE[:videoParallelChartVideos])].to_json
          else
            render json: TreeNode.find(selectedTreeNode).videoJSONMethod.to_json
          end
        end
      }
    end
  end

  # TODO: DRY code between this and modelEvaluation actions
  # TODO: Once DRY-ed up, remove references to @viewingClipboard flag
  # TODO: remove hack relating to video ID - this requires refactoring
  #  code so that clipboard is out of video hierarchy
  # GET /videos/viewVideoClipboard
  def viewVideoClipboard
    @user = current_user
    @viewingClipboard = true

    # remember the old video context from which the clipboard is viewed
    # so that we can quickly access it again
    # hack to prevent not having a video ID
    videoId = params[:id] || 1
    @video = Video.find(videoId)


    @videoFrames = VideoFrame.includes(:video_frame_tags).where(video_frame_tags: {user_id: @user.id, usage: ImageTag::CLIPBOARD})

    @clipboardCount = @videoFrames.count
    @selectionCount = VideoFrameTag.where(user_id: @user.id).where(usage: ImageTag::TEMP).count
    buttonType = params[:button_type]

    respond_to do |format|
      format.html {
        if buttonType == "removeSelectedFromClipboard"
          VideoFrameTag.removeSelectedFromClipboard(@user)
          redirect_to videos_viewVideoClipboard_path(id: @video.id), notice: "Clipboard updated"
        end

        if buttonType == "setTempAllVideFramesInClipboard"
          VideoFrameTag.setTempAllVideFramesInClipboard(@user)
          redirect_to videos_viewVideoClipboard_path(id: @video.id), notice: "Selection updated"
        end
      }
      format.js {

        # update individual VF click
        if buttonType == "videoFrameSingleClicked"
            vf = VideoFrame.find(params['videoFrame_id'])
            if vf != nil
                vf.toggleClicked(@user.id)
                @videoFrameClassTagToUpdate = params[:"data-update-target"]
                @videoFrameClassTagToUpdateClicked = vf.hasTag?(@user.id, ImageTag::TEMP)
            end
            @selectionCount = VideoFrameTag.where(user_id: @user.id).where(usage: ImageTag::TEMP).count
        end

        if buttonType == "unsetTempAllVideoFrames"
          VideoFrameTag.where(user_id: @user.id).where(usage: ImageTag::TEMP).destroy_all
          @selectionCount = VideoFrameTag.where(user_id: @user.id).where(usage: ImageTag::TEMP).count
          @unsetTempAllVideoFrames = true
        end
      }
    end
  end

  # GET /videos/:id/modelEvaluation
  def modelEvaluation
    # TODO: move to a global scope
    limitNumberOfFrames = 100
    
    @user = current_user
    @video = Video.find(params[:id])
    @models = params[:models]

    @modelsArray = parseIntegerArrayFromStringArray(@models)

    @viewEvaluatedImagesCount = 0
    @clipboardCount = VideoFrameTag.where(user_id: @user.id).where(usage: ImageTag::CLIPBOARD).count
    @selectionCount = VideoFrameTag.where(user_id: @user.id).where(usage: ImageTag::TEMP).count

    buttonType = params[:button_type]

    respond_to do |format|
      format.html
      format.js {
        if buttonType == "viewEvaluatedImagesCountBut"
          # make sure at least one second is captured
          brushExtLeft = getTimeBackInMilliseconds(params[:brushExtLeft])
          brushExtRight = getTimeBackInMilliseconds(params[:brushExtRight])
          if brushExtRight - brushExtLeft <= 1000
            brushExtRight = brushExtLeft + 1001
          end
          @viewEvaluatedImagesCount = @video.getVideoFramesForBrushing(@modelsArray, brushExtLeft, brushExtRight).count
        end

        if buttonType == "viewEvaluatedImagesShowBut"
          # make sure at least one second is captured
          brushExtLeft = getTimeBackInMilliseconds(params[:brushExtLeft])
          brushExtRight = getTimeBackInMilliseconds(params[:brushExtRight])
          if brushExtRight - brushExtLeft <= 1000
            brushExtRight = brushExtLeft + 1001
          end
          @videoFrames = @video.getVideoFramesForBrushing(@modelsArray, brushExtLeft, brushExtRight).limit(limitNumberOfFrames)
          @viewEvaluatedImagesCount = @videoFrames.count

          @viewEvaluatedImagesShowBut = true
        end

        # update individual VF click
        if buttonType == "videoFrameSingleClicked"
            vf = VideoFrame.find(params['videoFrame_id'])
            if vf != nil
                vf.toggleClicked(@user.id)
                @videoFrameClassTagToUpdate = params[:"data-update-target"]
                @videoFrameClassTagToUpdateClicked = vf.hasTag?(@user.id, ImageTag::TEMP)
            end
            @selectionCount = VideoFrameTag.where(user_id: @user.id).where(usage: ImageTag::TEMP).count
        end

        if buttonType == "unsetTempAllVideoFrames"
          VideoFrameTag.where(user_id: @user.id).where(usage: ImageTag::TEMP).destroy_all
          @selectionCount = VideoFrameTag.where(user_id: @user.id).where(usage: ImageTag::TEMP).count
          @unsetTempAllVideoFrames = true
        end

        if buttonType == "addSelectedToClipboard"
          VideoFrameTag.addSelectedToClipboard(@user)
          @clipboardCount = VideoFrameTag.where(user_id: @user.id).where(usage: ImageTag::CLIPBOARD).count
          @selectionCount = VideoFrameTag.where(user_id: @user.id).where(usage: ImageTag::TEMP).count
          @unsetTempAllVideoFrames = true
        end

        if buttonType == "removeSelectedFromClipboard"
          VideoFrameTag.removeSelectedFromClipboard(@user)
          @clipboardCount = VideoFrameTag.where(user_id: @user.id).where(usage: ImageTag::CLIPBOARD).count
          @selectionCount = VideoFrameTag.where(user_id: @user.id).where(usage: ImageTag::TEMP).count
          @unsetTempAllVideoFrames = true
        end
      }
      format.json { render json: @video.getJSONForChart(@modelsArray).to_json }
    end
  end

  # GET /videos/:id/handleAddModelsForDetection
  def handleAddModelsForDetection
    @video = Video.find(params[:id])
    @models = params[:models]

    @modelsArray = parseIntegerArrayFromStringArray(@models)

    # due to bug in FancyTree javascript library, currently, when a treenode
    # is selected, the models under it automatically get selected, even though
    # they are "unselectable"
    @modelsArray.map do |mId|
      vd = @video.getModelVideoDetection(mId)
      if vd != nil && vd.classification != VideoDetection::CLASSIFICATION[:evaluateQueue]
        # these are unselectable models:
        @modelsArray.delete(mId)
      end
    end

    # first, reset all in-queue models
    @video.video_detections.where(classification: VideoDetection::CLASSIFICATION[:evaluateQueue]).destroy_all

    # now, we re-populate based on the form submitted
    @modelsArray.map do |mId|
      @video.setModelVideoDetection(mId, VideoDetection::CLASSIFICATION[:evaluateQueue], nil)
    end

    # if at least one model is in queue, set video task to evaluate,
    # else set to default inspect success state
    if @video.getModelsInVideoDetectionState(VideoDetection::CLASSIFICATION[:evaluateQueue]).count > 0
      @video.update(videotask: Video::VIDEOTASK[:evaluateQueue])
    else
      @video.update(videotask: Video::VIDEOTASK[:inspectSuccess])
    end

    redirect_to @video, notice: "Evaluation models updated"
  end

  # GET /videos/addModelsForDetection
  def addModelsForDetection
    @user = current_user
    @video = Video.find(params[:id])
    @models = Model.where(buildstatus: "build-complete").where("name != ?", "IMAGEBANK")

    respond_to do |format|
      format.html
      format.json { 
        render json: [TreeNode.getJSONForSelectionTable(@user, @models, @video, TreeNode::JSONUSAGE[:videoAddModels])].to_json 
      }
    end
  end

  # GET /videos/:id/handleVideoLabelSelection
  def handleVideoLabelSelection
    @video = Video.find(params[:id])
    @treeNodes = params[:treenodes]

    @treeNodesArray = parseIntegerArrayFromStringArray(@treeNodes)

    # first, reset all video labels:
    @video.video_labels.destroy_all

    # now, we re-populate based on the form submitted
    @treeNodesArray.map do |tnId|
      @video.addVideoLabel(current_user, tnId)
    end

    redirect_to @video, notice: "Video labels updated"
  end

  # GET /videos/:id/videoLabelSelection
  def videoLabelSelection
    @user = current_user
    @video = Video.find(params[:id])
    @models = Model.all

    respond_to do |format|
      format.html
      format.json { 
        render json: [TreeNode.getJSONForSelectionTable(@user, @models, @video, TreeNode::JSONUSAGE[:videoLabel])].to_json 
      }
    end
  end

  # GET /videos/copyPasteURLFromWeb
  def uploadFromURL
  end

  # POST /videos/handleURLPaste
  def handleUploadFromURL
    urlList = params[:urlList].to_s.split("\r\n")

    urlAddCount = 0
    urlDuplicateCount = 0
    urlInvalidCount = 0
    urlList.map do |url|
      if url.length > 0
        host = URI.parse(url).host
        if host != nil && host.include?("youtube")
          # if file hasn't been downloaded up to now
          if Video.where(file_source: url).count <= 0
            @video = Video.new(
              source_type: Video::SOURCETYPE[:youtube], 
              user_id: current_user.id,
              file_source: url, 
              videostatus: Video::VIDEOSTATUS[:s3uploadQueue],
              videotask: Video::VIDEOTASK[:uploadQueue],
              comment: 'Please type in new comment...')
            # if successful save
            if @video.save
              urlAddCount = urlAddCount + 1
            end
          else
            urlDuplicateCount = urlDuplicateCount + 1
          end
        else
          urlInvalidCount = urlInvalidCount + 1
        end
      end
    end
    redirect_to videos_path, notice: "#{urlAddCount} Videos queued for upload; #{urlDuplicateCount} duplicates not queued; #{urlInvalidCount} urls invalid"
  end

  # GET /getIndexVideosForTable.json
  def getIndexVideosForTable
    respond_to do |format|
      format.html # index.html.erb
      format.json { 
        render json: '[{"key":"1","node_type":"treenode","title":"Tree Root","tooltip":"TreeNode - Tree Root","evaluate_class":"-","extraClasses":"fancyTreeClassTreeNode","comments":"-","algorithm":"-","build_status":"-","checkout":"-","show":"-", "lazy":"true", "folder":"true"}]'
      }
    end
  end

  # GET /videos
  # GET /videos.json
  def index
    @videos = Video.all.paginate(page: params[:page], per_page: 20)

    respond_to do |format|
      format.html # index.html.erb
      format.json { 
        # prevent uploaded video displaying:
        @videos = []
        render json: @videos.map{|video| video.to_jq_upload } 
      }
    end
  end

  # GET /videos/1
  # GET /videos/1.json
  def show
    @user = current_user
    @video = Video.find(params[:id])

    # treenodes for video labels:
    @treeNodes = @video.tree_nodes
    # models that are already evaluated for charting:
    @models = @video.getModelsInVideoDetectionState([
      VideoDetection::CLASSIFICATION[:positive], 
      VideoDetection::CLASSIFICATION[:negative]])

    respond_to do |format|
      format.html # show.html.erb
      format.json { 
        render json: [TreeNode.getJSONForSelectionTable(@user, @models, @video, TreeNode::JSONUSAGE[:videoShow])].to_json 
      }
    end
  end

  # GET /videos/new
  def new
    @video = Video.new

    respond_to do |format|
      format.html # new.html.erb
      format.json { render json: @video }
    end
  end

  # GET /videos/1/edit
  def edit
  end

  # POST /videos
  # POST /videos.json
  def create
    @video = Video.new(video_params)
    @video.user_id = current_user.id
    @video.videostatus = Video::VIDEOSTATUS[:s3uploaded]
    @video.videotask = Video::VIDEOTASK[:inspectQueue]
    @video.comment = 'Please type in new comment...'

    respond_to do |format|
      if @video.save
        format.html { 
          #redirect_to @video, notice: 'Video was successfully created.' 
          render :json => [@video.to_jq_upload].to_json,
          :content_type => 'text/html',
          :layout => false
        }
        format.json { 
          render json: {files: [@video.to_jq_upload]}, status: :created, location: @video 
        }
      else
        format.html { render action: 'new' }
        format.json { render json: @video.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /videos/1
  # PATCH/PUT /videos/1.json
  def update
    respond_to do |format|
      if @video.update(video_params)
        format.html { redirect_to @video, notice: 'Video was successfully updated.' }
        format.json { 
          respond_with_bip(@video) 
        }
      else
        format.html { render action: 'edit' }
        format.json { render json: @video.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /videos/1
  # DELETE /videos/1.json
  def destroy
    @video.destroy
    respond_to do |format|
      format.html { redirect_to videos_url }
      format.json { head :no_content }
    end
  end

  private
    # returns parsed array of integers from string array
    def parseIntegerArrayFromStringArray(stringArray)
      retArr = stringArray[1..stringArray.length-2].split(",").map {|s| s.to_i}
      return retArr.uniq
    end

    # Use callbacks to share common setup or constraints between actions.
    def set_video
      @video = Video.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def video_params
      params.require(:video).permit(:upload, :user_id, :source_type, :file_source, :comment, :title)
    end
end
