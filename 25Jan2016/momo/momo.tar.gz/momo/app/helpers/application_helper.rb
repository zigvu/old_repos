module ApplicationHelper

	PROGRESSDELIM = '::PROGRESS::'

	def beautyTimeMilliseconds(milliseconds)
		if milliseconds == nil
			'0:0:0::0'
		else
			# Hour:Minute:Seconds::Millisecond
			'%d:%d:%d::%d' %
			# the .reverse lets us put the larger units first for readability
			[60,60,1000].reverse.inject([milliseconds]) {|result, unitsize|
				result[0,0] = result.shift.divmod(unitsize)
				result
			}
		end
	end

	def getTimeBackInMilliseconds(formattedTime)
		milliseconds = formattedTime.split("::")[1].to_i
		nonMilliseconds = formattedTime.split("::")[0]
		seconds = nonMilliseconds.split(":")[2].to_i
		minutes = nonMilliseconds.split(":")[1].to_i
		hours = nonMilliseconds.split(":")[0].to_i
		return hours * 60 * 60 * 1000 + minutes * 60 * 1000 + seconds * 1000 + milliseconds
	end

	def beautyAlbum(album_type)
		if album_type == ImageTag::TRAIN_POS
			"Positive Train"
		elsif album_type == ImageTag::TRAIN_NEG
			"Negative Train"
		elsif album_type == ImageTag::TEST_POS
			"Positive Test"
		elsif album_type == ImageTag::TEST_NEG
			"Negative Test"
		elsif album_type == ImageTag::TP
			"Test: True Positive"
		elsif album_type == ImageTag::FN
			"Test: False Negative"
		elsif album_type == ImageTag::FP
			"Test: False Positive"
		elsif album_type == ImageTag::TN
			"Test: True Negative"
		elsif album_type == ImageTag::CLIPBOARD
			"Clipboard"
		elsif album_type == ImageTag::IMAGEBANK
			"Image Bank"
		end
	end

	def modelSetProgress(oldStatusProgress, newProgress)
		oldStatus = modelGetStatus(oldStatusProgress)
		oldStatus + PROGRESSDELIM + newProgress.to_s
	end

	def modelSetStatus(oldStatusProgress, newStatus)
		oldProgress = modelGetProgress(oldStatusProgress)
		if oldProgress == '0'
			newStatus
		else
			newStatus + PROGRESSDELIM + oldProgress
		end
	end

	def modelGetProgress(oldStatusProgress)
		if oldStatusProgress.index(PROGRESSDELIM) == nil
			'0'
		else
			oldStatusProgress[oldStatusProgress.index(PROGRESSDELIM)+PROGRESSDELIM.length..oldStatusProgress.length]
		end
	end

	def modelGetStatus(oldStatusProgress)
		if oldStatusProgress.index(PROGRESSDELIM) == nil
			oldStatusProgress
		else
			oldStatusProgress[0..oldStatusProgress.index(PROGRESSDELIM)-1]
		end
	end

	# convert a has to array for select tag display
	def getSelectArray(origHash)
		origArray = []
		counter = 1
		origHash.to_a.map do |i| 
			origArray << [i[1], counter]
			counter = counter + 1
		end
		origArray
	end

	def getSelectItem(origHash, itemPos)
		origHash.to_a[itemPos - 1][1]
	end

	def getSelectPos(origHash, itemString)
		counter = 1
		found = false
		origHash.to_a.map do |i|
			if i[1] == itemString
				found = true
				break
			else
				counter = counter + 1
			end
		end
		found ? counter : 0
	end

end
