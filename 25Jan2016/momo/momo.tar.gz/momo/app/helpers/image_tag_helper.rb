module ImageTagHelper
end
