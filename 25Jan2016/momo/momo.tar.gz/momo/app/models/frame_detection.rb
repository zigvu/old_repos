class FrameDetection < ActiveRecord::Base

	belongs_to :video_frame
	belongs_to :video_detection
end
