require "open-uri"

# Base class for all images (except video frames).
# 
# This class uses Paperclip gem to manage file storage in S3
# @todo Paperclip validation of size and presence of "upload"
#   is missing from current implementation.
class Image < ActiveRecord::Base
	validates :user, presence: true
	
	# Setup paperclip
	# ---------------------------------------------------------

	# Default time for expiring URL from S3
	# @note Currently image URLs are set to expire in 30 minutes
	S3URLEXPTIME = 1800

	#validates_attachment_presence :upload
	#validates_attachment_size :upload, :less_than => 5.megabytes
	if Rails.env.local?
		has_attached_file :upload,
					:styles => {:original => {:geometry => '800x600>', :format => :png},
			                    :medium => {:geometry => '300x225>', :format => :png},
                                :small => {:geometry => '75x50>', :format => :png}}
	else
		has_attached_file :upload, 
                    :styles => {:original => {:geometry => '800x600>', :format => :png},
			                    :medium => {:geometry => '300x225>', :format => :png},
                                :small => {:geometry => '75x50>', :format => :png}},
                    :bucket => S3HOSTBUCKETIMAGE,
                    :s3_host_alias => S3HOSTIMAGES
	end

	include Rails.application.routes.url_helpers

	# JSON handler for Jquery-file-upload library
	# @return [Hash{String => Symbol, Number}] hash indicating file name, size, url,
	#   delete url, and delete method type
	def to_jq_upload 
		{
	    "name" => read_attribute(:upload_file_name),
			"size" => read_attribute(:upload_file_size),
			"url" => upload.url(:original),
			"delete_url" => image_path(self),
			"delete_type" => "DELETE"
		}
	end

	# Upload file directly from URL.
	#
	# This method downloads the file from remote URL to server, processes the file
	# and re-uploads the file to S3 via paperclip
	# @param url [String] from which to upload the file
	# @todo Create return value
	def upload_from_url(url)
		# if kheer uploaded, it will be saved in /tmp
		file_source = (url[0..3] == '/tmp') ? "Kheer" : url
		if Rails.env.local?
			self.file_source = file_source
			self.upload = (file_source == url) ? File.open('public' + url, 'r') :  File.open(url, 'r')
		else
			self.file_source = file_source
			self.upload = (file_source == url) ? URI.parse(url) :  File.open(url, 'r')
		end
	end

	# Get URL of an image for a particular style
	#
	# If the rails environment is non-local, an expiring S3 URL is served
	# @param style [Symbol] of the image requested
	# @return [String] expiring S3 URL 
	def getURL(style)
		if Rails.env.local?
			upload.url(style)
		else
			upload.expiring_url(Image::S3URLEXPTIME, style)
		end
	end

	# Done setting up paperclip
	# ---------------------------------------------------------

	# required by pagination
	self.per_page = 50


	# Set an image tag (and associated text tag) for this image/model pair
	#
	# If image tag to be updated is text tag, then this creates a new text tag.
	# In addition to creating new text tag, the unassigned model text tag is also
	# removed from this image.
	# @param curUserId [Integer] id of current user
	# @param curModelId [Integer] id of model for which this tag is being set
	# @param targetTagUsage [String] image tag constants from {ImageTag}
	# @param targetTextTagId [Integer, nil] if non-nil, id of one of the text
	#   tags of specified model, {ModelTextTag}
	# @todo Create return value
	def setTag(curUserId, curModelId, targetTagUsage, targetTextTagId)
		if !hasTag?(curUserId, curModelId, targetTagUsage, targetTextTagId)
			image_tags.create(user_id: curUserId, model_id: curModelId, usage: targetTagUsage, model_text_tag_id: targetTextTagId)
			# if it is text tag, then need to remove from uncategorized
			if targetTagUsage == ImageTag::TEXT
				imgtgs = image_tags.includes(:model).where(models: {id: curModelId})
				mtt = Model.find(curModelId).getIdOfUnassignedModelTextTag
				imgtgs.where(model_text_tag_id: mtt).destroy_all
			end
		end
	end

	# Unset an image tag (and associated text tag) for this image/model pair
	#
	# If image tag to be unset is text tag, then an 
	# unassigned model text tag is created for this image. If the image tag is
	# temporary tags (TEMP or CLIPBOARD), only those tags of specified user is removed.
	# @param (see #setTag)
	# @todo Create return value
	def unsetTag(curUserId, curModelId, targetTagUsage, targetTextTagId)
		imgtgs = image_tags.includes(:model).where(models: {id: curModelId})
		if targetTagUsage == ImageTag::TEMP 
			# remove only for this user:
			imgtgs.includes(:user).where(users: {id: curUserId}).where(usage: targetTagUsage).destroy_all
		elsif targetTagUsage == ImageTag::CLIPBOARD
			# if clipboard, don't be model specific, but for this user only:
			image_tags.includes(:user).where(users: {id: curUserId}).where(usage: targetTagUsage).destroy_all
		elsif targetTagUsage == ImageTag::TEXT
			# PREVENT accidental deletion if text tag not provided:
			if targetTextTagId != nil
				imgtgs.where(model_text_tag_id: targetTextTagId).destroy_all

				# if there are no text tags associated with this image for this
				# model, then put it in uncategorized bucket
				if !hasTag?(curUserId, curModelId, targetTagUsage, nil)
					mtt = Model.find(curModelId).getIdOfUnassignedModelTextTag
					image_tags.create(user_id: curUserId, model_id: curModelId, usage: targetTagUsage, model_text_tag_id: mtt)
				end
			end
		else
			# if it is one of TRAIN/TEST_POS/NEG, then remove all references of this
			# model from image
			#imgtgs.where(usage: targetTagUsage).destroy_all
			imgtgs.destroy_all
		end
	end

	# Checks if an image tag (or text tag) already exists for this image/model pair
	#
	# @param (see #setTag)
	# @return [Boolean] true if a tag exists for current image/model pair, else false
	def hasTag?(curUserId, curModelId, targetTagUsage, targetTextTagId)
		count = -1
		imgtgs = image_tags.joins(:model).where(models: {id: curModelId}).where(usage: targetTagUsage)
		if targetTagUsage == ImageTag::TEMP
			# check for current user only
			count = imgtgs.joins(:user).where(users: {id: curUserId}).count
		elsif targetTagUsage == ImageTag::CLIPBOARD
			# if clipboard, don't be model specific, but for this user only:
			count = image_tags.joins(:user).where(users: {id: curUserId}).where(usage: targetTagUsage).count
		elsif targetTagUsage == ImageTag::TEXT
			# if no text tag provided, then count all text tags for the model
			if targetTextTagId == nil
				count = imgtgs.count
			else
				count = imgtgs.where(model_text_tag_id: targetTextTagId).count
			end
		else
			count = imgtgs.count
		end
		count > 0 ? true : false
	end

	# Get detection score once a model is built
	#
	# @param curModelId [Integer] id of model for which this tag is being set
	# @return [Float] detection score of this image for given model
	# @todo Check for model built state
	def getDetectionScore(curModelId)
		image_tags.where(usage: [ImageTag::TEST_POS, ImageTag::TEST_NEG, ImageTag::IMAGEBANK])
		.where(model_id: curModelId).first.detection_score.round(4)
	end

	# Get detection classification once a model is built
	#
	# @param (see #getDetectionScore)
	# @return [String] one of TP, FN, FP, TN as described in {ImageTag}
	# @todo (see #getDetectionScore)
	def getDetectionClassification(curModelId)
		if image_tags.where(usage: ImageTag::TEST_POS).where(model_id: curModelId).count > 0
			if getDetectionScore(curModelId) >= 0
				ImageTag::TP
			else
				ImageTag::FN
			end
		elsif image_tags.where(usage: ImageTag::TEST_NEG).where(model_id: curModelId).count > 0
			if getDetectionScore(curModelId) >= 0
				ImageTag::FP
			else
				ImageTag::TN
			end
		else
			'None'
		end
	end

	# Get text tags once a model is built
	#
	# @param (see #getDetectionScore)
	# @return [<String>] a text tag described in {ModelTextTag}
	# @todo (see #getDetectionScore)
	def getModelTextTagArray(curModelId)
		imgTagArray = []
		image_tags.where(usage: ImageTag::TEXT).where(model_id: curModelId).find_each do |imgTag|
			imgTagArray << imgTag.model_text_tag.tag
		end
		imgTagArray
	end

	# Class method to clean orphaned images
	def self.cleanOrphanedImages
		Image.all.find_each do |img|
			if img.image_tags.count < 1
				img.destroy
			end
		end
	end
    

    has_many :image_tags, dependent: :destroy
    has_many :models, through: :image_tags
    belongs_to :user
end
