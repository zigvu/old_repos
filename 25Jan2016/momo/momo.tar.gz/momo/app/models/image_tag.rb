class ImageTag < ActiveRecord::Base
	validates :user, presence: true

	# different types of tags:
	TRAIN_POS = "TRAIN_POS"
	TRAIN_NEG = "TRAIN_NEG"
	TEST_POS = "TEST_POS"
	TEST_NEG = "TEST_NEG"
	TP = "TP"
	FP = "FP"
	TN = "TN"
	FN = "FN"
	TEXT = "TEXT"
	TEMP = "TEMP"
	CLIPBOARD = "CLIPBOARD"
	IMAGEBANK = "IMAGEBANK"
	WEAKMODEL = "WEAKMODEL"

	validates_inclusion_of :usage, in: [TRAIN_POS, TRAIN_NEG, TEST_POS, TEST_NEG, TP, FP, TN, FN, TEXT, TEMP, CLIPBOARD, IMAGEBANK], allow_nil: false
	
	belongs_to :image
	belongs_to :model
	belongs_to :user
	belongs_to :model_text_tag
end
