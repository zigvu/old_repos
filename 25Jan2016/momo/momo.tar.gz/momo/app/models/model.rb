
# Base class for models.
# 
# This class keeps track of all images, tags and text tags
# necessary to build a model. Each model is built within a
# {TreeNode} and successive versions of a model are treated as
# independent sibling models within that {TreeNode}.
class Model < ActiveRecord::Base
	validates :user, presence: true
	validates :name, presence: true

	# Minimum number of training images required to build model
	MINNUMIMGTRAIN = 50
	# Minimum number of testing images required to build model
	MINNUMIMGTEST = 10

	# Get expiring S3 URLs for model SVM once it is built 
	#
	# @return [String] URL using which this model SVM can be accessed
	# @note Assume files are saved in agreed upon paths
	def get_S3_model_file
		if Rails.env.local?
			modelpath
		else
			AWS::S3.new.buckets[S3HOSTBUCKETMODEL]
				.objects['uploads/' + id.to_s + '/model.txt']
				.url_for(:read, :expires => Image::S3URLEXPTIME * 10)
				.to_s
		end
	end

	# Get expiring S3 URLs for charts after model is built 
	#
	# @param filename [String] name of the chart
	# @return [String] URL using which this model chart can be accessed
	# @note Assume images are saved in agreed upon paths
	def get_S3_chart_url(filename)
		if Rails.env.local?
			# we don't have charts in the local environment
			nil
		else
			AWS::S3.new.buckets[S3HOSTBUCKETMODEL]
				.objects['uploads/' + id.to_s + '/figures/' + filename]
				.url_for(:read, :expires => Image::S3URLEXPTIME)
		end
	end

	# Determines if the model has sufficient number of images for build.
	#
	# @return [Boolean] true if model has minimum number of training/testing images, else false
	def hasSufficientImagesForBuild?
		if 	(getImagesUserUsageTag(nil, ImageTag::TRAIN_POS, nil).count >= MINNUMIMGTRAIN) &&
			(getImagesUserUsageTag(nil, ImageTag::TRAIN_NEG, nil).count >= MINNUMIMGTRAIN) &&
			(getImagesUserUsageTag(nil, ImageTag::TEST_POS, nil).count >= MINNUMIMGTEST) &&
			(getImagesUserUsageTag(nil, ImageTag::TEST_NEG, nil).count >= MINNUMIMGTEST)
			
			true
		else
			false
		end
	end

	# Set all images in album as "selected"
	#
	# This method sets all images in a particular album to be on a "selected" state.
	# @param (see #getImagesUserUsageTag)
	# @todo: Not used so remove
	def setTempAllImagesInAlbum(curUser, imageTagUsage, modelTextTagId)
		# if album is for the current user only, don't select other's temp/clipboard:
		if imageTagUsage == ImageTag::TEMP || imageTagUsage == ImageTag::CLIPBOARD
			tempImages = getImagesUserUsageTag(curUser, imageTagUsage, modelTextTagId)
		else
			tempImages = getImagesUserUsageTag(nil, imageTagUsage, modelTextTagId)
		end
		tempImages.map do |image|
			image.setTag(curUser.id, id, ImageTag::TEMP, nil)
		end
	end

	# Set all images with given ids as "selected"
	#
	# This method sets all images in a particular album to be on a "selected" state.
	# @param imageIdArray [<Integer>] array of id of {Image}
	def setTempAllImageIdsInArray(curUser, imageIdArray)
		if imageIdArray != nil
			imageIdArray.each do |imageId|
				Image.find(imageId).setTag(curUser.id, id, ImageTag::TEMP, nil)
			end
		end
	end

	# Unset all temp images
	#
	# This method unsets all temp images (TEMP or CLIPBOARD tags).
	# @param curUser [User] current user
	def unsetTempAllImages(curUser)
		ImageTag.where(user_id: curUser.id).where(usage: ImageTag::TEMP).destroy_all
	end

	# Toggle the state of a single image as the user clicks/unclicks on the image
	#
	# @param curUser [User] current user
	# @param image [Image] image being currently clicked
	def toggleSingleImageClicked(curUser, image)
		if image.hasTag?(curUser.id, id, ImageTag::TEMP, nil)
			image.unsetTag(curUser.id, id, ImageTag::TEMP, nil)
		else
			image.setTag(curUser.id, id, ImageTag::TEMP, nil)
		end
	end

	# Get all images for a particular album or if album is temp, for the user
	#
	# @param curUser [User, nil] current user if {ImageTag} is TEMP or CLIPBOARD, 
	#   nil if album is user indpendent (e.g., TEST_POS).
	# @param imageTagUsage [String] image tag constants from {ImageTag}
	# @param modelTextTagId [Integer, nil] if non-nil, id of one of the text
	#   tags of specified model, {ModelTextTag}
	# @return [Set<Image>] list of images
	def getImagesUserUsageTag(curUser, imageTagUsage, modelTextTagId)
		# clipboard is shared across models
		if imageTagUsage == ImageTag::CLIPBOARD
			userUsageTagImages = Image.all.includes(:image_tags).where(image_tags: {user_id: curUser.id, usage: imageTagUsage})
		else
			userUsageTagImages = getAllImages(imageTagUsage, modelTextTagId)
			if curUser == nil
				userUsageTagImages
			else
				userUsageTagImages.includes(:image_tags).where(image_tags: {user_id: curUser.id})
			end
		end
	end

	# Get images for post analysis once model has been built
	#
	# TP/FN/FP/TN are determined by the original label (TEST_POS etc.) and sign of score.
	# @param postAnalysisType [String] image tag constants from {ImageTag}
	# @return [Set<Image>] list of images
	def getImagesPostAnalysis(postAnalysisType)
		if postAnalysisType == ImageTag::TP
			tgImg = images.includes(:image_tags).where(image_tags: {usage: ImageTag::TEST_POS})
			tgImg.where("image_tags.detection_score >= ?", 0).order('image_tags.detection_score desc')
    elsif postAnalysisType == ImageTag::FN
    	tgImg = images.includes(:image_tags).where(image_tags: {usage: ImageTag::TEST_POS})
			tgImg.where("image_tags.detection_score < ?", 0).order('image_tags.detection_score asc')
    elsif postAnalysisType == ImageTag::FP
    	tgImg = images.includes(:image_tags).where(image_tags: {usage: ImageTag::TEST_NEG})
			tgImg.where("image_tags.detection_score >= ?", 0).order('image_tags.detection_score desc')
    elsif postAnalysisType == ImageTag::TN
    	tgImg = images.includes(:image_tags).where(image_tags: {usage: ImageTag::TEST_NEG})
			tgImg.where("image_tags.detection_score < ?", 0).order('image_tags.detection_score asc')
		elsif postAnalysisType == ImageTag::IMAGEBANK
			tgImg = images.includes(:image_tags).where(image_tags: {usage: ImageTag::IMAGEBANK})
			tgImg.order('image_tags.detection_score desc')
    else
    	nil
    end
	end

	# Set a new image tag and optionally text tag for all selected images.
	#
	# Set tag of all TEMP images to target usage (and optionally text tag).
	# For text tags, {Image} class handles setting/unsetting unassigned tags.
	# @param curUser [User] current user
	# @param targetUsage [String] image tag constants from {ImageTag}
	# @param targetModelTextTagId [Integer, nil] if non-nil, id of one of the text
	#   tags of specified model, {ModelTextTag}
	# @todo Create return value
	def setClickedImageTags(curUser, targetUsage, targetModelTextTagId)
		clickedImages = getImagesUserUsageTag(curUser, ImageTag::TEMP, nil)
		clickedImages.map do |image|
			# set tag:
			image.setTag(curUser.id, id, targetUsage, targetModelTextTagId)
			# unset clicked state:
			image.unsetTag(curUser.id, id, ImageTag::TEMP, nil)
		end
	end

	# Unset image tags and optionally text tag for all selected images.
	#
	# Unset tag of all TEMP images (and optionally unset text tags).
	# For text tags, {Image} class automatically inserts an "unassigned" text tag
	# if no text tag is associated with the image.
	# @param curUser [User] current user
	# @param curUsage [String] image tag constants from {ImageTag}
	# @param curModelTextTagId [Integer, nil] if non-nil, id of one of the text
	#   tags of specified model, {ModelTextTag}
	# @todo Create return value
	def unsetClickedImageTags(curUser, curUsage, curModelTextTagId)
		clickedImages = getImagesUserUsageTag(curUser, ImageTag::TEMP, nil)
		clickedImages.map do |image|
			# unset tag:
			image.unsetTag(curUser.id, id, curUsage, curModelTextTagId)
			# unset clicked state:
			image.unsetTag(curUser.id, id, ImageTag::TEMP, nil)
		end
	end

	# Paste CLIPBOARD images to album
	#
	# This updates images tagged with CLIPBOARD to appropriate albums. It handles images
	# coming from other models. Additionally, if the pasted image happens to be in the image
	# bank of this model, it is removed from image bank. No duplicate image is allowed in
	# any of the four primary albums, as defined in {ImageTag}
	# @param (see #setClickedImageTags)
	def pasteClipboardImageTags(curUser, targetUsage, targetModelTextTagId)
		# note that we cannot use image.* methods since those don't update
		# model id - so for now, this is the way to go
		mtt = getIdOfUnassignedModelTextTag
		clipboardImageTags = ImageTag.where(usage: ImageTag::CLIPBOARD, user_id: curUser.id)
		clipboardImageTags.map do |clipboardImageTag|
			# disable paste to other albums:
			if targetUsage == ImageTag::TRAIN_POS ||
				targetUsage == ImageTag::TRAIN_NEG ||
				targetUsage == ImageTag::TEST_POS ||
				targetUsage == ImageTag::TEST_NEG

				# ensure image has not been used in one of the four albums
				if 0 >= image_tags.where(usage: [ImageTag::TRAIN_POS,
												ImageTag::TRAIN_NEG,
												ImageTag::TEST_POS,
												ImageTag::TEST_NEG], 
											image_id: clipboardImageTag.image_id).count
					
					# no need to delete clipboardImageTag - just update suffices
					clipboardImageTag.update(usage: targetUsage, model_id: id)
					# if positive usage then create text tags too
					if targetUsage == ImageTag::TRAIN_POS || targetUsage == ImageTag::TEST_POS
						image_tags.create(user_id: curUser.id, image_id: clipboardImageTag.image_id, usage: ImageTag::TEXT, model_text_tag_id: mtt)
					end

					# if this image tag points to an image from image bank,
					# remove that image from the bank (of this model, of course)
					image_tags.where(usage: ImageTag::IMAGEBANK).where(image_id: clipboardImageTag.image_id).destroy_all
				end
			end
		end
	end

	# Delete text tag associated with this model
	#
	# This method deletes {ModelTextTag} associated with this model. It also
	# cleans up any {ImageTag} that might be referencing the deleted {ModelTextTag}.
	# If an image has no {ModelTextTag} associated with it, it is automatically
	# tagged as being unassigned.
	# @param curUser [User] current user
	# @param modelTextTag [ModelTextTag] one of the {ModelTextTag} associated with this model
	def deleteModelTextTag(curUser, modelTextTag)
		tagImages = getAllImages(ImageTag::TEXT, modelTextTag.id)
		tagImages.map do |image|
			image.unsetTag(curUser.id, id, ImageTag::TEXT, modelTextTag.id)
		end
	end

	# Returns the id of the "UNASSIGNED" model text tag
	#
	# Each model has one {ModelTextTag} with the tag "UNASSIGNED". This method
	# returns the ID of that tag.
	# @return [Integer, nil] id of the "UNASSIGNED" {ModelTextTag} if present, else nil
	def getIdOfUnassignedModelTextTag
		mtt = model_text_tags.where(tag: ModelTextTag::UNASSIGNED).first
		if mtt == nil
			nil
		else
			mtt.id
		end
	end

	# Returns node parent of current model
	# 
	# @return [Array<TreeNode>] parents of current node up to root node
	def getNodeParents
		# if nodeParents hasn't been computed yet, compute:
		if @nodeParents == nil
			# if this is a new model, set root node as current node
			if self.tree_node == nil
				setCurrentNode(TreeNode.first)
			end
			@nodeParents = self.tree_node.getNodeParents
		end
		@nodeParents
	end

	# Adds a tree node to current model
	# 
	# @param newNode [TreeNode] new node to add as a child existing node tree
	# @param curUser [User] current user
	# @todo Refactor to combine with {Model#setCurrentNode} function
	def addNewChildNode(newNode, curUser)
		newNode.user = curUser
		# establish relationship
		self.tree_node.add_child newNode
		setCurrentNode(newNode)
	end

	# Sets a new node as current node
	# 
	# This method also sets two instance variables for use in views:
	# nodeParents and nodeChildren
	# @param newNode [TreeNode] new node to add as a child existing node tree
	def setCurrentNode(newNode)
		self.tree_node = newNode
		self.save
		@nodeParents = self.tree_node.getNodeParents
		@nodeChildren = self.tree_node.getNodeChildren
	end

	# Returns node children of current model
	# 
	# @return [Array<TreeNode>] children of current node
	def getNodeChildren
		# if nodeChildren hasn't been computed yet, compute:
		if @nodeChildren == nil
			# if this is a new model, set root as current node
			if self.tree_node == nil
				setCurrentNode(TreeNode.first)
			end
			@nodeChildren = self.tree_node.getNodeChildren
		end
		@nodeChildren
	end

	# Returns hash of node children of current model for use in view
	# 
	# @return [Hash] children of current node
	# @todo Move this to controller since it deals with views
	def getNodeChildrenHashForSelect
		nodeChld = getNodeChildren
		hash = {}
		nodeChld.count.times do |i|
			hash.merge!({nodeChld[i].name => i})
		end
		# add last item to add new scene
		hash.merge!({"---New Node---" => nodeChld.count})
		hash
	end

	# Get the user name of the person who has checked out this model
	# 
	# @return [String] user name of person who has checked out model, or none 
	def getCheckoutUserName
		if checkout_user == nil
			'None'
		else
			User.where(id: checkout_user).pluck(:username).first
		end
	end

	# Get checked-out status of this model by user
	#
	# @param (see #modelCheckout)
	# @return [Boolean] true if current user has checked out the model, else false
	def isModelCheckedout?(curUserId)
		checkout_user == curUserId ? true : false
	end

	# Get check-out-able status of this model by user
	#
	# Model is checkedoutable if user has not checked out any other model and
	# if the model hasn't been checkedout by another user. If
	# the user is a "builder", then it can checkout any number
	# of models in the "pre-build" state.
	# @param (see #modelCheckout)
	# @return [Boolean] true if current user can check out the model, else false
	def isModelCheckoutable?(curUserId)
		# the builder user can always checkout model in pre-build state
		if curUserId == User.getBuilderId && buildstatus == "pre-build"
			true
		elsif Model.where(checkout_user: curUserId).count > 0 || isModelBuilt? || buildstatus == "build-failure"
			false 
		else
			checkout_user == nil ? true : false
		end
	end

	# Checkout a model
	#
	# @param curUserId [Integer] id of current user
	# @todo Create return value
	def modelCheckout(curUserId)
		if isModelCheckoutable?(curUserId)
			update(checkout_user: curUserId)
		end
	end

	# Checkin a model
	#
	# @param (see #modelCheckout)
	# @todo Create return value
	def modelCheckin(curUserId)
		if isModelCheckedout?(curUserId)
			update(checkout_user: nil)
		end
	end

	# Check if the model is built
	#
	# @return [Boolean] true if building of this model is complete, else false
	def isModelBuilt?
		buildstatus == "build-complete" ? true : false
	end

	# Check if the model has built failure
	#
	# @return [Boolean] true if building of this model is complete, else false
	def isModelBuiltFailure?
		buildstatus == "build-failure" ? true : false
	end

	# Get formatted build status
	#
	# @todo Move this method to a helper module since it relates to view
	def getPrettyBuildStatus
		if buildstatus == "pre-build"
			"Not built"
		elsif buildstatus == "build-complete"
			"Build complete"
		elsif buildstatus == "build-failure"
			"Build failure"
		elsif buildstatus.split('-').first == "build"
			"Model building"
		else
			buildstatus.split('-').map(&:capitalize).join(' ')
		end
	end

	# Set build status of current model
	#
	# @param status [String] indicating build status from builder
	# @todo Create return value
	def setBuildStatus(status)
		if Model.buildstates.include?(status)
			update(buildstatus: status)
		end
	end

	# Gets images with specified image tags (and optionally text tags)
	#
	# @param imageTagUsage [String] image tag constants from {ImageTag}
	# @param modelTextTagId [Integer, nil] if non-nil, id of one of the text
	#   tags of specified model, {ModelTextTag}
	# @return [Set<Image>] list of images
	def getAllImages(imageTagUsage, modelTextTagId)
		if imageTagUsage == ImageTag::TEXT
			imgs = images.includes(:image_tags).where(image_tags: {usage: imageTagUsage, model_text_tag_id: modelTextTagId}).order('id desc')
		else
			# if model is built and looking at test images
			if isModelBuilt? && (imageTagUsage == ImageTag::TEST_POS)
				imgs = images.includes(:image_tags).where(image_tags: {usage: imageTagUsage}).order('image_tags.detection_score desc')
			elsif isModelBuilt? && (imageTagUsage == ImageTag::TEST_NEG)		
				imgs = images.includes(:image_tags).where(image_tags: {usage: imageTagUsage}).order('image_tags.detection_score asc')
			else
				imgs = images.includes(:image_tags).where(image_tags: {usage: imageTagUsage}).order('id asc')
			end
		end
		imgs
	end

	# some class methods:

	# Class method to return file not found string
	# @return [String] returns 'FileNotFoundString'
	def self.fileNotFoundString
		'FileNotFoundString'
	end

	# Class method to return algorithms
	# @return [Array<String, Integer>] a list of algorithms
	def self.algorithms
		[['StructSVM-Generic', 0],['StructSVM', 1],['MHMP', 2]]
	end

	# Class method to return potential build states
	# @return [Array<String>] a list of build states
	# @todo Change into hash for easy calling
	def self.buildstates
		["build-queue", "build-start", "build-initialize-instance",
		 "build-train-start", "build-train-complete", "build-test-start",
		  "build-test-complete", "build-complete", "build-shutdown-instance",
		  "build-failure", "pre-build"
		]
	end

	# Class method to return algorithms
	# @return [Array<String, Integer>] a list of model types
	def self.modelTypes
		[['Scene', 0],['Object', 1],['Activity', 2]]
	end

	has_many :image_tags, dependent: :destroy # since not all image tags relate to text tags, destroy these
	has_many :images, through: :image_tags
	has_many :model_text_tags, dependent: :destroy
	has_many :video_detections, dependent: :destroy
	belongs_to :tree_node
	belongs_to :user
end
