class ModelTextTag < ActiveRecord::Base
	validates :user, presence: true
	validates :model, presence: true
	validates :tag, presence: true, allow_blank: false

	# unassigned tag
	UNASSIGNED = "Unassigned"
	
    has_many :image_tags, dependent: :destroy
    belongs_to :model
    belongs_to :user
end
