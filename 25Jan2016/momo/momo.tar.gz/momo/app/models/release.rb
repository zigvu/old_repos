class Release < ActiveRecord::Base
	serialize :tree, Hash

	BUILDSTATE = {
		build_queue: "build-queue",
		build_start: "build-start",
		build_initialize_instance: "build-initialize-instance",
		build_complete: "build-complete",
		build_shutdown_instance: "build-shutdown-instance",
		build_failure: "build-failure",
		pre_build: "pre-build"
	}


	belongs_to :user
end
