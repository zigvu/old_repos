class SpotManager < ActiveRecord::Base
	validates :user, presence: true

	# Type of EC2 spot instance being requested
	INSTANCETYPE = {
		t1_micro: 't1.micro',
		m1_small: 'm1.small',
		m1_medium: 'm1.medium',
		m1_large: 'm1.large',
		m1_xlarge: 'm1.xlarge',
		m3_xlarge: 'm3.xlarge',
		m3_2xlarge: 'm3.2xlarge',
		m2_xlarge: 'm2.xlarge',
		m2_2xlarge: 'm2.2xlarge',
		m2_4xlarge: 'm2.4xlarge',
		c1_medium: 'c1.medium',
		c1_xlarge: 'c1.xlarge',
		c3_large: 'c3.large',
		c3_xlarge: 'c3.xlarge',
		c3_2xlarge: 'c3.2xlarge',
		c3_4xlarge: 'c3.4xlarge',
		c3_8xlarge: 'c3.8xlarge',
		cc2_8xlarge: 'cc2.8xlarge',
		cr1_8xlarge: 'cr1.8xlarge',
		g2_2xlarge: 'g2.2xlarge'
	}

	# Builder task for which instance is being requested 
	TASK = {
		model: 'model', 
		video: 'video'
	}

	# Behavior when a bid task fails
	FAILUREBEHAVIOR = {
		terminate: 'terminate',
		rebid: 'rebid',
		ondemand: 'ondemand'
	}

	belongs_to :user
end
