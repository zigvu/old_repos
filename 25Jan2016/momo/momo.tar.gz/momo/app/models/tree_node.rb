# Base class for tree nodes.
# 
# This class assembles {Model} classes in a tree structure.
# Withhin each tree node, there can be one or more
# {TreeNode} and/or {Model}.
class TreeNode < ActiveRecord::Base
	acts_as_tree
	validates :user, presence: true
	validates :name, presence: true

	# Constant denoting JSON usage for tree node for display in tree
	JSONUSAGE = {
		videoShow: "videoShow",
		videoLabel: "videoLabel",
		videoAddModels: "videoAddModels",
		videoParallelChartModels: "videoParallelChartModels",
		videoParallelChartVideos: "videoParallelChartVideos",
		modelIndex: "modelIndex",
		releaseShow: "releaseShow"
	}

	# Get the parents of current node, up to tree root
	#
	# @return [Array<TreeNode>] an array of tree nodes in order
	#  from root to current node
	def getNodeParents
		nodeParents = []
		tempNode = parent
		while tempNode != nil
			nodeParents = nodeParents + [tempNode]
			tempNode = tempNode.parent
		end
		# reverse and return list
		nodeParents.reverse
	end

	# Get the children of current node, up to leaf node
	#
	# @return [Array<TreeNode>] an array of tree nodes in order
	#  from current node to leaf node
	def getNodeChildren
		children.to_a
	end

	# Class method to recursively get JSON representation of the children below
	# current node
	#
	# @return [String] JSON representing all tree nodes below the current node
	#  in a format useful for cellroti system
	def getAllChildrenNodeJSON
		# input information about this tree node:
		retJSON = {
			:id => id,
			:name => name,
			:description => description,
			:comment => comment
		}

		# if this node has children:
		if children.count > 0
			childrenJSON = []
			children.map do |child|
				childrenJSON << child.getAllChildrenNodeJSON
			end
			retJSON.merge!(:"children" => childrenJSON)
		end

		retJSON
	end

	# Method to get JSON representation of videos for this treenode
	#
	# @return [String] JSON entry to display one row of video information in table.
	def videoJSONMethod
		retJSON = []
		videos.map do |video|
			retJSON << {
				:"key" => video.id.to_s,
				:"node_type" => "video",
				:"title" => video.title,
				:"tooltip" => "Video - " + video.title + ", Last updated: " + video.updated_at.to_formatted_s(:short),
				:"extraClasses" => "fancyTreeClassVideo"
			}
		end
		retJSON
	end

	# create class methods:

	# Class method to get single JSON representation of specified model
	#
	# @param user [User] current user
	# @param model [Model] for which to get the JSON information
	# @param video [Video, nil] if non-nil, video associated for this JSON
	# @param usage [String] one of the constants identified in JSONUSAGE of {TreeNode}
	# @return [String] JSON entry to display one row in tree node table. This entry is
	#  dependent on usage
	def self.modelJSONMethod(user, model, video, usage)
		retJSON = {
			:"key" => model.id.to_s,
			:"node_type" => "model",
			:"title" => model.name + " , V: " + model.model_version.to_s,
			:"tooltip" => "Model - " + model.name + ", V: " + model.model_version.to_s + ", Last updated: " + model.updated_at.to_formatted_s(:short),
			:"extraClasses" => "fancyTreeClassModel"
		}
		
		if usage == TreeNode::JSONUSAGE[:videoShow]
			video_eval_class = video.getModelVideoDetection(model.id).classification.capitalize
			retJSON.merge!(:"evaluate_class" => video_eval_class)
		elsif usage == TreeNode::JSONUSAGE[:videoLabel]
			# labeling video is at the treenode level, so have models be empty
			retJSON = nil
		elsif usage == TreeNode::JSONUSAGE[:videoAddModels]
			vd = video.getModelVideoDetection(model.id)
			if vd == nil
				retJSON.merge!(:"evaluate_class" => "-")
			elsif vd.classification == VideoDetection::CLASSIFICATION[:evaluateQueue]
				retJSON.merge!(:"evaluate_class" => "Evaluate-queue")
				retJSON.merge!(:"selected" => "true")
			else
				retJSON.merge!(:"evaluate_class" => vd.classification.capitalize)
				retJSON.merge!(:"hideCheckbox" => "true")
				retJSON.merge!(:"unselectable" => "true")
			end
		elsif usage == TreeNode::JSONUSAGE[:modelIndex]
			retJSON.merge!(:"model_type" => model.model_type)
			retJSON.merge!(:"algorithm" => model.algorithm)
			retJSON.merge!(:"build_status" => model.getPrettyBuildStatus)
			if model.isModelCheckedout?(user.id)
				retJSON.merge!(:"checkout" => "Checkin")
			elsif model.isModelBuilt?
				retJSON.merge!(:"checkout" => "Built")
			elsif model.isModelBuiltFailure?
				retJSON.merge!(:"checkout" => "Build-Failure")
			elsif model.isModelCheckoutable?(user.id)
				retJSON.merge!(:"checkout" => "Checkout")
			else
				retJSON.merge!(:"checkout" => model.getCheckoutUserName)
			end
			retJSON.merge!(:"show" => "Show")
		elsif usage == TreeNode::JSONUSAGE[:videoParallelChartModels]
			# no special change for now
		elsif usage == TreeNode::JSONUSAGE[:videoParallelChartVideos]
			# labeling video is at the treenode level, so have models be empty
			retJSON = nil
		elsif usage == TreeNode::JSONUSAGE[:releaseShow]
			retJSON.merge!(:"model_type" => model.model_type)
			if @releasedModelIds != nil && @releasedModelIds.count > 0 && @releasedModelIds.include?(model.id)
				retJSON.merge!(:"selected" => "true")
			end
		end
		retJSON
	end

	# Class method to get single JSON representation of specified treenode
	#
	# @param user [User] current user
	# @param treeNode [TreeNode] for which to get the JSON information
	# @param video [Video, nil] if non-nil, video associated for this JSON
	# @param usage [String] one of the constants identified in JSONUSAGE of {TreeNode}
	# @return (see #modelJSONMethod)
	def self.treeNodeJSONMethod(user, treeNode, video, usage)
		retJSON = {
			:"key" => treeNode.id.to_s,
			:"node_type" => "treenode",
			:"title" => treeNode.name,
			:"tooltip" => "TreeNode - " + treeNode.name,
			:"evaluate_class" => "-",
			:"extraClasses" => "fancyTreeClassTreeNode"
		}
		if usage == TreeNode::JSONUSAGE[:videoShow]
			# no special change for now
		elsif usage == TreeNode::JSONUSAGE[:videoAddModels]
			# no special change for now
		elsif usage == TreeNode::JSONUSAGE[:videoLabel]
			if video.hasVideoLabel?(treeNode.id)
				retJSON.merge!(:"selected" => "true")
				retJSON.merge!(:"expand" => "true")
			end
		elsif usage == TreeNode::JSONUSAGE[:modelIndex]
			retJSON.merge!(:"comments" => '-')
			retJSON.merge!(:"algorithm" => '-')
			retJSON.merge!(:"build_status" => '-')
			retJSON.merge!(:"checkout" => '-')
			retJSON.merge!(:"show" => '-')
		elsif usage == TreeNode::JSONUSAGE[:videoParallelChartModels]
			# no special change for now
		elsif usage == TreeNode::JSONUSAGE[:videoParallelChartVideos]
			# videos are labeled at leaf nodes of tree
			if treeNode.children.count <= 0
				# if this tree node has no video, it is not a folder
				if treeNode.videos.count > 0
					retJSON.merge!(:"lazy" => "true")
					retJSON.merge!(:"folder" => "true")
				end
				retJSON[:"title"] = retJSON[:"title"] + " (" + treeNode.videos.count.to_s + ")"
			end
			# unselectable
			retJSON.merge!(:"hideCheckbox" => "true")
			retJSON.merge!(:"unselectable" => "true")
		elsif usage == TreeNode::JSONUSAGE[:releaseShow]
			if @releasedNodeIds != nil && @releasedNodeIds.count > 0 && @releasedNodeIds.include?(treeNode.id)
				retJSON.merge!(:"node_selected" => "true")
			else
				retJSON.merge!(:"node_selected" => "false")
			end
		end
		retJSON
	end

	# Class method to recursively get JSON for tree node table
	#
	# @param curUser [User] current user
	# @param rootNode [TreeNode] the very first node in the tree node hierarchy
	# @param validTreeNodes [Array<TreeNode>] an array of tree nodes that are valid
	#  to display in the tree node table
	# @param validModels [Array<Model>] an array of models that are valid
	#  to display in the model table
	# @param curVideo [Video, nil] if non-nil, video associated for this tree node table
	# @param usage [String] one of the constants identified in JSONUSAGE of {TreeNode}
	# @return [String] JSON representing the whole tree node table, as expected by FancyTree
	#  javascript library
	def self.recurseTreeNodeForTable(curUser, rootNode, validTreeNodes, validModels, curVideo, usage)
		retJSON = {}
		children = rootNode.children

		# if this tree node has no children
		if children.count == 0
			models = rootNode.models
			if models.count != 0
				modelJSON = []
				models.map do |model|
					# validate that model should be included
					if validModels.include?(model)
						modelJSON << modelJSONMethod(curUser, model, curVideo, usage)
					end
				end
				# add treenode only if there are valid models:
				if modelJSON.count > 0
					nodeJSON = treeNodeJSONMethod(curUser, rootNode, curVideo, usage)
					if modelJSON[0] != nil
						nodeJSON.merge!(:"children" => modelJSON)
					end
					retJSON.merge!(nodeJSON)
				end
			end
		else
			childJSON = []
			children.map do |child|
				# validate that tree node should be looked into
				if validTreeNodes.include?(child)
					tempReturn = recurseTreeNodeForTable(curUser, child, validTreeNodes, validModels, curVideo, usage)

					# don't include empty branches
					if tempReturn.count > 0
						childJSON << tempReturn
					end
				end
			end
			if childJSON.count > 0
				nodeJSON = treeNodeJSONMethod(curUser, rootNode, curVideo, usage)
				if childJSON[0] != nil
					nodeJSON.merge!(:"children" => childJSON)
				end
				retJSON.merge!(nodeJSON)
			end
		end
		retJSON
	end

	# Get treenode and model information for tree node table.
	#
	# @param curUser [User] current user
	# @param models [Array<Model>] an array of models that are valid
	#  to display in the model table
	# @param video [Video, nil] if non-nil, video associated for this tree node table
	# @param usage [String] one of the constants identified in JSONUSAGE of {TreeNode}
	# @return [Array<String>] each string in the array is a Hash with 
	#   treenode, model and video detection information
	def self.getJSONForSelectionTable(curUser, models, video, usage, releasedModelIds = nil, releasedNodeIds = nil)
		# Get already selected releases
		@releasedModelIds = releasedModelIds
		@releasedNodeIds = releasedNodeIds

		# first, get all parent nodes for models
		treeNodeParents = []
		models.map do |model|
			tn = model.tree_node
			if !treeNodeParents.include?(tn)
				treeNodeParents << tn
			end

			treeNodes = model.getNodeParents
			treeNodes.map do |tn|
				if !treeNodeParents.include?(tn)
					treeNodeParents << tn
				end
			end
		end

		recurseTreeNodeForTable(curUser, TreeNode.first, treeNodeParents, models, video, usage)
	end

	def getReleases(modelIDs)
		models = Model.where(id: modelIDs)
		# first, get all parent nodes for models
		treeNodeParents = []
		models.map do |model|
			tn = model.tree_node
			if !treeNodeParents.include?(tn)
				treeNodeParents << tn
			end

			treeNodes = model.getNodeParents
			treeNodes.map do |tn|
				if !treeNodeParents.include?(tn)
					treeNodeParents << tn
				end
			end
		end

		{:root => getAllReleasesJSON(models, treeNodeParents)}
	end

	# Class method to recursively get JSON representation of the 
	# children models and treenodes below current node
	#
	# @param curUser [User] current user
	# @return [String] JSON representing all models tree nodes below the current node
	#  in a format useful for cellroti system
	def getAllReleasesJSON(allowedModels, allowedTreeNodes)
		# input information about this tree node:
		retJSON = {
			:id => id,
			:name => name,
			:description => description,
			:comment => comment
		}
		modelJSON = nil
		models.each do |model|
			allowedModels.each do |amodel|
				if model.id == amodel.id
					modelJSON = {
						:id => model.id,
						:name => model.name,
						:model_version => model.model_version,
						:algorithm => model.algorithm,
						:model_type => model.model_type,
						:model_url => model.get_S3_model_file
					}
				end
			end
		end
		if modelJSON != nil
			retJSON.merge!(:"model" => modelJSON)
		end

		# if this node has children:
		if children.count > 0
			childrenJSON = []
			children.map do |child|
				allowedTreeNodes.each do |atreeNode|
					if child.id == atreeNode.id
						childrenJSON << child.getAllReleasesJSON(allowedModels, allowedTreeNodes)
					end
				end
			end
			retJSON.merge!(:"children" => childrenJSON)
		end

		retJSON
	end

	has_many :models, dependent: :destroy
	has_many :video_labels, dependent: :destroy
	has_many :videos, through: :video_labels
  belongs_to :user
end
