class User < ActiveRecord::Base
  # Include default devise modules. Others available are:
  # :token_authenticatable, :confirmable,
  # :lockable, :timeoutable and :omniauthable
  devise :database_authenticatable, :registerable,
  :recoverable, :rememberable, :trackable, :validatable,
  :token_authenticatable

  validates :username, presence: true
  validates :username, uniqueness: true

  after_create :create_user_settings

  BUILDER = "builder"

  # some class methods:
  def self.getBuilderId
    User.where(username: User::BUILDER).pluck(:id).first
  end

  has_many :images
  has_many :tree_nodes
  has_many :models
  has_many :model_text_tags
  has_many :image_tags
  has_many :videos
  has_many :video_labels
  has_many :video_frame_tags
  has_many :spot_managers
  has_one  :user_setting, dependent: :destroy
  has_many :releases

  private
    def create_user_settings
      userSetting = UserSetting.create(user_id: id)
      Services::SettingsHandler.new(userSetting).resetAllSettings
    end
end
