class UserSetting < ActiveRecord::Base
	serialize :selections, Hash
	serialize :clipboard, Hash
	serialize :preferences, Hash

	belongs_to :user
end
