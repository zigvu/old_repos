require "open-uri"

# Base class for videos.
# 
# This class keeps track of all videos
class Video < ActiveRecord::Base
	include ApplicationHelper

	validates :user, presence: true

	# Video source type - currently only youtube upload is supported
	SOURCETYPE = {
		desktop: "desktop",
		youtube: "youtube"
	}
	# Video status w.r.t. back-end builder
	VIDEOSTATUS = {
		s3uploadQueue: 's3-upload-queue',
		s3uploaded: 's3-uploaded', 
		s3ready: 's3-ready',
		s3deleted: 's3-deleted'
	}
	# Current task for builder
	VIDEOTASK = {
		uploadQueue: 'upload-queue', 
		uploadCurrent: 'upload-current', 
		uploadSuccess: 'upload-success',
		uploadFail: 'upload-failure',
		inspectQueue: 'inspect-queue', 
		inspectCurrent: 'inspect-current', 
		inspectSuccess: 'inspect-success',
		inspectFail: 'inspect-failure',
		evaluateQueue: 'evaluate-queue', 
		evaluateCurrent: 'evaluate-current', 
		evaluateSuccess: 'evaluate-success',
		evaluateFail: 'evaluate-failure'
	}

	###########################################################
	# Setup paperclip
	# evan temp debug: uncomment below:
	#validates_attachment_presence :upload
	#validates_attachment_size :upload, :less_than => 500.megabytes
	if Rails.env.local?
		has_attached_file :upload
	else
		has_attached_file :upload, 
					:bucket => S3HOSTBUCKETVIDEO,
					:s3_host_alias => S3HOSTVIDEOS
	end
	
	include Rails.application.routes.url_helpers

	# JSON handler for Jquery-file-upload library
	#
	# Seel also {Image#to_jq_upload}
	# @return [Hash{String => Symbol, Number}] hash indicating file name, size, url,
	#   delete url, and delete method type
	def to_jq_upload 
		{
			"name" => read_attribute(:upload_file_name),
			"size" => read_attribute(:upload_file_size),
			"url" => upload.url(:original),
			"delete_url" => video_path(self),
			"delete_type" => "DELETE"
		}
	end

	# Link paper clip object from S3 URL.
	#
	# Once user puts a file in S3 upload queue, the back-end downloads the file
	# and sends a S3 URL to update the database. This URL is used to build the
	# paperclip object.
	# @param url [String] from which to upload the file
	# @todo Create return value
	def upload_from_S3_url(url)
		# below downloads the whole video and then re-uploads
		#self.upload = URI.parse(url)
		# to avoid downloading the whole video and then re-uploading, hack:
		fileName = url.split('/').last
		contentType = MIME::Types.type_for(fileName).first.content_type.to_s
		self.update(upload_file_name: fileName, upload_content_type: contentType)
	end

	# Get URL of current video
	#
	# If the rails environment is non-local, an expiring S3 URL is served
	# @return [String] expiring S3 URL 
	def getURL
		if Rails.env.local?
			upload.url
		else
			upload.expiring_url(Image::S3URLEXPTIME)
		end
	end

	# Done setting up paperclip
	###########################################################

	# Get video/model detection data for charting
	#
	# @param modelArray [Array<Model>] array of models that will be displayed
	#   in chart
	# @return [Array<String>] each string in the array is a Hash with data for plotting
	#   a single frame detection (across models)
	def getJSONForChart(modelArray)
		retJSON = []

		# ensure that videoDetectionsArray is ordered the same way as modelId
		videoDetectionsArray = []
		modelArray.each do |modelId|
			videoDetectionsArray << video_detections.where(model_id: modelId).first.id
		end

		videoFrames = video_frames.includes(:frame_detections)
		.where(frame_detections: {video_detection_id: videoDetectionsArray})

		# create score array so that scores are persistent across frames that have gaps
		vfScores = []
		vfModelNames = []
		for i in 0..modelArray.count-1
			vfScores << 0
			#vfModelNames << modelArray[i].to_s + ": " + Model.find(modelArray[i]).name
			curModel = Model.find(modelArray[i])
			vfModelNames << curModel.name + ":V" + curModel.model_version.to_s
		end

		videoFrames.map do |vf|
			vfDate = vf.frame_position

			for i in 0..modelArray.count-1
				# if this frame doesn't have a detection for this model, skip and use
				# prior frame detection score
				if vf.frame_detections.find_by(video_detection_id: videoDetectionsArray[i]) != nil
					vfScores[i] = vf.frame_detections.find_by(video_detection_id: videoDetectionsArray[i]).frame_score
				end
			end
			#vfCumulative = vfScores.sum.to_f / vfScores.count
			vfCumulative = vfScores.max + 0.1

			vfJSON = {
				:"date" => beautyTimeMilliseconds(vfDate).to_s, 
				:"Cumulative" => vfCumulative.round(4).to_s, 
				:"Zero-line" => "0"
			}

			# add all model scores:
			for i in 0..modelArray.count-1
				vfJSON.merge!(vfModelNames[i] => vfScores[i].round(4).to_s)
			end

			retJSON << vfJSON
		end
		retJSON
	end

	# Get video frames for brushing in chart
	#
	# @param (see #getJSONForChart)
	# @param brushExtLeft [Integer] time in milliseconds after which frames will be extracted
	# @param brushExtRight [Integer] time in milliseconds before which frames will be extracted
	# @return [Set<VideoFrame>] frames that have timestamp between 
	#   brushExtLeft and brushExtRight	
	def getVideoFramesForBrushing(modelArray, brushExtLeft, brushExtRight)
		videoDetectionsArray = video_detections.where(model_id: [modelArray]).pluck(:id)
		video_frames.includes(:frame_detections)
		.where(frame_detections: {video_detection_id: videoDetectionsArray})
		.where(frame_position: brushExtLeft..brushExtRight)
	end

	# Get score for single frame detection for a model
	#
	# @param modelId [Integer] id of the {Model} for which to retrieve frame detection score
	# @return [Float] score for frame detection
	# @note A model may only be evaluated once against each video,
	#   so guaranteed to have only one video detection per model/video pair
	def getModelVideoDetection(modelId)
		video_detections.where(model_id: modelId).first
	end

	# Set model detection state to new state for this video/model pair
	#
	# @param modelId [Integer] id of {Model} for which this detection happened
	# @param newDetectionState [String] one of constants in {VideoDetection::CLASSIFICATION}
	# @param newScore [Float, nil] if model detection is complete, put score, else nil
	# @todo Create return value
	def setModelVideoDetection(modelId, newDetectionState, newScore)
		# new detection state can't be nil
		if newDetectionState == nil
			return
		end
		currentDetection = getModelVideoDetection(modelId)
		if currentDetection == nil
			video_detections.create(model_id: modelId, classification: VideoDetection::CLASSIFICATION[:evaluateQueue])
		elsif currentDetection.classification == VideoDetection::CLASSIFICATION[:evaluateQueue] || 
			currentDetection.classification == VideoDetection::CLASSIFICATION[:evaluateCurrent]
			currentDetection.update(classification: newDetectionState, score: newScore)
		else
			# do nothing for now - if already classified, no change here
		end
	end

	# Checks if given video/model pair is in a certain detection state
	#
	# @param modelId [Integer] id of {Model} for which this detection happened
	# @param detectionState [String] one of constants in {VideoDetection::CLASSIFICATION}
	# @return [Boolean] true if this video/model pair is in specified detection state
	def isModelInVideoDetectionState?(modelId, detectionState)
		video_detections.where(model_id: modelId).where(classification: detectionState).count > 0 ? true : false
	end

	# Get all models associated with this video
	#
	# @return [Set<Model>] list of models which are associated with this video
	def getCurrentModels
		Model.includes(:video_detections).where(video_detections: {video_id: id})
	end

	# Get all models in specified video detection state
	#
	# @param detectionState [String] one of constants in {VideoDetection::CLASSIFICATION}
	# @return [Set<Model>] list of models in given video detection state
	def getModelsInVideoDetectionState(detectionState)
		getCurrentModels.includes(:video_detections).where(video_detections: {classification: detectionState})
	end
	
	# Checks if current video is labeled with a given treenode
	#
	# @param treeNodeId [Integer] id of {TreeNode}
	# @return [Boolean] true if video is labeled with given treenode, else false
	def hasVideoLabel?(treeNodeId)
		video_labels.where(tree_node_id: treeNodeId).count > 0 ? true : false
	end

	# Adds a treenode to the list of labels
	#
	# @param curUser [User] current user
	# @param treeNodeId [Integer] id of {TreeNode}
	# @todo Create return value
	def addVideoLabel(curUser, treeNodeId)
		if !hasVideoLabel?(treeNodeId)
			video_labels.create(user_id: curUser.id, tree_node_id: treeNodeId)
		end
	end

	# Remove a treenode from the list of labels
	#
	# @param treeNodeId [Integer] id of {TreeNode}
	# @todo Create return value
	def removeVideoLabel(treeNodeId)
		video_labels.where(tree_node_id: treeNodeId).destroy_all
	end


	default_scope { order('created_at desc') }
	has_many :video_frames, dependent: :destroy
	has_many :frame_detections, through: :video_frames
	has_many :video_detections, dependent: :destroy
	has_many :video_labels, dependent: :destroy
	has_many :tree_nodes, through: :video_labels
	has_many :video_frame_tags, through: :video_frames
	belongs_to :user
end
