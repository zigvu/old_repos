# Base class for video detection.
# 
# For each video/model pair, there is a unique video detection
# item. A user may request the back-end to evaluate a video
# with a model by putting the video in evaluate queue state from
# the UI. At that time, a new VideoDetection object is created
# with "evaluate-queue" state.
class VideoDetection < ActiveRecord::Base
	validates :video, presence: true
	validates :model, presence: true

	# State of this video/model pair detection
	CLASSIFICATION = {
		evaluateQueue: 'evaluate-queue', 
		evaluateCurrent: 'evaluate-current', 
		positive: "positive",
		negative: "negative",
		evaluateFail: 'evaluate-failure'
	}

	def getJSONForParallelChartSingle

	end

	def self.getJSONForParallelChart(modelArray, videoArray)
		retJSON = []
		videoArray.map do |vA|
			v = Video.find(vA)
			vStartTime = v.video_frames.order("frame_position ASC").first.frame_position
			vEndTime = v.video_frames.order("frame_position ASC").last.frame_position
			vDuration = vEndTime - vStartTime

			vDetections = v.video_detections.where(model_id: modelArray)
			vDetections.map do |vd|
				vdFrameDetections = vd.frame_detections
				vdFrameDetections.map do |vdf|
					timePercentage = (vdf.video_frame.frame_position - vStartTime) / vDuration.to_f
					vdfJSON = {
						:"VideoFrameId" => vdf.video_frame_id.to_s,
						:"ModelId" => vd.model.id,
						:"Video" => "Video ID: " + v.id.to_s,
						:"Time" => timePercentage.to_f,
						:"FrameScore" => vdf.frame_score.to_f,
						:"Model" => vd.model.name + ":V" + vd.model.model_version.to_s
					}
					retJSON << vdfJSON
				end
			end
		end
		retJSON
	end


	has_many :frame_detections, dependent: :destroy
	belongs_to :video
	belongs_to :model
end
