# Base class for video frames.
# 
# When a video is to be evaluated against a model, the backend
# creates static video frames, evaluate the frame against the
# model, stores the frame (and optionally the associated feature)
# in S3 and returns back S3 URL and score for the frame. 
class VideoFrame < ActiveRecord::Base
	default_scope { order('frame_position ASC') }

	# Get URL of a video frame
	#
	# If the rails environment is non-local, an expiring S3 URL is served
	# @return [String] expiring S3 URL 
	def getURL
		if Rails.env.local?
			self.S3_URL
		else
			s3url = self.S3_URL
			# reconstruct the bucket and file name from S3_URL field
			# s3url = 's3-us-west-2.amazonaws.com/zigvuvideosdevelopment/uploads/1/5184/original.png'
			bucket = s3url[(s3url.index('.com/')+5)..(s3url.index('uploads')-2)]
			fileName = s3url[s3url.index('uploads')..-1]
			AWS::S3.new.buckets[bucket].objects[fileName].url_for(:read).to_s
		end
	end

	# Toggle the state of this video frame as the user clicks/unclicks on the image
	#
	# @param userId [Integer] id of current user
	def toggleClicked(userId)
		if hasTag?(userId, ImageTag::TEMP)
			unsetTag(userId, ImageTag::TEMP)
		else
			setTag(userId, ImageTag::TEMP)
		end
	end

	# Checks if current video frame has given tag
	#
	# @param userId [Integer] id of current user
	# @param curUsage [String] one of usage constants from {ImageTag}
	# @return [Boolean] true if current frame has given usage associated with it, else false
	def hasTag?(userId, curUsage)
		video_frame_tags.where(user_id: userId).where(usage: curUsage).count > 0 ? true : false
	end

	# Set a tag for current video frame
	#
	# @param (see #hasTag?)
	# @todo Create return value
	def setTag(userId, curUsage)
		if !hasTag?(userId, curUsage)
			video_frame_tags.create(user_id: userId, usage: curUsage)
		end
	end

	# Unset a tag for current video frame
	#
	# @param (see #setTag)
	# @todo Create return value
	def unsetTag(userId, curUsage)
		video_frame_tags.where(user_id: userId).where(usage: curUsage).destroy_all
	end

	# Get detection score for this frame/model pair
	#
	# A frame is evaluated only once against a model.
	# @param modelId [Integer] id of {Model} for which this detection happened
	def getDetectionScore(modelId)
		# assume that a model gets evaluated with a particular frame only once:
		fd = frame_detections.includes(:video_detection).where(video_detections: {model_id: modelId}).first
		if (fd != nil) && (fd.frame_score != nil)
			fd.frame_score
		else
			# we should never get this value - prior to saving a video frame, we would have
			# updated the frame_score
			nil
		end
	end


	belongs_to :video
	has_many :frame_detections, dependent: :destroy
	has_many :video_frame_tags, dependent: :destroy
end
