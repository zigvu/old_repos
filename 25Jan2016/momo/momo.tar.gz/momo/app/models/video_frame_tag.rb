# Base class for video frame tags.
# 
# For every frame event, there is a corresponding {VideoFrameTag} created.
# This class is analogous to {ImageTag} class in images.
class VideoFrameTag < ActiveRecord::Base

	# Class method to add selected frames to clipboard
	#
	# Once frames are added to clipboard, they are automatically removed
	# from TEMP state
	# @param curUser [User] current user
	# @todo Create return value
	def self.addSelectedToClipboard(curUser)
		clickedTags = VideoFrameTag.where(user_id: curUser.id).where(usage: ImageTag::TEMP)
		clickedTags.map do |clickedTag|
			# if the video frame is already in the clipboard, ignore:
			if VideoFrameTag.where(user_id: curUser.id)
				.where(usage: ImageTag::CLIPBOARD)
				.where(video_frame_id: clickedTag.video_frame_id)
				.count <= 0
				clickedTag.update(usage: ImageTag::CLIPBOARD)
			end
		end
		# reset temp images:
		VideoFrameTag.where(user_id: curUser.id).where(usage: ImageTag::TEMP).destroy_all
	end

	# Class method to remove selected frames from clipboard
	#
	# Once frames are removed from clipboard, they are also automatically removed
	# from TEMP state
	# @param curUser [User] current user
	# @todo Create return value
	def self.removeSelectedFromClipboard(curUser)
		clickedVideoFrames = VideoFrame.includes(:video_frame_tags).where(video_frame_tags: {user_id: curUser.id, usage: ImageTag::TEMP})
		clickedVideoFrames.map do |clickedVideoFrame|
			clickedVideoFrame.video_frame_tags.where(user_id: curUser.id).where(usage: [ImageTag::TEMP, ImageTag::CLIPBOARD]).destroy_all
		end
	end

	# Class method to set all video frames in clipboard to TEMP
	#
	# @param curUser [User] current user
	# @todo Create return value
	def self.setTempAllVideFramesInClipboard(curUser)
		# reset temp images first:
		VideoFrameTag.where(user_id: curUser.id).where(usage: ImageTag::TEMP).destroy_all
		clickedTags = VideoFrameTag.where(user_id: curUser.id).where(usage: ImageTag::CLIPBOARD)
		clickedTags.map do |clickedTag|
			VideoFrameTag.create(user_id: curUser.id, video_frame_id: clickedTag.video_frame_id, usage: ImageTag::TEMP)
		end
	end

	belongs_to :user
	belongs_to :video_frame
end
