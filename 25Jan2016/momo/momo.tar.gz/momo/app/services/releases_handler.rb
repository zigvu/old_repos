module Services
	class ReleasesHandler
		require 'json'
		#attr_accessor :models, :nodes

		def initialize(release)
			@release = release
			@mappingFile = 'mapping.txt'
			@s3_URL = "uploads/#{@release.id}/input"
			@local_URL = "public/system/releases/#{@release.id}/input"
		end

		def start_build_process
			# first, save files to s3
			if release_save_to_s3
				if Rails.env.local?
					return @release.update(buildstatus: Release::BUILDSTATE[:build_queue], S3_URL: @local_URL)
				else
					return @release.update(buildstatus: Release::BUILDSTATE[:build_queue], S3_URL: @s3_URL)
				end
			else
				return false
			end
		end

		def release_save_to_s3
			mappingHash = release_mapping_hash
			save_hash_to_file(mappingHash, @mappingFile)

			nodeIds = @release.tree[:nodes]
			nodeIds.each do |nodeId|
				nodeImageIds = release_imageids_array(nodeId)
				tn = TreeNode.find(nodeId)
				nodeHash = {node_id: tn.id, node_name: tn.name, images: nodeImageIds}
				save_hash_to_file(nodeHash, "#{nodeId}.txt")
			end

			if Rails.env.local?
				return true
			else
				# count number of files in S3 to ensure files are saved
				@awsBucket = @awsBucket || AWS::S3.new.buckets[S3HOSTBUCKETRELEASE]
				obj = @awsBucket.objects.with_prefix(@s3_URL)
				return (obj.count != (nodeIds.count + 1))
			end
		end

		def save_hash_to_file(hash, filename)
			localFileName = "/tmp/#{filename}"
			File.open(localFileName, 'w') do |f|
				f.write(hash.to_json)
			end
			if Rails.env.local?
				FileUtils.mkdir_p(@local_URL)
				FileUtils.cp(localFileName, @local_URL)
			else
				@awsBucket = @awsBucket || AWS::S3.new.buckets[S3HOSTBUCKETRELEASE]
				obj = @awsBucket.objects["#{@s3_URL}/#{filename}"]
				obj.write(Pathname.new(localFileName))
			end
			File.delete(localFileName)
		end

		def release_imageids_array(nodeId)
			modelIds = @release.tree[:models]
			
			tn = TreeNode.find(nodeId)
			selModelIds = []
			tn.self_and_descendants.each do |tnd|
				tndModelIds = tnd.models.pluck(:id)
				tndModelIds.each do |tndmId|
					selModelIds << tndmId if modelIds.include?(tndmId)
				end
			end

			imageIds = []
			weakModelId = TreeNode.where(name: ImageTag::WEAKMODEL).pluck(:id).first
			if nodeId == weakModelId
				# if this is weak model node, then the positive examples consists of
				# all negative images from rest of the models
				restModelIds = modelIds - selModelIds
				restModelIds.each do |rModelId|
					imageIds << Model.find(rModelId).getAllImages(ImageTag::TRAIN_NEG, nil).pluck(:id)
				end
				imageIds.flatten!
				imageIds.uniq!
			else
				selModelIds.each do |sModelId|
					imageIds << Model.find(sModelId).getAllImages(ImageTag::TRAIN_POS, nil).pluck(:id)
				end
				imageIds.flatten!
				imageIds.uniq!
			end

			return imageIds
		end

		def release_mapping_hash
			modelIds = @release.tree[:models]
			nodeIds = @release.tree[:nodes]

			retHash = []
			nodeIds.each do |nodeId|
				tn = TreeNode.find(nodeId)
				# get models in self and children
				selectedModelHash = []
				tn.self_and_descendants.each do |tnd|
					tndModelIds = tnd.models.pluck(:id)
					tndModelIds.each do |tndmId|
						if modelIds.include?(tndmId)
							m = Model.find(tndmId)
							selectedModelHash << {model_id: m.id, model_name: m.name, model_version: m.model_version}
						end
					end
				end
				# write hash
				retHash << {node_id: tn.id, node_name: tn.name, models: selectedModelHash}
			end
			return retHash
		end

		def update_release(modelIds, nodeIds)
			if modelIds == nil || nodeIds == nil || modelIds.count == 0 || nodeIds.count == 0
				raise RuntimeError, "New models and nodes cannot be empty"
			end
			success, reason = isUpdateValid?(modelIds, nodeIds)
			if success
				h = {models: modelIds, nodes: nodeIds}
				if @release.update(tree: h)
					return true, "Release updated successfully"
				else
					return false, "Database save failed"
				end
			end
			puts reason
			return success, reason
		end

		def getModelIds
			return @release.tree[:models]
		end
		def getNodeIds
			return @release.tree[:nodes]
		end
		def isBuildReady?
			return ((@release.buildstatus == Release::BUILDSTATE[:pre_build]) || 
				(@release.id == nil))
		end
		def isBuilt?
			return @release.buildstatus == Release::BUILDSTATE[:build_complete]
		end

		def getReleaseTree
			# note: this tree leverages the fact that if a treenode has a model in it,
			# it will not have children; if the treenode doesn't have a model, then it
			# must have children 
			retJSON = {
				:id => @release.id,
				:name => "Release: #{@release.name}",
				:description => "Release updated at: #{@release.updated_at}",
				:comment => "Release created at: #{@release.created_at}"
			}
			modelIds = @release.tree[:models]
			nodeIds = @release.tree[:nodes]
			childrenHash = []
			nodeIds.each do |nodeId|
				tn = TreeNode.find(nodeId)
				selectedTNHash = []

				# get models in children
				tn.descendants.each do |tnd|
					tndModelIds = tnd.models.pluck(:id)
					tndModelIds.each do |tndmId|
						if modelIds.include?(tndmId)
							model = Model.find(tndmId)
							modelHash = {
								:id => model.id,
								:name => model.name,
								:model_version => model.model_version,
								:algorithm => model.algorithm,
								:model_type => model.model_type,
								:model_url => model.get_S3_model_file
							}
							selectedTNHash << {
								:id => tnd.id,
								:name => tnd.name,
								:description => tnd.description,
								:comment => tnd.comment,
								:model => modelHash
							}
						end
					end
				end
				# get models in self
				tnModelId = nil
				tnModelIds = tn.models.pluck(:id)
				tnModelIds.each do |tnmId|
					if modelIds.include?(tnmId)
						tnModelId = tnmId
					end
				end

				if tnModelId == nil
					childrenHash << {
						:id => tn.id,
						:name => tn.name,
						:description => tn.description,
						:comment => tn.comment,
						:children => selectedTNHash
					}
				else
					model = Model.find(tnModelId)
					modelHash = {
						:id => model.id,
						:name => model.name,
						:model_version => model.model_version,
						:algorithm => model.algorithm,
						:model_type => model.model_type,
						:model_url => model.get_S3_model_file
					}
					childrenHash << {
						:id => tn.id,
						:name => tn.name,
						:description => tn.description,
						:comment => tn.comment,
						:model => modelHash
					}
				end
			end

			retJSON.merge!(children: childrenHash)
			return {root: retJSON}
		end

		private
			def isUpdateValid?(modelIds, nodeIds)
				# tree root is not included in nodeIds
				if nodeIds.include?(TreeNode.first.id)
					return false, "ReleasesHandler: Invalid: Root treenode included"
				end

				# there are at least two nodes - needs to be at least a binary class
				if nodeIds.count < 2
					return false, "ReleasesHandler: Invalid: At least two nodes need to be present"
				end

				# at least one node needs to be weak model
				weakModelId = TreeNode.where(name: ImageTag::WEAKMODEL).pluck(:id).first
				if (weakModelId == nil) || (not nodeIds.include?(weakModelId))
					return false, "ReleasesHandler: Invalid: At least one model from weak model must be present"
				end

				# no two models under the same treenode
				treeNodeIDs = []
				modelIds.each do |modelId|
					treeNodeID = Model.find(modelId).tree_node.id
					if treeNodeIDs.include?(treeNodeID)
						return false, "ReleasesHandler: Invalid: Two models under same treenode"
					end
					treeNodeIDs << treeNodeID
				end

				# all treenodes have at least one model
				nodeIds.each do |nodeId|
					curModelIds = []
					TreeNode.find(nodeId).self_and_descendants.each do |child|
						curModelIds << child.models.pluck(:id)
					end
					curModelIds.flatten!
					intersects = false
					modelIds.each do |modelId|
						if curModelIds.include?(modelId)
							intersects = true
							break
						end
					end
					if not intersects
						return false, "ReleasesHandler: Invalid: Treenode doesn't have a model"
					end
				end

				# no treenode under another treenode
				nodeIds.each do |nodeId|
					childrenIds = TreeNode.find(nodeId).descendant_ids
					childrenIds.each do |childId|
						if nodeIds.include?(childId)
							return false, "ReleasesHandler: Invalid: Nested treenode"
						end
					end
				end

				# all models have at least one ancestor treenode
				modelIds.each do |modelId|
					intersects = false
					ancestorIds = Model.find(modelId).tree_node.self_and_ancestor_ids
					ancestorIds.each do |ancestorId|
						if nodeIds.include?(ancestorId)
							intersects = true
							break
						end
					end
					if not intersects
						return false, "ReleasesHandler: Invalid: Model doesn't have an ancestor treenode"
					end
				end				

				return true, "ReleasesHandler: Valid: All checks pass"
			end
	end
end