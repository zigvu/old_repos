module Services
	class SettingsHandler
		# For each user_setting field, there is a single array row
		# First value in a field array row is the name of the field
		# Second value in a field array row is an array of things it holds
		@@fieldValues = [
			[:selections, [:treeNodes, :models, :videos, :videoFrames]],
			[:clipboard, [:treeNodes, :models, :videos, :videoFrames]],
			[:preferences, [:color]]
		]

		def initialize(user_settings)
			@user_settings = user_settings
		end

		def resetAllSettings
			resetSelections and resetClipboard and resetPreferences
		end

		def resetSelections
			setDefaultField(:selections)
		end
		def resetClipboard
			setDefaultField(:clipboard)
		end
		def resetPreferences
			setDefaultField(:preferences)
		end

		# Meta programming to create commonly used methods
		@@fieldValues.each do |fv|
			field = fv[0]
			methodNames = fv[1]
			methodNames.each do |mn|
				fieldName = field.slice(0,1).capitalize + field.slice(1..-1)
				methodName = mn.slice(0,1).capitalize + mn.slice(1..-1)

				# Getter methods: Example: getSelectionsCampaigns
				define_method("get#{fieldName}#{methodName}") do
					getX(field, mn)
				end

				# Adder methods: Example: addSelectionsCampaigns
				define_method("add#{fieldName}#{methodName}") do |argument|
					addX(field, mn, argument)
				end

				# Remover methods: Example: removeSelectionsCampaigns
				define_method("remove#{fieldName}#{methodName}") do |argument|
					removeX(field, mn, argument)
				end

				# Resetter methods: Example: resetSelectionsCampaigns
				define_method("reset#{fieldName}#{methodName}") do
					resetX(field, mn)
				end
			end
		end

		private
			def getX(columnName, hashKeyName)
				column = @user_settings.send(columnName)
				hashValue = column[hashKeyName]
				hashValue.to_a
			end

			def addX(columnName, hashKeyName, hashValueArray)
				column = @user_settings.send(columnName)
				column[hashKeyName].merge(hashValueArray)
				@user_settings.update({columnName => column})
			end

			def removeX(columnName, hashKeyName, hashValueArray)
				column = @user_settings.send(columnName)
				column[hashKeyName].subtract(hashValueArray)
				@user_settings.update({columnName => column})
			end

			def resetX(columnName, hashKeyName)
				column = @user_settings.send(columnName)
				column[hashKeyName].clear
				@user_settings.update({columnName => column})
			end

			def setDefaultField(columnName)
				@@fieldValues.each do |fv|
					if fv[0] == columnName
						column = {}
						fv[1].each do |mn|
							column.merge!(mn => [].to_set)
						end
						return @user_settings.update({columnName => column})
					end
				end
				return false
			end
	end
end