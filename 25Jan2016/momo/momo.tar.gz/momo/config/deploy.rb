require "rvm/capistrano"
require "rvm/capistrano/alias_and_wrapp"
require "bundler/capistrano"

set :application, "momo"
set :repository,  "git@github.com:zigvu/momo.git"
set :branch, "master"
#https://github.com/zigvu/momo.git

set :scm, :git # You can set :scm explicitly or Capistrano will make an intelligent guess based on known version control directory names
# Or: `accurev`, `bzr`, `cvs`, `darcs`, `git`, `mercurial`, `perforce`, `subversion` or `none`

# role :web, "your web-server here"                          # Your HTTP server, Apache/etc
# role :app, "your app-server here"                          # This may be the same as your `Web` server
# role :db,  "your primary db-server here", :primary => true # This is where Rails migrations will run
# role :db,  "your slave db-server here"

set :deploy_to, "/var/www"
server ENV['AWS_SERVER'], :app, :web, :db, :primary => true
set :user, "railsuser"
set :ssh_options, { :forward_agent => true }
set :keep_releases, 5
#set :use_sudo, false

default_run_options[:pty] = true
set :normalize_asset_timestamps, false

# if you want to clean up old releases on each deploy uncomment this:
# after "deploy:restart", "deploy:cleanup"

# if you're still using the script/reaper helper you will need
# these http://github.com/rails/irs_process_scripts

# If you are using Passenger mod_rails uncomment this:
namespace :deploy do
  task :start do ; end
  task :stop do ; end
  task :restart, :roles => :app, :except => { :no_release => true } do
    run "#{try_sudo} touch #{File.join(current_path,'tmp','restart.txt')}"
  end

  task :symlink_password do
  	run "ln -nfs #{shared_path}/config/passwords.yml #{release_path}/config/passwords.yml"
  end
end

after 'deploy:update_code', 'deploy:symlink_password'
before 'deploy:restart', 'deploy:migrate'
after 'deploy', 'deploy:cleanup'


# note: this is a hack -- it needs to be at the end of the file for
# deploy:update_code to work!
load 'deploy/assets'