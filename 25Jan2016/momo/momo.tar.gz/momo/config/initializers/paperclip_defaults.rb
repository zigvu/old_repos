if Rails.env.local?
	Paperclip::Attachment.default_options.merge!(
	    :path => "#{Rails.root}/public/system/images/:attachment/:id/:style.:extension",
		:url => "/system/images/:attachment/:id/:style.:extension",
		:default_url => '/images/missing_:style.png',
		:use_timestamp => false
	)
else
	Paperclip::Attachment.default_options.merge!(
		:storage => :s3,
	    :s3_credentials => "#{Rails.root}/config/aws.yml",
	    :s3_permissions => "private",
	    :path => ":attachment/:id/:style.:extension",
		:url => ':s3_alias_url',
		:default_url => '/images/missing_:style.png',
		:use_timestamp => false
	)
end