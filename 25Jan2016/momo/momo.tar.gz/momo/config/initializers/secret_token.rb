# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Momo::Application.config.secret_key_base = '48f05b9c8096cc7db08711aefdb1f4dbe30c9b5f4ee9540ac9bfab7725160e9e3d610a83de90576679c4e0d8c01f0f12a280f2bf2af3d5111a84967710a7abf9'
