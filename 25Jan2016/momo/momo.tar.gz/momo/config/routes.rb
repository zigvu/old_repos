Momo::Application.routes.draw do


  namespace :builder do
    get 'releases/getDefaultRelease' => 'releases#getDefaultRelease'
    resources :releases, :defaults => { :format => 'json' } do
    end

    resources :spot_managers, :defaults => { :format => 'json' } do
    end

    resources :tree_nodes, :defaults => { :format => 'json' } do
      get 'model' => 'tree_nodes#getLatestModel'
      get 'releases' => 'tree_nodes#getReleases'
    end

    resources :models, :defaults => { :format => 'json' } do
      get 'TRAIN_POS' => 'models#getImages', :album => ImageTag::TRAIN_POS
      get 'TRAIN_NEG' => 'models#getImages', :album => ImageTag::TRAIN_NEG
      get 'TEST_POS' => 'models#getImages', :album => ImageTag::TEST_POS
      get 'TEST_NEG' => 'models#getImages', :album => ImageTag::TEST_NEG
      get 'IMAGEBANK' => 'models#getImages', :album => ImageTag::IMAGEBANK
      put 'updateScore' => 'models#updateScore'
      put 'updateModelParam' => 'models#updateModelParam'
      put 'updateScoreFromFile' => 'models#updateScoreFromFile'
    end

    get 'videos/evaluateQueueLength' => 'videos#evaluateQueueLength'
    resources :videos, :defaults => { :format => 'json' } do
      get 'upload' => 'videos#upload'
      put 'upload' => 'videos#uploadUpdate'
      get 'inspect' => 'videos#inspect'
      put 'inspect' => 'videos#inspectUpdate'
      get 'evaluate' => 'videos#evaluate'
      put 'evaluateUpdateFromFile' => 'videos#evaluateUpdateFromFile'
      get 'evaluate/:model_id' => 'videos#evaluateModel'
      put 'evaluate/:model_id' => 'videos#evaluateModelUpdate'

      get 'evaluate/:model_id/videoframe/:frame_position' => 'videos#videoFrame'
      put 'evaluate/:model_id/videoframe' => 'videos#videoFrameUpdate'
    end
  end

  resources :models do
    member do
      get 'buildNewVersion' => 'models#buildNewVersion'
      get 'viewImages' => 'models#viewImages'
      get 'addImages' => 'models#addImages'
      get 'buildAndTestModel' => 'models#buildAndTestModel'
      get 'rerunModelTasks' => 'models#rerunModelTasks'
    end
  end

  get 'models/createHierarchy' => 'models#createHierarchy'
  post 'models/selectNodeChild' => 'models#selectNodeChild'
  post 'models/finalizeNewModel' => 'models#finalizeNewModel'
  post 'models/finalizeNodeTree' => 'models#finalizeNodeTree'

  post 'images/uploadFromKheer' => 'images#uploadFromKheer'
  get 'images/uploadFromAddon' => 'images#uploadFromAddon'
  get 'images/uploadFromLocal' => 'images#uploadFromLocal'
  get 'images/dragDropFromWeb' => 'images#dragDropFromWeb'
  get 'images/pasteFromVideo' => 'images#pasteFromVideo'

  get 'videos/viewVideoClipboard' => 'videos#viewVideoClipboard'
  get 'videos/uploadFromLocal' => 'videos#uploadFromLocal'
  get 'videos/uploadFromURL' => 'videos#uploadFromURL'
  post 'videos/handleUploadFromURL' => 'videos#handleUploadFromURL'
  get 'videos/modelNetworkGraph' => 'videos#modelNetworkGraph'
  get 'videos/getIndexVideosForTable' => 'videos#getIndexVideosForTable'

  resources :videos do
    member do
      get 'addModelsForDetection' => 'videos#addModelsForDetection'
      get 'handleAddModelsForDetection' => 'videos#handleAddModelsForDetection'
      
      get 'videoLabelSelection' => 'videos#videoLabelSelection'
      get 'handleVideoLabelSelection' => 'videos#handleVideoLabelSelection'

      get 'modelEvaluation' => 'videos#modelEvaluation'

      get 'rerunVideoTasks' => 'videos#rerunVideoTasks'
    end
  end

  resources :video_frames

  resources :images

  resources :tree_nodes

  resources :model_text_tags

  get 'releases/handleReleases' => 'releases#handleReleases'
  get 'releases/handleDefault' => 'releases#handleDefault'
  get 'releases/handleBuild' => 'releases#handleBuild'
  resources :releases

  get 'users/admin' => 'users#admin'
  get 'users/admin/spot' => 'users#spot'
  post 'users/admin/handleSpot' => 'users#handleSpot'
  get 'users/admin/handleOrphanedImages' => 'users#handleOrphanedImages'

  devise_for(:users, :controllers => { :sessions => "sessions" })

  # The priority is based upon order of creation: first created -> highest priority.
  # See how all your routes lay out with "rake routes".

  # You can have the root of your site routed with "root"
  root 'models#index'

  # Example of regular route:
  #   get 'products/:id' => 'catalog#view'

  # Example of named route that can be invoked with purchase_url(id: product.id)
  #   get 'products/:id/purchase' => 'catalog#purchase', as: :purchase

  # Example resource route (maps HTTP verbs to controller actions automatically):
  #   resources :products

  # Example resource route with options:
  #   resources :products do
  #     member do
  #       get 'short'
  #       post 'toggle'
  #     end
  #
  #     collection do
  #       get 'sold'
  #     end
  #   end

  # Example resource route with sub-resources:
  #   resources :products do
  #     resources :comments, :sales
  #     resource :seller
  #   end

  # Example resource route with more complex sub-resources:
  #   resources :products do
  #     resources :comments
  #     resources :sales do
  #       get 'recent', on: :collection
  #     end
  #   end
  
  # Example resource route with concerns:
  #   concern :toggleable do
  #     post 'toggle'
  #   end
  #   resources :posts, concerns: :toggleable
  #   resources :photos, concerns: :toggleable

  # Example resource route within a namespace:
  #   namespace :admin do
  #     # Directs /admin/products/* to Admin::ProductsController
  #     # (app/controllers/admin/products_controller.rb)
  #     resources :products
  #   end
end
