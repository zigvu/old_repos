class AddParentIdToTreeNode < ActiveRecord::Migration
 def change
    add_column :tree_nodes, :parent_id, :integer
 end
end