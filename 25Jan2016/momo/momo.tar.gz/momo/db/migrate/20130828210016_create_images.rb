class CreateImages < ActiveRecord::Migration
  def change
    create_table :images do |t|
      t.integer :source_file_id
      t.string :file_source
      t.string :large_filepath
      t.string :medium_filepath
      t.string :small_filepath
      t.integer :user_id

      t.timestamps
    end
  end
end
