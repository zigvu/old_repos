class CreateModels < ActiveRecord::Migration
  def change
    create_table :models do |t|
      t.string :dictionary_path
      t.string :svm_path
      t.integer :model_version
      t.string :algorithm
      t.string :PRcurve_path
      t.string :ROCcurve_path
      t.float :accuracy
      t.text :comment
      t.integer :tree_node_id
      t.integer :user_id

      t.timestamps
    end
  end
end
