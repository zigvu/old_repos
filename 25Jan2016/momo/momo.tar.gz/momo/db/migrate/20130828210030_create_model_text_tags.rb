class CreateModelTextTags < ActiveRecord::Migration
  def change
    create_table :model_text_tags do |t|
      t.string :tag
      t.integer :model_id
      t.integer :user_id

      t.timestamps
    end
  end
end
