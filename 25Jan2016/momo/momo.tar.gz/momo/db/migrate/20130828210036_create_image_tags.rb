class CreateImageTags < ActiveRecord::Migration
  def change
    create_table :image_tags do |t|
      t.string :usage
      t.float :detection_score
      t.integer :image_id
      t.integer :model_id
      t.integer :user_id
      t.integer :model_text_tag_id

      t.timestamps
    end
  end
end
