class RemoveLargeSmallFilepathsFromImage < ActiveRecord::Migration
  def change
    remove_column :images, :large_filepath, :string
    remove_column :images, :small_filepath, :string
  end
end
