class AddBuildstatusToModels < ActiveRecord::Migration
  def change
    add_column :models, :buildstatus, :string
  end
end
