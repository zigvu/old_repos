class AddThresholdToModels < ActiveRecord::Migration
  def change
    add_column :models, :threshold, :float
  end
end
