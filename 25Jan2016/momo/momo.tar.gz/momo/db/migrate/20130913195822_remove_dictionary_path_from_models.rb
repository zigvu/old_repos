class RemoveDictionaryPathFromModels < ActiveRecord::Migration
  def change
    remove_column :models, :dictionary_path, :string
  end
end
