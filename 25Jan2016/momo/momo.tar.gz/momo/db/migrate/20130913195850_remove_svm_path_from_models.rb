class RemoveSvmPathFromModels < ActiveRecord::Migration
  def change
    remove_column :models, :svm_path, :string
  end
end
