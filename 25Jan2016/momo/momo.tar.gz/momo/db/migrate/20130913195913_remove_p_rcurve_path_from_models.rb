class RemovePRcurvePathFromModels < ActiveRecord::Migration
  def change
    remove_column :models, :PRcurve_path, :string
  end
end
