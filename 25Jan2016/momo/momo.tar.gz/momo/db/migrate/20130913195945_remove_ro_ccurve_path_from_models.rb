class RemoveRoCcurvePathFromModels < ActiveRecord::Migration
  def change
    remove_column :models, :ROCcurve_path, :string
  end
end
