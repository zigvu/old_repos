class AddModelpathToModels < ActiveRecord::Migration
  def change
    add_column :models, :modelpath, :string
  end
end
