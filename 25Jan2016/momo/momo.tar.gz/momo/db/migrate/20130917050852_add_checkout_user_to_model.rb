class AddCheckoutUserToModel < ActiveRecord::Migration
  def change
    add_column :models, :checkout_user, :integer
  end
end
