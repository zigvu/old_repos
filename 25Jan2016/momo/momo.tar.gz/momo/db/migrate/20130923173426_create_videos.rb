class CreateVideos < ActiveRecord::Migration
  def change
    create_table :videos do |t|
      t.string :source_type
      t.string :source_URL
      t.string :S3_URL
      t.integer :user_id

      t.timestamps
    end
  end
end
