class CreateVideoFrames < ActiveRecord::Migration
  def change
    create_table :video_frames do |t|
      t.datetime :frame_position
      t.string :S3_URL
      t.integer :video_id

      t.timestamps
    end
  end
end
