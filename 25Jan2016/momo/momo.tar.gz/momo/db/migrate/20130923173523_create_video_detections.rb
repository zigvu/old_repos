class CreateVideoDetections < ActiveRecord::Migration
  def change
    create_table :video_detections do |t|
      t.float :score
      t.string :classification
      t.integer :video_id
      t.integer :model_id

      t.timestamps
    end
  end
end
