class RemoveFramePositionFromVideoFrame < ActiveRecord::Migration
  def change
    remove_column :video_frames, :frame_position, :datetime
  end
end
