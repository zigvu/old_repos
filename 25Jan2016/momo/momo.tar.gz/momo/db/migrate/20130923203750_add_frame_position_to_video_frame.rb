class AddFramePositionToVideoFrame < ActiveRecord::Migration
  def change
    add_column :video_frames, :frame_position, :integer
  end
end
