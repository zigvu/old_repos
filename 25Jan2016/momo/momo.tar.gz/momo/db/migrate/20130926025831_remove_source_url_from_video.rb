class RemoveSourceUrlFromVideo < ActiveRecord::Migration
  def change
    remove_column :videos, :source_URL, :string
  end
end
