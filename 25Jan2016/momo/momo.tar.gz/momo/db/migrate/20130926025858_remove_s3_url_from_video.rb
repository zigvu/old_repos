class RemoveS3UrlFromVideo < ActiveRecord::Migration
  def change
    remove_column :videos, :S3_URL, :string
  end
end
