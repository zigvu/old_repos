class AddFileSourceToVideo < ActiveRecord::Migration
  def change
    add_column :videos, :file_source, :string
    add_column :videos, :quality, :string
    add_column :videos, :format, :string
    add_column :videos, :length, :integer
    add_column :videos, :size, :integer
  end
end
