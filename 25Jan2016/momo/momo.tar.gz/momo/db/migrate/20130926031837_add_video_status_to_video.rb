class AddVideoStatusToVideo < ActiveRecord::Migration
  def change
    add_column :videos, :videostatus, :string
  end
end
