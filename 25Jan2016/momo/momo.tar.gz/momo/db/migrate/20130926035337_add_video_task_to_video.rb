class AddVideoTaskToVideo < ActiveRecord::Migration
  def change
    add_column :videos, :videotask, :string
  end
end
