class AddTitledescriptionToVideo < ActiveRecord::Migration
  def change
    add_column :videos, :title, :text
    add_column :videos, :description, :text
    add_column :videos, :comment, :text
  end
end
