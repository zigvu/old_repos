class CreateVideoLabels < ActiveRecord::Migration
  def change
    create_table :video_labels do |t|
      t.integer :video_id
      t.integer :user_id
      t.integer :tree_node_id

      t.timestamps
    end
  end
end
