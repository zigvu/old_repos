class RemoveModelIdFromFrameDetection < ActiveRecord::Migration
  def change
    remove_column :frame_detections, :model_id, :integer
  end
end
