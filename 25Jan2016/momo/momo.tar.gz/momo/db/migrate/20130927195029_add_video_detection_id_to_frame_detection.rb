class AddVideoDetectionIdToFrameDetection < ActiveRecord::Migration
  def change
    add_column :frame_detections, :video_detection_id, :integer
  end
end
