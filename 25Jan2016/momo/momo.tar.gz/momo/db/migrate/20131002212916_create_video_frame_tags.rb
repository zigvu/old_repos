class CreateVideoFrameTags < ActiveRecord::Migration
  def change
    create_table :video_frame_tags do |t|
      t.string :usage
      t.integer :user_id
      t.integer :video_frame_id

      t.timestamps
    end
  end
end
