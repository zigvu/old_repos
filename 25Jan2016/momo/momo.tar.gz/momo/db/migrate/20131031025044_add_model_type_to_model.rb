class AddModelTypeToModel < ActiveRecord::Migration
  def change
    add_column :models, :model_type, :string
  end
end
