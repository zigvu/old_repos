class AddErrorToVideos < ActiveRecord::Migration
  def change
    add_column :videos, :error, :string
  end
end
