class AddErrorToModels < ActiveRecord::Migration
  def change
    add_column :models, :error, :string
  end
end
