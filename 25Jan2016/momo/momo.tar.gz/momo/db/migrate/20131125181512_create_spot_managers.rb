class CreateSpotManagers < ActiveRecord::Migration
  def change
    create_table :spot_managers do |t|
      t.string :type
      t.float :price
      t.string :task
      t.integer :num_instance
      t.integer :idle_time
      t.string :failure_behavior
      t.integer :user_id

      t.timestamps
    end
  end
end
