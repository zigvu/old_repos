class FixTypeInSpotManager < ActiveRecord::Migration
  def change
  	change_table :spot_managers do |t|
  		t.rename :type, :instance_type
  	end
  end
end
