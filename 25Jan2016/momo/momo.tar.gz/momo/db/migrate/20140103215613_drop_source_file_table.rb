class DropSourceFileTable < ActiveRecord::Migration
  def up
    drop_table :source_files
    remove_column :images, :source_file_id
  end

  def down
    raise ActiveRecord::IrreversibleMigration
  end
end
