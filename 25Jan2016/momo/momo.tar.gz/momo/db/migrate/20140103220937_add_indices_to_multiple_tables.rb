class AddIndicesToMultipleTables < ActiveRecord::Migration
  def change
  	add_index :frame_detections, [:video_frame_id, :video_detection_id], :name => 'video_frame_video_detection_ids_ix'
  	add_index :image_tags, [:image_id, :model_id], :name => 'image_model_ids_ix'
  	add_index :images, :user_id, :name => 'user_id_ix'
  	add_index :model_text_tags, :model_id, :name => 'model_id_ix'
  	add_index :models, :tree_node_id, :name => 'tree_node_id_ix'
  	add_index :video_detections, [:video_id, :model_id], :name => 'video_model_ids_ix'
  	add_index :video_frame_tags, :video_frame_id, :name => 'video_frame_id_ix'
  	add_index :video_frames, :video_id, :name => 'video_id_ix'
  	add_index :video_labels, [:video_id, :tree_node_id], :name => 'video_tree_node_ids_ix'
  	add_index :videos, :user_id, :name => 'user_id_ix'
  end
end
