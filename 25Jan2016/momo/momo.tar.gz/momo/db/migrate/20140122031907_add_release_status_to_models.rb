class AddReleaseStatusToModels < ActiveRecord::Migration
  def change
    add_column :models, :release_status, :string
  end
end
