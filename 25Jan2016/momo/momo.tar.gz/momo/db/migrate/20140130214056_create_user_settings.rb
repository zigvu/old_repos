class CreateUserSettings < ActiveRecord::Migration
  def change
    create_table :user_settings do |t|
      t.text :selections
      t.text :releases
      t.text :clipboard
      t.text :preferences
      t.integer :user_id

      t.timestamps
    end
    add_index :user_settings, :user_id
  end
end
