class CreateReleases < ActiveRecord::Migration
  def change
    create_table :releases do |t|
      t.text :tree
      t.string :buildstatus
      t.string :S3_URL
      t.integer :user_id

      t.timestamps
    end
  end
end
