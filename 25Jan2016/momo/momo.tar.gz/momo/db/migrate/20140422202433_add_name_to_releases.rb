class AddNameToReleases < ActiveRecord::Migration
  def change
    add_column :releases, :name, :string
  end
end
