class RemoveReleasesFromUserSettings < ActiveRecord::Migration
  def change
    remove_column :user_settings, :releases, :text
  end
end
