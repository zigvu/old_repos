class AddReleaseIdToUserSettings < ActiveRecord::Migration
  def change
    add_column :user_settings, :release_id, :integer
  end
end
