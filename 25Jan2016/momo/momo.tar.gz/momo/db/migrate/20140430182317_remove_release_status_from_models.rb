class RemoveReleaseStatusFromModels < ActiveRecord::Migration
  def change
    remove_column :models, :release_status, :string
  end
end
