# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20140430182317) do

  create_table "frame_detections", force: true do |t|
    t.float    "frame_score"
    t.float    "cumulative_score"
    t.string   "classification"
    t.integer  "video_frame_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "video_detection_id"
  end

  add_index "frame_detections", ["video_frame_id", "video_detection_id"], name: "video_frame_video_detection_ids_ix", using: :btree

  create_table "image_tags", force: true do |t|
    t.string   "usage"
    t.float    "detection_score"
    t.integer  "image_id"
    t.integer  "model_id"
    t.integer  "user_id"
    t.integer  "model_text_tag_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "image_tags", ["image_id", "model_id"], name: "image_model_ids_ix", using: :btree

  create_table "images", force: true do |t|
    t.string   "file_source"
    t.string   "medium_filepath"
    t.integer  "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "upload_file_name"
    t.string   "upload_content_type"
    t.integer  "upload_file_size"
    t.datetime "upload_updated_at"
  end

  add_index "images", ["user_id"], name: "user_id_ix", using: :btree

  create_table "model_text_tags", force: true do |t|
    t.string   "tag"
    t.integer  "model_id"
    t.integer  "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "model_text_tags", ["model_id"], name: "model_id_ix", using: :btree

  create_table "models", force: true do |t|
    t.integer  "model_version"
    t.string   "algorithm"
    t.float    "accuracy"
    t.text     "comment"
    t.integer  "tree_node_id"
    t.integer  "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "name"
    t.string   "buildstatus"
    t.float    "threshold"
    t.string   "modelpath"
    t.integer  "checkout_user"
    t.string   "model_type"
    t.string   "error"
  end

  add_index "models", ["tree_node_id"], name: "tree_node_id_ix", using: :btree

  create_table "releases", force: true do |t|
    t.text     "tree"
    t.string   "buildstatus"
    t.string   "S3_URL"
    t.integer  "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "name"
  end

  create_table "spot_managers", force: true do |t|
    t.string   "instance_type"
    t.float    "price"
    t.string   "task"
    t.integer  "num_instance"
    t.integer  "idle_time"
    t.string   "failure_behavior"
    t.integer  "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  create_table "tree_node_hierarchies", id: false, force: true do |t|
    t.integer "ancestor_id",   null: false
    t.integer "descendant_id", null: false
    t.integer "generations",   null: false
  end

  add_index "tree_node_hierarchies", ["ancestor_id", "descendant_id", "generations"], name: "tree_node_anc_desc_udx", unique: true, using: :btree
  add_index "tree_node_hierarchies", ["descendant_id"], name: "tree_node_desc_idx", using: :btree

  create_table "tree_nodes", force: true do |t|
    t.string   "name"
    t.text     "description"
    t.text     "comment"
    t.integer  "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "parent_id"
  end

  create_table "user_settings", force: true do |t|
    t.text     "selections"
    t.text     "clipboard"
    t.text     "preferences"
    t.integer  "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "release_id"
  end

  add_index "user_settings", ["user_id"], name: "index_user_settings_on_user_id", using: :btree

  create_table "users", force: true do |t|
    t.string   "email",                  default: "",    null: false
    t.string   "encrypted_password",     default: "",    null: false
    t.string   "reset_password_token"
    t.datetime "reset_password_sent_at"
    t.datetime "remember_created_at"
    t.integer  "sign_in_count",          default: 0
    t.datetime "current_sign_in_at"
    t.datetime "last_sign_in_at"
    t.string   "current_sign_in_ip"
    t.string   "last_sign_in_ip"
    t.string   "username",                               null: false
    t.string   "firstname",                              null: false
    t.string   "lastname",                               null: false
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "authentication_token"
    t.boolean  "admin",                  default: false
  end

  add_index "users", ["email"], name: "index_users_on_email", unique: true, using: :btree
  add_index "users", ["reset_password_token"], name: "index_users_on_reset_password_token", unique: true, using: :btree

  create_table "video_detections", force: true do |t|
    t.float    "score"
    t.string   "classification"
    t.integer  "video_id"
    t.integer  "model_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "video_detections", ["video_id", "model_id"], name: "video_model_ids_ix", using: :btree

  create_table "video_frame_tags", force: true do |t|
    t.string   "usage"
    t.integer  "user_id"
    t.integer  "video_frame_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "video_frame_tags", ["video_frame_id"], name: "video_frame_id_ix", using: :btree

  create_table "video_frames", force: true do |t|
    t.string   "S3_URL"
    t.integer  "video_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.integer  "frame_position"
  end

  add_index "video_frames", ["video_id"], name: "video_id_ix", using: :btree

  create_table "video_labels", force: true do |t|
    t.integer  "video_id"
    t.integer  "user_id"
    t.integer  "tree_node_id"
    t.datetime "created_at"
    t.datetime "updated_at"
  end

  add_index "video_labels", ["video_id", "tree_node_id"], name: "video_tree_node_ids_ix", using: :btree

  create_table "videos", force: true do |t|
    t.string   "source_type"
    t.integer  "user_id"
    t.datetime "created_at"
    t.datetime "updated_at"
    t.string   "upload_file_name"
    t.string   "upload_content_type"
    t.integer  "upload_file_size"
    t.datetime "upload_updated_at"
    t.string   "file_source"
    t.string   "quality"
    t.string   "format"
    t.integer  "length"
    t.integer  "size"
    t.string   "videostatus"
    t.string   "videotask"
    t.text     "title"
    t.text     "description"
    t.text     "comment"
    t.string   "error"
  end

  add_index "videos", ["user_id"], name: "user_id_ix", using: :btree

end
