# initialize user, model and some images:
builder = User.create(firstname: 'momo', lastname: 'builder', username: 'builder', password: 'abcdefgh', password_confirmation: 'abcdefgh',  email: 'builder@zigvu.com')
admin = User.create(firstname: 'momo', lastname: 'admin', username: 'admin', password: 'abcdefgh', password_confirmation: 'abcdefgh',  email: 'admin@zigvu.com', admin: true)
imagebank = Model.create(name: ImageTag::IMAGEBANK, model_version: 0, buildstatus: "build-complete", algorithm: "StructSVM-Generic", modelpath: "FileNotFoundString", accuracy: 0.0, threshold: 0.0, comment: "Image bank", user_id: User.getBuilderId)

tnRoot = TreeNode.create(name: "Tree Root", description: "Base for all images", comment: "All objects/scene/activity fall under this node", user_id: User.getBuilderId)

# spot instances to use:
User.find(User.getBuilderId).spot_managers.create(instance_type: SpotManager::INSTANCETYPE[:c3_large], price: 0.05, task: SpotManager::TASK[:model], num_instance: 1, idle_time: 30, failure_behavior: SpotManager::FAILUREBEHAVIOR[:terminate])
User.find(User.getBuilderId).spot_managers.create(instance_type: SpotManager::INSTANCETYPE[:c3_large], price: 0.05, task: SpotManager::TASK[:video], num_instance: 1, idle_time: 30, failure_behavior: SpotManager::FAILUREBEHAVIOR[:terminate])

# if production environment, return at this point
# if Rails.env.production?
# 	return
# end

user1 = User.create(firstname: 'evan', lastname: 'acharya', username: 'eacharya', password: 'abcdefgh', password_confirmation: 'abcdefgh',  email: 'abc.d@e.com')
user2 = User.create(firstname: 'john', lastname: 'doe', username: 'johndoe', password: 'abcdefgh', password_confirmation: 'abcdefgh',  email: 'john.doe@e.com')

# create first tree node and link to parent:
tnObj = TreeNode.new(name: "Random Models", description: "Random models for development", comment: "Generic first level tree", user_id: user1.id)
tnRoot.add_child tnObj

tnDog =  TreeNode.new(name: "Dog", description: "Seed node for testing", comment: "Describes all dogs", user_id: user1.id)
tnObj.add_child tnDog

# create model:
mBeagle = Model.create(name: "Beagle", model_version: 0, model_type: "Object", buildstatus: "pre-build", algorithm: "StructSVM-Generic", modelpath: Model.fileNotFoundString, accuracy: 0.0, threshold: 0.0, comment: "Has 100 images in each train/test-pos/neg and has ImageBank images", tree_node_id: tnDog.id, user_id: user1.id)
mtt1 = mBeagle.model_text_tags.create(user_id: user1.id, tag: ModelTextTag::UNASSIGNED)
mtt2 = mBeagle.model_text_tags.create(user_id: user1.id, tag: "Front facing")
mtt3 = mBeagle.model_text_tags.create(user_id: user1.id, tag: "Back facing")

# populate images from /var/seedImages
# prior to running this, clear S3 database as well

# load methods to seed database
load 'app/classes/ImportFromSeed.rb'
imp = ImportFromSeed.new
imp.setLimitRecordCount(500)

# import SUN database to imagebank model
imp.importSUNImagesToImageBank(imagebank.id, '/var/seedImages/SUN/images')

# import positive negative images for beagle:
imp.addImagesToAlbum(user1.id, mBeagle.id, ImageTag::TRAIN_POS, mtt2.tag, '/var/seedImages/beagle/images/positive/train')
imp.addImagesToAlbum(user1.id, mBeagle.id, ImageTag::TRAIN_NEG, nil, '/var/seedImages/beagle/images/negative/train')
imp.addImagesToAlbum(user1.id, mBeagle.id, ImageTag::TEST_POS, mtt3.tag, '/var/seedImages/beagle/images/positive/test')
imp.addImagesToAlbum(user1.id, mBeagle.id, ImageTag::TEST_NEG, nil, '/var/seedImages/beagle/images/negative/test')

# add imagebank to model too:
imagebankImages = imagebank.images.includes(:image_tags).where(image_tags: {usage: ImageTag::TRAIN_POS})
imagebankImages.map do |image|
    image.image_tags.create(user_id: user1.id, model_id: mBeagle.id, usage: ImageTag::IMAGEBANK)
end

# video frame testing:
# video names should correspond to folder names in seedImages/videoframes folder
videoTestingVideos = ["Airplane", "Baseball", "Camping"]
videoTestingModels = ["Airplane", "Baseball", "Camping", "Cooking", "FashionShow", "TruckExtr"]

models = []
videoTestingModels.map do |modelStr|
	models << imp.createDummyModel(modelStr, user1, tnObj, modelStr + " - dummy - no images")
end

videoTestingVideos.map do |videoStr|
	video = user1.videos.create(title: videoStr,source_type: "desktop", videostatus: Video::VIDEOSTATUS[:s3ready], videotask: Video::VIDEOTASK[:evaluateSuccess])
	frameBaseFolder = '/var/seedImages/videoframes/' + videoStr
	
	models.each do |model|
		# create video detections:
		videoDetection = video.video_detections.create(score: 0.1, classification: VideoDetection::CLASSIFICATION[:positive], model_id: model.id)
		modelJSONFolder = frameBaseFolder + '/' + model.name + '.json'
		imp.addVideoFrames(modelJSONFolder, frameBaseFolder, video.id, videoDetection.id)

		# create video labels - randomly tag half of them:
		if rand(videoTestingModels.count - 1) > (videoTestingModels.count/2).round
			model.tree_node.video_labels.create(video_id: video.id, user_id: user1.id)
		end
	end
end

# mAeroplane = imp.createDummyModel("Airplane", user1, tnObj, "Airplane - dummy - no images")
# mBaseball = imp.createDummyModel("Baseball", user1, tnObj, "Baseball - dummy - no images")
# mCamping = imp.createDummyModel("Camping", user1, tnObj, "Camping - dummy - no images")
# mCooking = imp.createDummyModel("Cooking", user1, tnObj, "Cooking - dummy - no images")
# mFashionShow = imp.createDummyModel("FashionShow", user1, tnObj, "FashionShow - dummy - no images")
# mTruckExtr = imp.createDummyModel("TruckExtr", user1, tnObj, "TruckExtr - dummy - no images")

# user1.videos.create(source_type: "desktop", videostatus: Video::VIDEOSTATUS[:s3ready], videotask: Video::VIDEOTASK[:evaluateSuccess])
# vfAeroplane = Video.first.video_detections.create(score: 0.1, classification: VideoDetection::CLASSIFICATION[:positive], model_id: mAeroplane.id)
# vfBaseball = Video.first.video_detections.create(score: 0.2, classification: VideoDetection::CLASSIFICATION[:positive], model_id: mBaseball.id)
# vfCamping = Video.first.video_detections.create(score: 0.3, classification: VideoDetection::CLASSIFICATION[:positive], model_id: mCamping.id)
# vfCooking = Video.first.video_detections.create(score: 0.4, classification: VideoDetection::CLASSIFICATION[:positive], model_id: mCooking.id)
# vfFashionShow = Video.first.video_detections.create(score: 0.5, classification: VideoDetection::CLASSIFICATION[:positive], model_id: mFashionShow.id)
# vfTruckExtr = Video.first.video_detections.create(score: 0.6, classification: VideoDetection::CLASSIFICATION[:evaluateFail], model_id: mTruckExtr.id)

# # populate video frames dummy data:
# imp.addVideoFrames('/var/seedImages/videoframes/camping/Airplane.json', '/var/seedImages/videoframes/camping', Video.first.id, vfAeroplane.id)
# imp.addVideoFrames('/var/seedImages/videoframes/camping/Baseball.json', '/var/seedImages/videoframes/camping', Video.first.id, vfBaseball.id)
# imp.addVideoFrames('/var/seedImages/videoframes/camping/Camping.json', '/var/seedImages/videoframes/camping', Video.first.id, vfCamping.id)
# imp.addVideoFrames('/var/seedImages/videoframes/camping/Cooking.json', '/var/seedImages/videoframes/camping', Video.first.id, vfCooking.id)
# imp.addVideoFrames('/var/seedImages/videoframes/camping/FashionShow.json', '/var/seedImages/videoframes/camping', Video.first.id, vfFashionShow.id)
# imp.addVideoFrames('/var/seedImages/videoframes/camping/TruckExtr.json', '/var/seedImages/videoframes/camping', Video.first.id, vfTruckExtr.id)

