require 'spec_helper'

describe ImageTagController do

end
