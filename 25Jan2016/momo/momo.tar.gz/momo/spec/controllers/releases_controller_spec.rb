require 'spec_helper'

describe ReleasesController do

end
