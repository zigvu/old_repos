# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :frame_detection do
    frame_score 1.5
    cumulative_score 1.5
    classification "MyString"
    video_frame_id 1
    model_id 1
  end
end
