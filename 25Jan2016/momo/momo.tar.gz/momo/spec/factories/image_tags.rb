# spec/factories/image_tag.rb
FactoryGirl.define do
	factory :image_tag do
		usage "none"
		detection_score 0.0
		image
		# model
		user
		#model_text_tag_id
	end
end
