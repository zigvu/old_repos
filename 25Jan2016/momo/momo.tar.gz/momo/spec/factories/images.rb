# spec/factories/image.rb
FactoryGirl.define do
	sequence(:large_filepath) { |n| "large_filepath#{n}.png" }

	factory :image do
		file_source "Web"
		large_filepath
		medium_filepath "medium_filepath.png"
		small_filepath "small_filepath.png"

		user
	end
end

