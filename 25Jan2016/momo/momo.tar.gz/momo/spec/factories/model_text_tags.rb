# spec/factories/model_text_tag.rb
FactoryGirl.define do
	sequence(:tag) { |n| "tag#{n}.png" }
	factory :model_text_tag do
		tag
		model
		user
	end
end
