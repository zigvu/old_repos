# spec/factories/model.rb
FactoryGirl.define do
	sequence(:dictionary_path) { |n| "dictionary_path#{n}" }
	factory :model do
		name {"model_num#{rand(1000).to_s}" }
		dictionary_path
		svm_path "svm_path"
		model_version 0
		algorithm "mhmp"
		PRcurve_path "PRcurve_path"
		ROCcurve_path "ROCcurve_path"
		accuracy 0.0
		comment "comment"
		tree_node
		user
	end
end
