# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :release do
    tree "MyText"
    buildstatus "MyString"
    S3_URL "MyString"
    user_id 1
  end
end
