# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :spot_manager do
    type ""
    price 1.5
    task "MyString"
    num_instance 1
    idle_time 1
    failure_behavior "MyString"
    user_id 1
  end
end
