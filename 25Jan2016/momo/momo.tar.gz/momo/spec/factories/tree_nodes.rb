# spec/factories/tree_node.rb
FactoryGirl.define do
	sequence(:name) { |n| "name#{n}.png" }
	factory :tree_node do
		name
		description "description"
		comment "comment"
		user
	end
end
