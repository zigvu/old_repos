# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :user_setting do
    selections "MyText"
    releases "MyText"
    clipboard "MyText"
    preferences "MyText"
    user_id 1
  end
end
