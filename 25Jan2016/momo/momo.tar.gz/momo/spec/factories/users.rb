# spec/factories/user.rb
FactoryGirl.define do
	sequence(:email) { |n| "email#{n}@a.com" }
	sequence(:username) { |n| "name#{n}b" }

	factory :user do
		firstname "evan"
		lastname "acharya"

		username
		email
		password "plaintextpassword"
	end
end
