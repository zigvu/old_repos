# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :video_detection do
    score 1.5
    classification "MyString"
    video_id 1
    model_id 1
  end
end
