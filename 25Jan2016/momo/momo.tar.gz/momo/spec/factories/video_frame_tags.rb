# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :video_frame_tag do
    usage "MyString"
    user_id 1
    video_frame_id 1
  end
end
