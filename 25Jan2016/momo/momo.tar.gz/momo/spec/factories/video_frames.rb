# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :video_frame do
    frame_position "2013-09-23 10:34:45"
    S3_URL "MyString"
    video_id 1
  end
end
