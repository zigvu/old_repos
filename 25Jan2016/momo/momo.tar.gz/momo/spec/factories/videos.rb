# Read about factories at https://github.com/thoughtbot/factory_girl

FactoryGirl.define do
  factory :video do
    source_type "MyString"
    source_URL "MyString"
    S3_URL "MyString"
    user_id 1
  end
end
