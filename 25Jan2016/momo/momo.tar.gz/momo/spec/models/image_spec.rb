# spec/models/image.rb
require 'spec_helper'

describe Image do
	before(:each) do
		@user = FactoryGirl.create(:user)
		@image1 = FactoryGirl.create(:image)
		@image2 = FactoryGirl.create(:image)
	end

	it "has a valid factory" do
		FactoryGirl.create(:image).should be_valid	
	end

	it "has a valid user" do
		FactoryGirl.build(:image, user: nil).should_not be_valid
	end

	it "destroys image_tags when it destroys" do
		FactoryGirl.create(:image_tag, user: @user, image: @image1)
		FactoryGirl.create(:image_tag, user: @user, image: @image2)
		ImageTag.all.count.should == 2

		@image1.destroy
		@image2.destroy
		ImageTag.all.count.should == 0
	end

end
