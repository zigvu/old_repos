# spec/models/image_tag.rb
require 'spec_helper'

describe ImageTag do
	it "has a valid factory" do
		FactoryGirl.create(:image_tag).should be_valid
	end

	it "has a valid user" do
		FactoryGirl.build(:image_tag, user: nil).should_not be_valid
	end
end