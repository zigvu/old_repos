# spec/models/model.rb
require 'spec_helper'

describe Model do
	before(:each) do
		@user = FactoryGirl.create(:user)
		@rootNode = FactoryGirl.create(:tree_node, user: @user)
		@model = FactoryGirl.create(:model, tree_node: @rootNode, user: @user)
	end

	it "has a valid factory" do
		FactoryGirl.create(:model).should be_valid
	end

	it "has a valid user" do
		FactoryGirl.build(:model, user: nil).should_not be_valid
	end

	it "has a valid name" do
		FactoryGirl.build(:model, name: nil).should_not be_valid
	end

	it "does not have same version as another" do
		FactoryGirl.create(:model, tree_node: @rootNode, user: @user, model_version: @model.model_version).should_not be_valid
	end

	it "is not of pre-defined tree_node types" do
	end
	
	it "has valid tree_node" do
		@model.tree_node.should be_valid
	end

	# each model has its own version of model_text_tags, so upon
	# destroy, delete tags too
	it "deletes model_text_tags upon deletion" do
		ModelTextTag.all.count.should == 0

		mtt1 = FactoryGirl.create(:model_text_tag, model: @model, user: @user)
		mtt2 = FactoryGirl.create(:model_text_tag, model: @model, user: @user)

		ModelTextTag.all.count.should == 2
		@model.model_text_tags.count.should == 2
		@model.destroy

		ModelTextTag.all.count.should == 0
	end
end