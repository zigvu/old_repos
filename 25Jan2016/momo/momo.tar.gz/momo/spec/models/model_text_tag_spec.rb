# spec/models/model_text_tag.rb
require 'spec_helper'

describe ModelTextTag do
	it "has a valid factory" do
		FactoryGirl.create(:model_text_tag).should be_valid
	end

	it "has a valid user" do
		FactoryGirl.build(:model_text_tag, user: nil).should_not be_valid
	end
end
