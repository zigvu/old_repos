# spec/models/tree_node.rb
require 'spec_helper'

describe TreeNode do
	before(:each) do
		@user = FactoryGirl.create(:user)
		@rootNode = FactoryGirl.create(:tree_node, user: @user)
	end

	it "has a valid factory" do
		FactoryGirl.create(:tree_node).should be_valid
	end

	it "has a valid user" do
		FactoryGirl.build(:tree_node, user: nil).should_not be_valid
	end

	it "has a valid name" do
		FactoryGirl.build(:tree_node, name: nil).should_not be_valid
	end

	it "has valid parenting structure" do
		@rootNode.children.count.should == 0

		childNode1 = FactoryGirl.build(:tree_node, user: @user)
		@rootNode.add_child childNode1
		@rootNode.children.count.should == 1

		childNode2 = FactoryGirl.build(:tree_node, user: @user)
		@rootNode.add_child childNode2
		@rootNode.children.count.should == 2

		childNode11 = FactoryGirl.build(:tree_node, user: @user)
		childNode1.add_child childNode11
		@rootNode.children.count.should == 2
		childNode1.children.count.should == 1

		childNode11.parent.should == childNode1
	end

end