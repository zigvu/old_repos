# spec/models/user.rb
require 'spec_helper'

describe User do
	before(:each) do
		@user = FactoryGirl.create(:user)
	end
	
	it "has a valid factory" do
		FactoryGirl.create(:user).should be_valid
	end

	it "is invalid without a username" do
		FactoryGirl.build(:user, username: nil).should_not be_valid
	end
	
	it "does not destroy images upon destruction" do
		image1 = FactoryGirl.create(:image, user: @user)
		image2 = FactoryGirl.create(:image, user: @user)

		Image.all.count.should == 2

		@user.destroy
		Image.all.count.should == 2		
	end

	it "does not destroy models upon destruction" do
		model1 = FactoryGirl.create(:model, user: @user)
		model1 = FactoryGirl.create(:model, user: @user)

		Model.all.count.should == 2

		@user.destroy
		Model.all.count.should == 2		
	end
end
